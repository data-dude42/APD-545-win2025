package com.example.w67.exceptions;

public class ConfirmActionException extends Exception {
    public ConfirmActionException(String message) {
        super(message);
    }
}