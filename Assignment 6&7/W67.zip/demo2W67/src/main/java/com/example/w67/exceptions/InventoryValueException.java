package com.example.w67.exceptions;

// InventoryValueException.java
public class InventoryValueException extends Exception {
    public InventoryValueException(String message) {
        super(message);
    }
}