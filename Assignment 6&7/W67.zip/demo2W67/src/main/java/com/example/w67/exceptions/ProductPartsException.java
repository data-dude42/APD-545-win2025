package com.example.w67.exceptions;

public class ProductPartsException extends Exception {
    public ProductPartsException(String message) {
        super(message);
    }
}
