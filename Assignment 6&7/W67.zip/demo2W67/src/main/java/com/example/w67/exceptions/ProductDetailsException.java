package com.example.w67.exceptions;

// ProductDetailsException.java
public class ProductDetailsException extends Exception {
    public ProductDetailsException(String message) {
        super(message);
    }
}