package com.example.w67.exceptions;

public class PartDetailsException extends Exception {
    public PartDetailsException(String message) {
        super(message);
    }
}