package com.example.w67.exceptions;

// MinMaxValueException.java
public class MinMaxValueException extends Exception {
    public MinMaxValueException(String message) {
        super(message);
    }
}