package com.example.w67.exceptions;

// ProductPriceException.java
public class ProductPriceException extends Exception {
    public ProductPriceException(String message) {
        super(message);
    }
}