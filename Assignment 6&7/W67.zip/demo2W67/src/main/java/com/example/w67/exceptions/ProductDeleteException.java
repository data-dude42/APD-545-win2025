package com.example.w67.exceptions;

// ProductDeleteException.java
public class ProductDeleteException extends Exception {
    public ProductDeleteException(String message) {
        super(message);
    }
}