package com.example.w67.exceptions;

// ProductPartException.java
public class ProductPartException extends Exception {
    public ProductPartException(String message) {
        super(message);
    }
}