module com.example.w67 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;
    requires jakarta.xml.bind;
    requires java.logging;
    requires java.sql;

    opens com.example.w67 to javafx.fxml, jakarta.xml.bind;
    exports com.example.w67;
    exports com.example.w67.Models;
    opens com.example.w67.Models to jakarta.xml.bind, javafx.fxml;
    exports com.example.w67.Controller;
    opens com.example.w67.Controller to jakarta.xml.bind, javafx.fxml;
}