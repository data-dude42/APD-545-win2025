package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Model class for Admin information
 */
public class Admin {
    private final IntegerProperty adminID;
    private final StringProperty username;
    private final StringProperty password;

    // Logger for admin activities
    private static final Logger logger = Logger.getLogger(Admin.class.getName());

    /**
     * Constructor for Admin class
     * @param adminID Unique identifier for the admin
     * @param username Admin's username
     * @param password Admin's password
     */
    public Admin(int adminID, String username, String password) {
        this.adminID = new SimpleIntegerProperty(adminID);
        this.username = new SimpleStringProperty(username);
        this.password = new SimpleStringProperty(password);
    }

    // Getters and Setters
    public int getAdminID() {
        return adminID.get();
    }

    public IntegerProperty adminIDProperty() {
        return adminID;
    }

    public void setAdminID(int adminID) {
        this.adminID.set(adminID);
    }

    public String getUsername() {
        return username.get();
    }

    public StringProperty usernameProperty() {
        return username;
    }

    public void setUsername(String username) {
        this.username.set(username);
    }

    public String getPassword() {
        return password.get();
    }

    public StringProperty passwordProperty() {
        return password;
    }

    public void setPassword(String password) {
        this.password.set(password);
    }

    /**
     * Authenticates an admin based on username and password
     * @param username Admin's username
     * @param password Admin's password
     * @return true if authentication is successful, false otherwise
     */
    public boolean login(String username, String password) {
        boolean success = this.username.get().equals(username) && this.password.get().equals(password);

        if (success) {
            logger.log(Level.INFO, "Admin '{0}' logged in successfully.", username);
        } else {
            logger.log(Level.WARNING, "Failed login attempt for username: {0}", username);
        }

        return success;
    }

    /**
     * Searches for a guest by name or phone number
     * @param searchTerm Name or phone number to search for
     * @return true if guest is found, false otherwise
     */
    public boolean searchGuest(String searchTerm) {
        // In a real implementation, this would search a database
        // For now, we'll just log the action and return true
        logger.log(Level.INFO, "Admin '{0}' searched for guest with term: {1}",
                new Object[]{getUsername(), searchTerm});

        return true;
    }

    /**
     * Checks out a guest and finalizes their stay
     * @param reservationID ID of the reservation to check out
     * @return true if checkout is successful, false otherwise
     */
    public boolean checkOutGuest(int reservationID) {
        // In a real implementation, this would update the database
        // For now, we'll just log the action and return true
        logger.log(Level.INFO, "Admin '{0}' checked out reservation ID: {1}",
                new Object[]{getUsername(), reservationID});

        return true;
    }

    /**
     * Generates reports based on hotel data
     * @param reportType Type of report to generate
     * @return true if report generation is successful, false otherwise
     */
    public boolean generateReport(String reportType) {
        // In a real implementation, this would generate a report
        // For now, we'll just log the action and return true
        logger.log(Level.INFO, "Admin '{0}' generated {1} report",
                new Object[]{getUsername(), reportType});

        return true;
    }
}