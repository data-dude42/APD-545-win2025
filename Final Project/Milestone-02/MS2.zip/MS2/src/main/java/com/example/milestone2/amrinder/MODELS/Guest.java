package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

/**
 * Model class for Guest information
 */
public class Guest {
    private final IntegerProperty guestID;
    private final StringProperty name;
    private final StringProperty phoneNumber;
    private final StringProperty email;
    private final StringProperty address;
    private final StringProperty feedback;

    /**
     * Constructor for Guest class
     * @param guestID Unique identifier for the guest
     * @param name Guest's full name
     * @param phoneNumber Guest's contact phone number
     * @param email Guest's email address
     * @param address Guest's physical address
     */
    public Guest(int guestID, String name, String phoneNumber, String email, String address) {
        this.guestID = new SimpleIntegerProperty(guestID);
        this.name = new SimpleStringProperty(name);
        this.phoneNumber = new SimpleStringProperty(phoneNumber);
        this.email = new SimpleStringProperty(email);
        this.address = new SimpleStringProperty(address);
        this.feedback = new SimpleStringProperty("");
    }

    // Getters and Setters
    public int getGuestID() {
        return guestID.get();
    }

    public IntegerProperty guestIDProperty() {
        return guestID;
    }

    public void setGuestID(int guestID) {
        this.guestID.set(guestID);
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getPhoneNumber() {
        return phoneNumber.get();
    }

    public StringProperty phoneNumberProperty() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber.set(phoneNumber);
    }

    public String getEmail() {
        return email.get();
    }

    public StringProperty emailProperty() {
        return email;
    }

    public void setEmail(String email) {
        this.email.set(email);
    }

    public String getAddress() {
        return address.get();
    }

    public StringProperty addressProperty() {
        return address;
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public String getFeedback() {
        return feedback.get();
    }

    public StringProperty feedbackProperty() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback.set(feedback);
    }

    /**
     * Gets all guest details as a formatted string
     * @return String containing all guest information
     */
    public String getGuestDetails() {
        return "Guest ID: " + getGuestID() +
                "\nName: " + getName() +
                "\nPhone: " + getPhoneNumber() +
                "\nEmail: " + getEmail() +
                "\nAddress: " + getAddress();
    }

    /**
     * Sets guest details
     * @param name Guest's full name
     * @param phoneNumber Guest's contact phone number
     * @param email Guest's email address
     * @param address Guest's physical address
     */
    public void setGuestDetails(String name, String phoneNumber, String email, String address) {
        setName(name);
        setPhoneNumber(phoneNumber);
        setEmail(email);
        setAddress(address);
    }

    /**
     * Validates guest details for proper format and required fields
     * @return true if all details are valid, false otherwise
     */
    public boolean validateGuestDetails() {
        // Basic validation rules
        boolean nameValid = name.get() != null && !name.get().trim().isEmpty();
        boolean phoneValid = phoneNumber.get() != null && phoneNumber.get().matches("\\d{10}"); // Simple 10-digit check
        boolean emailValid = email.get() != null && email.get().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$"); // Basic email regex
        boolean addressValid = address.get() != null && !address.get().trim().isEmpty();

        return nameValid && phoneValid && emailValid && addressValid;
    }
}