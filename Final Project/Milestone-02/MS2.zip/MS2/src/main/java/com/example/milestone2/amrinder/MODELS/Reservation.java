package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Model class for Reservation information
 */
public class Reservation {
    private final IntegerProperty reservationID;
    private final IntegerProperty guestID;
    private final IntegerProperty roomID;
    private final ObjectProperty<LocalDate> checkInDate;
    private final ObjectProperty<LocalDate> checkOutDate;
    private final IntegerProperty numberOfGuests;
    private final StringProperty status; // Confirmed, Cancelled, CheckedOut

    /**
     * Constructor for Reservation class
     * @param reservationID Unique identifier for the reservation
     * @param guestID ID of the guest making the reservation
     * @param roomID ID of the room being reserved
     * @param checkInDate Date of check-in
     * @param checkOutDate Date of check-out
     * @param numberOfGuests Number of guests in the reservation
     * @param status Current status of the reservation
     */
    public Reservation(int reservationID, int guestID, int roomID, LocalDate checkInDate,
                       LocalDate checkOutDate, int numberOfGuests, String status) {
        this.reservationID = new SimpleIntegerProperty(reservationID);
        this.guestID = new SimpleIntegerProperty(guestID);
        this.roomID = new SimpleIntegerProperty(roomID);
        this.checkInDate = new SimpleObjectProperty<>(checkInDate);
        this.checkOutDate = new SimpleObjectProperty<>(checkOutDate);
        this.numberOfGuests = new SimpleIntegerProperty(numberOfGuests);
        this.status = new SimpleStringProperty(status);
    }

    // Getters and Setters
    public int getReservationID() {
        return reservationID.get();
    }

    public IntegerProperty reservationIDProperty() {
        return reservationID;
    }

    public void setReservationID(int reservationID) {
        this.reservationID.set(reservationID);
    }

    public int getGuestID() {
        return guestID.get();
    }

    public IntegerProperty guestIDProperty() {
        return guestID;
    }

    public void setGuestID(int guestID) {
        this.guestID.set(guestID);
    }

    public int getRoomID() {
        return roomID.get();
    }

    public IntegerProperty roomIDProperty() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID.set(roomID);
    }

    public LocalDate getCheckInDate() {
        return checkInDate.get();
    }

    public ObjectProperty<LocalDate> checkInDateProperty() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate.set(checkInDate);
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate.get();
    }

    public ObjectProperty<LocalDate> checkOutDateProperty() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate.set(checkOutDate);
    }

    public int getNumberOfGuests() {
        return numberOfGuests.get();
    }

    public IntegerProperty numberOfGuestsProperty() {
        return numberOfGuests;
    }

    public void setNumberOfGuests(int numberOfGuests) {
        this.numberOfGuests.set(numberOfGuests);
    }

    public String getStatus() {
        return status.get();
    }

    public StringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    /**
     * Creates a new reservation
     * @return true if reservation is successfully created, false otherwise
     */
    public boolean createReservation() {
        // In a real implementation, this would interact with a database
        // For now, we'll just return true to indicate success
        return true;
    }

    /**
     * Cancels an existing reservation
     * @return true if reservation is successfully cancelled, false otherwise
     */
    public boolean cancelReservation() {
        if (!"Cancelled".equals(getStatus())) {
            setStatus("Cancelled");
            return true;
        }
        return false;
    }

    /**
     * Gets all reservation details as a formatted string
     * @return String containing all reservation information
     */
    public String getReservationDetails() {
        return "Reservation ID: " + getReservationID() +
                "\nGuest ID: " + getGuestID() +
                "\nRoom ID: " + getRoomID() +
                "\nCheck-in Date: " + getCheckInDate() +
                "\nCheck-out Date: " + getCheckOutDate() +
                "\nNumber of Guests: " + getNumberOfGuests() +
                "\nStatus: " + getStatus();
    }

    /**
     * Confirms the reservation
     * @return true if reservation is successfully confirmed, false otherwise
     */
    public boolean confirmReservation() {
        if (!"Confirmed".equals(getStatus())) {
            setStatus("Confirmed");
            return true;
        }
        return false;
    }

    /**
     * Calculate the total number of nights for this reservation
     * @return number of nights
     */
    public long calculateNumberOfNights() {
        return ChronoUnit.DAYS.between(checkInDate.get(), checkOutDate.get());
    }
}