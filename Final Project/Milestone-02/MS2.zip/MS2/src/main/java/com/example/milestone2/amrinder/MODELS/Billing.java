package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

/**
 * Model class for Billing information
 */
public class Billing {
    private final IntegerProperty billID;
    private final IntegerProperty reservationID;
    private final DoubleProperty amount;
    private final DoubleProperty tax;
    private final DoubleProperty totalAmount;
    private final DoubleProperty discount;

    // Tax rate constant
    private static final double TAX_RATE = 0.13; // 13% tax rate

    /**
     * Constructor for Billing class
     * @param billID Unique identifier for the bill
     * @param reservationID ID of the associated reservation
     * @param amount Base amount before tax and discount
     * @param discount Discount amount applied to the bill
     */
    public Billing(int billID, int reservationID, double amount, double discount) {
        this.billID = new SimpleIntegerProperty(billID);
        this.reservationID = new SimpleIntegerProperty(reservationID);
        this.amount = new SimpleDoubleProperty(amount);
        this.discount = new SimpleDoubleProperty(discount);

        // Calculate tax and total
        this.tax = new SimpleDoubleProperty(calculateTax(amount));
        this.totalAmount = new SimpleDoubleProperty(calculateTotal(amount, calculateTax(amount), discount));
    }

    // Getters and Setters
    public int getBillID() {
        return billID.get();
    }

    public IntegerProperty billIDProperty() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID.set(billID);
    }

    public int getReservationID() {
        return reservationID.get();
    }

    public IntegerProperty reservationIDProperty() {
        return reservationID;
    }

    public void setReservationID(int reservationID) {
        this.reservationID.set(reservationID);
    }

    public double getAmount() {
        return amount.get();
    }

    public DoubleProperty amountProperty() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount.set(amount);
        // Recalculate tax and total when amount changes
        setTax(calculateTax(amount));
        setTotalAmount(calculateTotal(amount, getTax(), getDiscount()));
    }

    public double getTax() {
        return tax.get();
    }

    public DoubleProperty taxProperty() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax.set(tax);
    }

    public double getTotalAmount() {
        return totalAmount.get();
    }

    public DoubleProperty totalAmountProperty() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount.set(totalAmount);
    }

    public double getDiscount() {
        return discount.get();
    }

    public DoubleProperty discountProperty() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount.set(discount);
        // Recalculate total when discount changes
        setTotalAmount(calculateTotal(getAmount(), getTax(), discount));
    }

    /**
     * Generates a bill for the reservation
     * @return true if bill is successfully generated, false otherwise
     */
    public boolean generateBill() {
        // In a real implementation, this would interact with a database
        // For now, we'll just return true to indicate success
        return true;
    }

    /**
     * Applies a discount to the bill
     * @param discountAmount Amount of discount to apply
     * @return true if discount is successfully applied, false otherwise
     */
    public boolean applyDiscount(double discountAmount) {
        if (discountAmount >= 0 && discountAmount <= getAmount()) {
            setDiscount(discountAmount);
            return true;
        }
        return false;
    }

    /**
     * Calculates the tax amount based on the base amount
     * @param baseAmount Amount before tax
     * @return Calculated tax amount
     */
    private double calculateTax(double baseAmount) {
        return baseAmount * TAX_RATE;
    }

    /**
     * Calculates the total amount after tax and discount
     * @param baseAmount Amount before tax and discount
     * @param taxAmount Tax amount
     * @param discountAmount Discount amount
     * @return Total amount after tax and discount
     */
    private double calculateTotal(double baseAmount, double taxAmount, double discountAmount) {
        return baseAmount + taxAmount - discountAmount;
    }

    /**
     * Prints the bill details
     * @return true if bill is successfully printed, false otherwise
     */
    public boolean printBill() {
        // In a real implementation, this would print the bill
        // For now, we'll just return true to indicate success
        return true;
    }

    /**
     * Gets a formatted string with all bill details
     * @return String with formatted bill details
     */
    public String getBillDetails() {
        return String.format(
                "Bill ID: %d\n" +
                        "Reservation ID: %d\n" +
                        "Base Amount: $%.2f\n" +
                        "Tax (%.0f%%): $%.2f\n" +
                        "Discount: $%.2f\n" +
                        "Total Amount: $%.2f",
                getBillID(),
                getReservationID(),
                getAmount(),
                TAX_RATE * 100,
                getTax(),
                getDiscount(),
                getTotalAmount()
        );
    }
}