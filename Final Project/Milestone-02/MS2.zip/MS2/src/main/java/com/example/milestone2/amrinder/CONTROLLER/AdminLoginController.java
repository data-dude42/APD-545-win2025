package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.HelloApplication;
import com.example.milestone2.amrinder.DB.Admin;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Level;

/**
 * Controller for the admin login view
 */
public class AdminLoginController {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Button backButton;

    @FXML
    private Label errorMessageLabel;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        errorMessageLabel.setVisible(false);
    }

    /**
     * Handles the login button click event
     * @param event The action event
     */
    @FXML
    private void handleLoginButton(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            showError("Please enter both username and password");
            return;
        }

        // Attempt to login
        com.example.milestone2.amrinder.MODELS.Admin admin = Admin.validateAdmin(username, password);

        if (admin != null) {
            try {
                LoggerUtil.getLogger().info("Admin login successful: " + username);

                // Load the admin dashboard view
                FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/admin_Dashboard.fxml"));
                Scene scene = new Scene(loader.load(), 800, 600);

                // Pass the admin to the dashboard controller
                AdminDashboardController dashboardController = loader.getController();
                dashboardController.setAdmin(admin);

                // Get the stage from the event source
                Stage stage = (Stage) loginButton.getScene().getWindow();

                // Set the new scene
                stage.setTitle("Mandarin Oriental - Admin Dashboard");
                stage.setScene(scene);
                stage.show();

            } catch (IOException e) {
                LoggerUtil.logException(Level.SEVERE, "Error loading admin dashboard view", e);
                e.printStackTrace();
                showError("Error loading admin dashboard");
            }
        } else {
            showError("Invalid username or password");
        }
    }

    /**
     * Handles the back button click event
     * @param event The action event
     */
    @FXML
    private void handleBackButton(ActionEvent event) {
        try {
            // Load the main view
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            // Get the stage from the event source
            Stage stage = (Stage) backButton.getScene().getWindow();

            // Set the new scene
            stage.setTitle("Mandarin Oriental");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
            e.printStackTrace();
        }
    }

    /**
     * Shows an error message
     * @param message Message to display
     */
    private void showError(String message) {
        errorMessageLabel.setText(message);
        errorMessageLabel.setVisible(true);
    }
}