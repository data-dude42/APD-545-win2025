package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

/**
 * Model class for Guest Feedback information
 */
public class Feedback {
    private final IntegerProperty feedbackID;
    private final IntegerProperty guestID;
    private final IntegerProperty reservationID;
    private final StringProperty comments;
    private final DoubleProperty rating;

    /**
     * Constructor for Feedback class
     * @param feedbackID Unique identifier for the feedback
     * @param guestID ID of the guest providing the feedback
     * @param reservationID ID of the reservation the feedback is for
     * @param comments Text comments from the guest
     * @param rating Numerical rating from the guest (typically 1-5)
     */
    public Feedback(int feedbackID, int guestID, int reservationID, String comments, double rating) {
        this.feedbackID = new SimpleIntegerProperty(feedbackID);
        this.guestID = new SimpleIntegerProperty(guestID);
        this.reservationID = new SimpleIntegerProperty(reservationID);
        this.comments = new SimpleStringProperty(comments);
        this.rating = new SimpleDoubleProperty(rating);
    }

    // Getters and Setters
    public int getFeedbackID() {
        return feedbackID.get();
    }

    public IntegerProperty feedbackIDProperty() {
        return feedbackID;
    }

    public void setFeedbackID(int feedbackID) {
        this.feedbackID.set(feedbackID);
    }

    public int getGuestID() {
        return guestID.get();
    }

    public IntegerProperty guestIDProperty() {
        return guestID;
    }

    public void setGuestID(int guestID) {
        this.guestID.set(guestID);
    }

    public int getReservationID() {
        return reservationID.get();
    }

    public IntegerProperty reservationIDProperty() {
        return reservationID;
    }

    public void setReservationID(int reservationID) {
        this.reservationID.set(reservationID);
    }

    public String getComments() {
        return comments.get();
    }

    public StringProperty commentsProperty() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments.set(comments);
    }

    public double getRating() {
        return rating.get();
    }

    public DoubleProperty ratingProperty() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating.set(rating);
    }

    /**
     * Submits the feedback to the system
     * @return true if feedback is successfully submitted, false otherwise
     */
    public boolean submitFeedback() {
        // In a real implementation, this would submit to a database
        // For now, we'll just return true to indicate success
        return true;
    }

    /**
     * Gets all feedback details as a formatted string
     * @return String containing all feedback information
     */
    public String getFeedbackDetails() {
        return "Feedback ID: " + getFeedbackID() +
                "\nGuest ID: " + getGuestID() +
                "\nReservation ID: " + getReservationID() +
                "\nRating: " + getRating() +
                "\nComments: " + getComments();
    }}
