package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.DB.Feedback;
import com.example.milestone2.amrinder.DB.Guest;
import com.example.milestone2.amrinder.DB.Reservation;
import com.example.milestone2.amrinder.HelloApplication;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;

/**
 * Controller for the feedback form view
 */
public class FeedbackFormController {
    @FXML
    private TextField nameSearchField;

    @FXML
    private Button searchButton;

    @FXML
    private TableView<com.example.milestone2.amrinder.MODELS.Reservation> reservationsTableView;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Reservation, Integer> resIdColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Reservation, LocalDate> checkInColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Reservation, LocalDate> checkOutColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Reservation, String> statusColumn;

    @FXML
    private Button selectReservationButton;

    @FXML
    private TextArea commentsArea;

    @FXML
    private Slider ratingSlider;

    @FXML
    private Label ratingValueLabel;

    @FXML
    private Button submitFeedbackButton;

    @FXML
    private Button backButton;

    private com.example.milestone2.amrinder.MODELS.Reservation currentReservation;
    private com.example.milestone2.amrinder.MODELS.Guest currentGuest;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        // Setup table columns
        resIdColumn.setCellValueFactory(new PropertyValueFactory<>("reservationID"));
        checkInColumn.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));
        checkOutColumn.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Disable reservation selection until search is performed
        selectReservationButton.setDisable(true);

        // Disable feedback inputs until reservation is selected
        commentsArea.setDisable(true);
        ratingSlider.setDisable(true);
        submitFeedbackButton.setDisable(true);

        // Add listener to rating slider
        ratingSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            ratingValueLabel.setText(String.format("%.1f", newValue.doubleValue()));
        });

        // Add listener to table selection
        reservationsTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    selectReservationButton.setDisable(newValue == null);
                });
    }

    /**
     * Handles the search button click event
     * @param event The action event
     */
    @FXML
    private void handleSearchButton(ActionEvent event) {
        String guestName = nameSearchField.getText().trim();

        if (guestName.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Information",
                    "Please enter your name");
            return;
        }

        // Search for guest by name
        List<com.example.milestone2.amrinder.MODELS.Guest> guests = Guest.searchGuests(guestName);

        if (guests.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Guest Not Found",
                    "No guest found with name: " + guestName);
            reservationsTableView.getItems().clear();
            return;
        }

        // Get reservations for the first matching guest
        // In a real application, you might want to allow the user to select which guest
        // if multiple guests have the same name
        currentGuest = guests.get(0);
        List<com.example.milestone2.amrinder.MODELS.Reservation> reservations = Reservation.getReservationsByGuestID(currentGuest.getGuestID());

        if (reservations.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "No Reservations",
                    "No reservations found for " + currentGuest.getName());
            reservationsTableView.getItems().clear();
            return;
        }

        // Display reservations in the table
        reservationsTableView.setItems(FXCollections.observableArrayList(reservations));
    }

    /**
     * Handles the select reservation button click event
     * @param event The action event
     */
    @FXML
    private void handleSelectReservationButton(ActionEvent event) {
        currentReservation = reservationsTableView.getSelectionModel().getSelectedItem();

        if (currentReservation == null) {
            showAlert(Alert.AlertType.WARNING, "No Selection",
                    "Please select a reservation from the table");
            return;
        }

        // Check if reservation is checked out
        if (!"CheckedOut".equals(currentReservation.getStatus())) {
            showAlert(Alert.AlertType.WARNING, "Invalid Status",
                    "Feedback can only be provided for completed stays");
            return;
        }

        // Check if feedback already exists
        if (Feedback.feedbackExistsForReservation(currentReservation.getReservationID())) {
            showAlert(Alert.AlertType.INFORMATION, "Feedback Already Submitted",
                    "You have already submitted feedback for this reservation");
            return;
        }

        // Enable feedback inputs
        commentsArea.setDisable(false);
        ratingSlider.setDisable(false);
        submitFeedbackButton.setDisable(false);

        // Show confirmation
        showAlert(Alert.AlertType.INFORMATION, "Reservation Selected",
                "Thank you, " + currentGuest.getName() + ". Please provide your feedback for Reservation #" +
                        currentReservation.getReservationID() + " below.");
    }

    /**
     * Handles the submit feedback button click event
     * @param event The action event
     */
    @FXML
    private void handleSubmitFeedbackButton(ActionEvent event) {
        String comments = commentsArea.getText().trim();
        double rating = ratingSlider.getValue();

        if (comments.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Information",
                    "Please provide some comments about your stay");
            return;
        }

        // Create feedback
        com.example.milestone2.amrinder.MODELS.Feedback feedback = new com.example.milestone2.amrinder.MODELS.Feedback(0, currentGuest.getGuestID(),
                currentReservation.getReservationID(), comments, rating);

        // Submit feedback
        int feedbackId = Feedback.submitFeedback(feedback);

        if (feedbackId > 0) {
            showAlert(Alert.AlertType.INFORMATION, "Feedback Submitted",
                    "Thank you for your feedback! Your input helps us improve our services.");

            // Return to main screen
            try {
                FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
                Scene scene = new Scene(loader.load(), 800, 600);

                Stage stage = (Stage) submitFeedbackButton.getScene().getWindow();
                stage.setTitle("Mandarin Oriental Reservation System");
                stage.setScene(scene);
                stage.show();

            } catch (IOException e) {
                LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
                e.printStackTrace();
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Submission Failed",
                    "Failed to submit feedback. Please try again or contact staff for assistance.");
        }
    }

    /**
     * Handles the back button click event
     * @param event The action event
     */
    @FXML
    private void handleBackButton(ActionEvent event) {
        try {
            // Return to main screen
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setTitle("Mandarin Oriental");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
            e.printStackTrace();
        }
    }

    /**
     * Shows an alert dialog
     * @param type Alert type
     * @param title Alert title
     * @param message Alert message
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}