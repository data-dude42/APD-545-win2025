package com.example.milestone2.amrinder;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.logging.Level;

/**
 * Main application class for the Hotel Reservation System
 */
public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        try {
            // Initialize logger
            LoggerUtil.initializeLogger();
            LoggerUtil.getLogger().info("Application started");

            // Initialize database
            dbUtil.initializeDatabase();

            // Load main view - Updated path to match project structure
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 1000);
            stage.setTitle("Milestone-02 APD winter25");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            LoggerUtil.logException(Level.SEVERE, "Error starting application", e);
            e.printStackTrace();
        }
    }

    /**
     * Main method to launch the application
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        launch();
    }
}