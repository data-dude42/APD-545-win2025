package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Guest-related database operations
 */
public class Guest {
    private static final Logger logger = Logger.getLogger(Guest.class.getName());

    /**
     * Adds a new guest to the database
     *
     * @param guest Guest object to add
     * @return ID of the newly created guest, or -1 if operation failed
     */
    public static int addGuest(com.example.milestone2.amrinder.MODELS.Guest guest) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int guestID = -1;

        try {
            conn = dbUtil.getConnection();
            String query = "INSERT INTO guest (name, phone_number, email, address) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, guest.getName());
            stmt.setString(2, guest.getPhoneNumber());
            stmt.setString(3, guest.getEmail());
            stmt.setString(4, guest.getAddress());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    guestID = rs.getInt(1);
                    logger.log(Level.INFO, "New guest added: {0}, ID: {1}", new Object[]{guest.getName(), guestID});
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error adding new guest", e);
            LoggerUtil.logException(Level.SEVERE, "Database error adding guest", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return guestID;
    }

    /**
     * Retrieves a guest by their ID
     *
     * @param guestID ID of the guest to retrieve
     * @return Guest object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Guest getGuestByID(int guestID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Guest guest = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM guest WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, guestID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                String name = rs.getString("name");
                String phoneNumber = rs.getString("phone_number");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String feedback = rs.getString("feedback");

                guest = new com.example.milestone2.amrinder.MODELS.Guest(guestID, name, phoneNumber, email, address);
                guest.setFeedback(feedback != null ? feedback : "");
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving guest by ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving guest", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return guest;
    }

    /**
     * Searches for guests by name or phone number
     *
     * @param searchTerm Name or phone number to search for
     * @return List of Guest objects matching the search criteria
     */
    public static List<com.example.milestone2.amrinder.MODELS.Guest> searchGuests(String searchTerm) {
        List<com.example.milestone2.amrinder.MODELS.Guest> guests = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM guest WHERE name LIKE ? OR phone_number LIKE ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setString(2, "%" + searchTerm + "%");

            rs = stmt.executeQuery();

            while (rs.next()) {
                int guestID = rs.getInt("guest_id");
                String name = rs.getString("name");
                String phoneNumber = rs.getString("phone_number");
                String email = rs.getString("email");
                String address = rs.getString("address");
                String feedback = rs.getString("feedback");

                com.example.milestone2.amrinder.MODELS.Guest guest = new com.example.milestone2.amrinder.MODELS.Guest(guestID, name, phoneNumber, email, address);
                guest.setFeedback(feedback != null ? feedback : "");
                guests.add(guest);
            }

            LoggerUtil.logAdminActivity("System", "searched for guests", "term: " + searchTerm + ", found: " + guests.size());

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error searching for guests", e);
            LoggerUtil.logException(Level.SEVERE, "Database error searching guests", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return guests;
    }

    /**
     * Updates an existing guest in the database
     *
     * @param guest Guest object with updated information
     * @return true if guest is successfully updated, false otherwise
     */
    public static boolean updateGuest(com.example.milestone2.amrinder.MODELS.Guest guest) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "UPDATE guest SET name = ?, phone_number = ?, email = ?, address = ?, feedback = ? WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, guest.getName());
            stmt.setString(2, guest.getPhoneNumber());
            stmt.setString(3, guest.getEmail());
            stmt.setString(4, guest.getAddress());
            stmt.setString(5, guest.getFeedback());
            stmt.setInt(6, guest.getGuestID());

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Guest updated: {0}", guest.getName());
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating guest", e);
            LoggerUtil.logException(Level.SEVERE, "Database error updating guest", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Deletes a guest from the database
     *
     * @param guestID ID of the guest to delete
     * @return true if guest is successfully deleted, false otherwise
     */
    public static boolean deleteGuest(int guestID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "DELETE FROM guest WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, guestID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Guest deleted: ID {0}", guestID);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error deleting guest", e);
            LoggerUtil.logException(Level.SEVERE, "Database error deleting guest", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }
}