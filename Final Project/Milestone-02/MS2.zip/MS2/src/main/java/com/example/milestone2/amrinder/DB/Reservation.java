package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Reservation-related database operations
 */
public class Reservation {
    private static final Logger logger = Logger.getLogger(Reservation.class.getName());

    /**
     * Creates a new reservation in the database
     * @param reservation Reservation object to add
     * @return ID of the newly created reservation, or -1 if operation failed
     */
    public static int createReservation(com.example.milestone2.amrinder.MODELS.Reservation reservation) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int reservationID = -1;

        try {
            conn = dbUtil.getConnection();
            String query = "INSERT INTO reservation (guest_id, room_id, check_in_date, check_out_date, number_of_guests, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, reservation.getGuestID());
            stmt.setInt(2, reservation.getRoomID());
            stmt.setDate(3, Date.valueOf(reservation.getCheckInDate()));
            stmt.setDate(4, Date.valueOf(reservation.getCheckOutDate()));
            stmt.setInt(5, reservation.getNumberOfGuests());
            stmt.setString(6, reservation.getStatus());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    reservationID = rs.getInt(1);
                    logger.log(Level.INFO, "New reservation created: ID {0}, Guest ID {1}, Room ID {2}",
                            new Object[]{reservationID, reservation.getGuestID(), reservation.getRoomID()});

                    // Update room status to Occupied
                    Room.updateRoomStatus(reservation.getRoomID(), "Occupied");
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error creating reservation", e);
            LoggerUtil.logException(Level.SEVERE, "Database error creating reservation", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return reservationID;
    }

    /**
     * Retrieves a reservation by its ID
     * @param reservationID ID of the reservation to retrieve
     * @return Reservation object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Reservation getReservationByID(int reservationID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Reservation reservation = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM reservation WHERE reservation_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, reservationID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int guestID = rs.getInt("guest_id");
                int roomID = rs.getInt("room_id");
                LocalDate checkInDate = rs.getDate("check_in_date").toLocalDate();
                LocalDate checkOutDate = rs.getDate("check_out_date").toLocalDate();
                int numberOfGuests = rs.getInt("number_of_guests");
                String status = rs.getString("status");

                reservation = new com.example.milestone2.amrinder.MODELS.Reservation(reservationID, guestID, roomID, checkInDate, checkOutDate, numberOfGuests, status);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving reservation by ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving reservation", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return reservation;
    }

    /**
     * Retrieves all reservations for a specific guest
     * @param guestID ID of the guest
     * @return List of Reservation objects for the guest
     */
    public static List<com.example.milestone2.amrinder.MODELS.Reservation> getReservationsByGuestID(int guestID) {
        List<com.example.milestone2.amrinder.MODELS.Reservation> reservations = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM reservation WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, guestID);

            rs = stmt.executeQuery();

            while (rs.next()) {
                int reservationID = rs.getInt("reservation_id");
                int roomID = rs.getInt("room_id");
                LocalDate checkInDate = rs.getDate("check_in_date").toLocalDate();
                LocalDate checkOutDate = rs.getDate("check_out_date").toLocalDate();
                int numberOfGuests = rs.getInt("number_of_guests");
                String status = rs.getString("status");

                com.example.milestone2.amrinder.MODELS.Reservation reservation = new com.example.milestone2.amrinder.MODELS.Reservation(reservationID, guestID, roomID, checkInDate, checkOutDate, numberOfGuests, status);
                reservations.add(reservation);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving reservations by guest ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving reservations", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return reservations;
    }

    /**
     * Updates the status of a reservation
     * @param reservationID ID of the reservation to update
     * @param status New status for the reservation
     * @return true if reservation status is successfully updated, false otherwise
     */
    public static boolean updateReservationStatus(int reservationID, String status) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();

            // First get the current reservation to know the room ID
            com.example.milestone2.amrinder.MODELS.Reservation currentReservation = getReservationByID(reservationID);
            if (currentReservation == null) {
                return false;
            }

            // Update reservation status
            String query = "UPDATE reservation SET status = ? WHERE reservation_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, status);
            stmt.setInt(2, reservationID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Reservation {0} status updated to: {1}", new Object[]{reservationID, status});

                // If reservation is cancelled or checked out, make the room available again
                if ("Cancelled".equals(status) || "CheckedOut".equals(status)) {
                    Room.updateRoomStatus(currentReservation.getRoomID(), "Available");
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating reservation status", e);
            LoggerUtil.logException(Level.SEVERE, "Database error updating reservation status", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Cancels a reservation
     * @param reservationID ID of the reservation to cancel
     * @return true if reservation is successfully cancelled, false otherwise
     */
    public static boolean cancelReservation(int reservationID) {
        return updateReservationStatus(reservationID, "Cancelled");
    }

    /**
     * Checks out a guest from their reservation
     * @param reservationID ID of the reservation to check out
     * @return true if check-out is successful, false otherwise
     */
    public static boolean checkOutReservation(int reservationID) {
        return updateReservationStatus(reservationID, "CheckedOut");
    }

    /**
     * Confirms a reservation
     * @param reservationID ID of the reservation to confirm
     * @return true if confirmation is successful, false otherwise
     */
    public static boolean confirmReservation(int reservationID) {
        return updateReservationStatus(reservationID, "Confirmed");
    }
}