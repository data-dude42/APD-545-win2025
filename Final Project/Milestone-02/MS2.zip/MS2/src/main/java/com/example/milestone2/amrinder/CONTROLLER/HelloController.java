package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.HelloApplication;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.logging.Level;

/**
 * Controller for the main view
 */
public class HelloController {
    @FXML
    private Label welcomeLabel;

    @FXML
    private Button kioskButton;

    @FXML
    private Button adminLoginButton;

    @FXML
    private Button feedbackButton;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        welcomeLabel.setText("Mandarin Oriental");
    }

    /**
     * Handles the kiosk button click event
     * @param event The action event
     */
    @FXML
    private void handleKioskButton(ActionEvent event) {
        try {
            LoggerUtil.getLogger().info("Kiosk mode selected");

            // Load the kiosk booking view
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/kiosk_Booking.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            // Get the stage from the event source
            Stage stage = (Stage) kioskButton.getScene().getWindow();

            // Set the new scene
            stage.setTitle("Mandarin Oriental - Self-Service Kiosk");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading kiosk view", e);
            e.printStackTrace();
        }
    }

    /**
     * Handles the admin login button click event
     * @param event The action event
     */
    @FXML
    private void handleAdminLoginButton(ActionEvent event) {
        try {
            LoggerUtil.getLogger().info("Admin login selected");

            // Load the admin login view
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/admin_Login.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            // Get the stage from the event source
            Stage stage = (Stage) adminLoginButton.getScene().getWindow();

            // Set the new scene
            stage.setTitle("Mandarin Oriental - Admin Login");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading admin login view", e);
            e.printStackTrace();
        }
    }

    /**
     * Handles the feedback button click event
     * @param event The action event
     */
    @FXML
    private void handleFeedbackButton(ActionEvent event) {
        try {
            LoggerUtil.getLogger().info("Feedback form selected");

            // Load the feedback form view
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/feedback_Form.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            // Get the stage from the event source
            Stage stage = (Stage) feedbackButton.getScene().getWindow();

            // Set the new scene
            stage.setTitle("Mandarin Oriental - Feedback Form");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading feedback form view", e);
            e.printStackTrace();
        }
    }
}