package com.example.milestone2.amrinder.MODELS;

/**
 * Enum representing different types of rooms available in the hotel
 */
public enum RoomType {
    SINGLE("Single", 100.0, 2),
    DOUBLE("Double", 180.0, 4),
    DELUXE("Deluxe", 250.0, 2),
    PENT_HOUSE("Pent House", 500.0, 2);

    private final String displayName;
    private final double basePrice;
    private final int maxOccupancy;

    /**
     * Constructor for RoomType enum
     * @param displayName Name to be displayed in UI
     * @param basePrice Base price of the room per night
     * @param maxOccupancy Maximum number of guests allowed in this room type
     */
    RoomType(String displayName, double basePrice, int maxOccupancy) {
        this.displayName = displayName;
        this.basePrice = basePrice;
        this.maxOccupancy = maxOccupancy;
    }

    /**
     * @return Display name for the room type
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * @return Base price for the room type per night
     */
    public double getBasePrice() {
        return basePrice;
    }

    /**
     * @return Maximum number of guests this room type can accommodate
     */
    public int getMaxOccupancy() {
        return maxOccupancy;
    }

    @Override
    public String toString() {
        return displayName;
    }
}