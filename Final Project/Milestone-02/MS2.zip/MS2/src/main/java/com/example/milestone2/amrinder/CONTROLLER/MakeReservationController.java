package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.DB.Billing;
import com.example.milestone2.amrinder.DB.Guest;
import com.example.milestone2.amrinder.DB.Reservation;
import com.example.milestone2.amrinder.DB.Room;
import com.example.milestone2.amrinder.MODELS.Admin;
import com.example.milestone2.amrinder.MODELS.RoomType;
import com.example.ms2.models.*;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

/**
 * Controller for the make reservation view (used by admin)
 */
public class MakeReservationController {
    @FXML
    private ComboBox<com.example.milestone2.amrinder.MODELS.Guest> guestComboBox;

    @FXML
    private Button searchGuestButton;

    @FXML
    private TextField searchGuestField;

    @FXML
    private TableView<com.example.milestone2.amrinder.MODELS.Guest> guestTableView;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, Integer> guestIdColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, String> guestNameColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, String> guestPhoneColumn;

    @FXML
    private TextField numberOfGuestsField;

    @FXML
    private DatePicker checkInDatePicker;

    @FXML
    private DatePicker checkOutDatePicker;

    @FXML
    private ComboBox<RoomType> roomTypeComboBox;

    @FXML
    private TableView<com.example.milestone2.amrinder.MODELS.Room> availableRoomsTableView;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, Integer> roomIdColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, RoomType> roomTypeColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, Double> roomPriceColumn;

    @FXML
    private Button createReservationButton;

    @FXML
    private Button cancelButton;

    private Admin currentAdmin;
    private com.example.milestone2.amrinder.MODELS.Guest selectedGuest;
    private com.example.milestone2.amrinder.MODELS.Room selectedRoom;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        // Initialize guest table columns
        guestIdColumn.setCellValueFactory(new PropertyValueFactory<>("guestID"));
        guestNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        guestPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));

        // Initialize available rooms table columns
        roomIdColumn.setCellValueFactory(new PropertyValueFactory<>("roomID"));
        roomTypeColumn.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Initialize room type combo box
        roomTypeComboBox.getItems().setAll(RoomType.values());

        // Initialize date pickers with default values
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));

        // Add listener to guest table selection
        guestTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        selectedGuest = newValue;
                        // Add guest to combo box if not already there
                        if (!guestComboBox.getItems().contains(selectedGuest)) {
                            guestComboBox.getItems().add(selectedGuest);
                        }
                        guestComboBox.setValue(selectedGuest);
                    }
                });

        // Add listener to available rooms table selection
        availableRoomsTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        selectedRoom = newValue;
                        createReservationButton.setDisable(false);
                    }
                });

        // Add listener to room type combo box
        roomTypeComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && checkInDatePicker.getValue() != null && checkOutDatePicker.getValue() != null) {
                loadAvailableRooms();
            }
        });

        // Add listeners to date pickers
        checkInDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && roomTypeComboBox.getValue() != null) {
                // Ensure check-out date is after check-in date
                if (checkOutDatePicker.getValue().isBefore(newValue)) {
                    checkOutDatePicker.setValue(newValue.plusDays(1));
                }
                loadAvailableRooms();
            }
        });

        checkOutDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && roomTypeComboBox.getValue() != null) {
                // Ensure check-out date is after check-in date
                if (newValue.isBefore(checkInDatePicker.getValue())) {
                    showAlert(Alert.AlertType.WARNING, "Invalid Date",
                            "Check-out date cannot be before check-in date.");
                    checkOutDatePicker.setValue(oldValue);
                } else {
                    loadAvailableRooms();
                }
            }
        });

        // Disable create reservation button until a room is selected
        createReservationButton.setDisable(true);
    }

    /**
     * Sets the admin for this controller
     * @param admin Admin making the reservation
     */
    public void setAdmin(Admin admin) {
        this.currentAdmin = admin;
    }

    /**
     * Handles the search guest button click event
     * @param event The action event
     */
    @FXML
    private void handleSearchGuestButton(ActionEvent event) {
        String searchTerm = searchGuestField.getText().trim();

        if (searchTerm.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Empty Search", "Please enter a search term");
            return;
        }

        List<com.example.milestone2.amrinder.MODELS.Guest> guests = Guest.searchGuests(searchTerm);

        if (guests.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "No Results",
                    "No guests found matching '" + searchTerm + "'");
        } else {
            guestTableView.setItems(FXCollections.observableArrayList(guests));
        }
    }

    /**
     * Loads available rooms based on selected criteria
     */
    private void loadAvailableRooms() {
        RoomType roomType = roomTypeComboBox.getValue();
        LocalDate checkInDate = checkInDatePicker.getValue();
        LocalDate checkOutDate = checkOutDatePicker.getValue();

        if (roomType == null || checkInDate == null || checkOutDate == null) {
            return;
        }

        List<com.example.milestone2.amrinder.MODELS.Room> availableRooms = Room.findAvailableRooms(roomType, checkInDate, checkOutDate);

        if (availableRooms.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "No Rooms Available",
                    "No " + roomType.getDisplayName() + " rooms available for the selected dates");
        }

        availableRoomsTableView.setItems(FXCollections.observableArrayList(availableRooms));
    }

    /**
     * Handles the create reservation button click event
     * @param event The action event
     */
    @FXML
    private void handleCreateReservationButton(ActionEvent event) {
        // Validate input
        if (guestComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "No Guest Selected", "Please select a guest");
            return;
        }

        if (selectedRoom == null) {
            showAlert(Alert.AlertType.WARNING, "No Room Selected", "Please select a room");
            return;
        }

        String numGuestsText = numberOfGuestsField.getText().trim();
        if (numGuestsText.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Information", "Please enter the number of guests");
            return;
        }

        int numberOfGuests;
        try {
            numberOfGuests = Integer.parseInt(numGuestsText);
            if (numberOfGuests <= 0) {
                throw new NumberFormatException("Number of guests must be positive");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Invalid Input", "Please enter a valid number of guests");
            return;
        }

        // Check if number of guests exceeds room capacity
        RoomType roomType = selectedRoom.getRoomType();
        if (numberOfGuests > roomType.getMaxOccupancy()) {
            showAlert(Alert.AlertType.WARNING, "Too Many Guests",
                    "The selected room can only accommodate " + roomType.getMaxOccupancy() + " guests");
            return;
        }

        // Create reservation
        com.example.milestone2.amrinder.MODELS.Guest guest = guestComboBox.getValue();
        LocalDate checkInDate = checkInDatePicker.getValue();
        LocalDate checkOutDate = checkOutDatePicker.getValue();

        com.example.milestone2.amrinder.MODELS.Reservation reservation = new com.example.milestone2.amrinder.MODELS.Reservation(0, guest.getGuestID(), selectedRoom.getRoomID(),
                checkInDate, checkOutDate, numberOfGuests, "Confirmed");

        int reservationId = Reservation.createReservation(reservation);

        if (reservationId > 0) {
            // Generate bill
            int billId = Billing.generateBillForReservation(reservationId);

            if (billId > 0) {
                // Log the activity
                LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "created reservation",
                        "ID: " + reservationId + " for guest: " + guest.getName());

                showAlert(Alert.AlertType.INFORMATION, "Reservation Created",
                        "Reservation created successfully with ID: " + reservationId +
                                "\nBill generated with ID: " + billId);

                // Close the window
                ((Stage) createReservationButton.getScene().getWindow()).close();
            } else {
                showAlert(Alert.AlertType.ERROR, "Bill Creation Failed",
                        "Reservation created but failed to generate bill");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Reservation Failed",
                    "Failed to create reservation");
        }
    }

    /**
     * Handles the cancel button click event
     * @param event The action event
     */
    @FXML
    private void handleCancelButton(ActionEvent event) {
        // Close the window
        ((Stage) cancelButton.getScene().getWindow()).close();
    }

    /**
     * Shows an alert dialog
     * @param type Alert type
     * @param title Alert title
     * @param message Alert message
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}