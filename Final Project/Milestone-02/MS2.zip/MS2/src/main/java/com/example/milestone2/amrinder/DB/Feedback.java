package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Feedback-related database operations
 */
public class Feedback {
    private static final Logger logger = Logger.getLogger(Feedback.class.getName());

    /**
     * Submits new feedback to the database
     * @param feedback Feedback object to add
     * @return ID of the newly created feedback, or -1 if operation failed
     */
    public static int submitFeedback(com.example.milestone2.amrinder.MODELS.Feedback feedback) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int feedbackID = -1;

        try {
            conn = dbUtil.getConnection();
            String query = "INSERT INTO feedback (guest_id, reservation_id, comments, rating) " +
                    "VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, feedback.getGuestID());
            stmt.setInt(2, feedback.getReservationID());
            stmt.setString(3, feedback.getComments());
            stmt.setDouble(4, feedback.getRating());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    feedbackID = rs.getInt(1);
                    logger.log(Level.INFO, "New feedback submitted: ID {0}, Guest ID {1}",
                            new Object[]{feedbackID, feedback.getGuestID()});

                    // Update guest's feedback in guest table
                    updateGuestFeedback(feedback.getGuestID(), feedback.getComments());
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error submitting feedback", e);
            LoggerUtil.logException(Level.SEVERE, "Database error submitting feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return feedbackID;
    }

    /**
     * Updates the feedback field for a guest
     * @param guestID ID of the guest
     * @param feedbackComment Comment to add to guest's feedback
     * @return true if update is successful, false otherwise
     */
    private static boolean updateGuestFeedback(int guestID, String feedbackComment) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "UPDATE guest SET feedback = ? WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, feedbackComment);
            stmt.setInt(2, guestID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating guest feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Retrieves feedback by its ID
     * @param feedbackID ID of the feedback to retrieve
     * @return Feedback object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Feedback getFeedbackByID(int feedbackID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Feedback feedback = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM feedback WHERE feedback_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, feedbackID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int guestID = rs.getInt("guest_id");
                int reservationID = rs.getInt("reservation_id");
                String comments = rs.getString("comments");
                double rating = rs.getDouble("rating");

                feedback = new com.example.milestone2.amrinder.MODELS.Feedback(feedbackID, guestID, reservationID, comments, rating);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving feedback by ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return feedback;
    }

    /**
     * Retrieves all feedback for a specific reservation
     * @param reservationID ID of the reservation
     * @return Feedback object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Feedback getFeedbackByReservationID(int reservationID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Feedback feedback = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM feedback WHERE reservation_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, reservationID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int feedbackID = rs.getInt("feedback_id");
                int guestID = rs.getInt("guest_id");
                String comments = rs.getString("comments");
                double rating = rs.getDouble("rating");

                feedback = new com.example.milestone2.amrinder.MODELS.Feedback(feedbackID, guestID, reservationID, comments, rating);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving feedback by reservation ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return feedback;
    }

    /**
     * Retrieves all feedback for a specific guest
     * @param guestID ID of the guest
     * @return List of Feedback objects for the guest
     */
    public static List<com.example.milestone2.amrinder.MODELS.Feedback> getFeedbackByGuestID(int guestID) {
        List<com.example.milestone2.amrinder.MODELS.Feedback> feedbackList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM feedback WHERE guest_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, guestID);

            rs = stmt.executeQuery();

            while (rs.next()) {
                int feedbackID = rs.getInt("feedback_id");
                int reservationID = rs.getInt("reservation_id");
                String comments = rs.getString("comments");
                double rating = rs.getDouble("rating");

                com.example.milestone2.amrinder.MODELS.Feedback feedback = new com.example.milestone2.amrinder.MODELS.Feedback(feedbackID, guestID, reservationID, comments, rating);
                feedbackList.add(feedback);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving feedback by guest ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return feedbackList;
    }

    /**
     * Checks if feedback exists for a specific reservation
     * @param reservationID ID of the reservation
     * @return true if feedback exists, false otherwise
     */
    public static boolean feedbackExistsForReservation(int reservationID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean exists = false;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT COUNT(*) FROM feedback WHERE reservation_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, reservationID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error checking if feedback exists", e);
            LoggerUtil.logException(Level.SEVERE, "Database error checking feedback", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return exists;
    }
}