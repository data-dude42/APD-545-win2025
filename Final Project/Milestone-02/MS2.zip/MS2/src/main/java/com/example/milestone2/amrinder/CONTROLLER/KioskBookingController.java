package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.DB.Billing;
import com.example.milestone2.amrinder.DB.Guest;
import com.example.milestone2.amrinder.DB.Reservation;
import com.example.milestone2.amrinder.DB.Room;
import com.example.milestone2.amrinder.HelloApplication;
import com.example.milestone2.amrinder.MODELS.RoomType;
import com.example.ms2.models.*;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;

/**
 * Controller for the kiosk booking view
 */
public class KioskBookingController {
    // Welcome step
    @FXML
    private VBox welcomeStep;

    @FXML
    private WebView welcomeVideoView;

    @FXML
    private Button startBookingButton;

    // Guest count step
    @FXML
    private VBox guestCountStep;

    @FXML
    private Spinner<Integer> guestCountSpinner;

    @FXML
    private Button guestCountNextButton;

    // Date selection step
    @FXML
    private VBox dateSelectionStep;

    @FXML
    private DatePicker checkInDatePicker;

    @FXML
    private DatePicker checkOutDatePicker;

    @FXML
    private Button dateSelectionNextButton;

    @FXML
    private Button dateSelectionBackButton;

    // Room selection step
    @FXML
    private VBox roomSelectionStep;

    @FXML
    private ListView<String> roomSuggestionsListView;

    @FXML
    private ComboBox<RoomType> roomTypeComboBox;

    @FXML
    private ListView<com.example.milestone2.amrinder.MODELS.Room> availableRoomsListView;

    @FXML
    private Button roomSelectionNextButton;

    @FXML
    private Button roomSelectionBackButton;

    // Guest details step
    @FXML
    private VBox guestDetailsStep;

    @FXML
    private TextField nameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField addressField;

    @FXML
    private Button guestDetailsNextButton;

    @FXML
    private Button guestDetailsBackButton;

    // Confirmation step
    @FXML
    private VBox confirmationStep;

    @FXML
    private TextArea bookingSummaryLabel;

    @FXML
    private TextArea estimatePriceLabel;

    @FXML
    private Button confirmBookingButton;

    @FXML
    private Button confirmationBackButton;

    // Success step
    @FXML
    private VBox successStep;

    @FXML
    private TextArea reservationIdLabel;

    @FXML
    private Button finishButton;

    // Rules button
    @FXML
    private Button rulesButton;

    // Home button
    @FXML
    private Button homeButton;

    // Tracking variables
    private int numberOfGuests;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private com.example.milestone2.amrinder.MODELS.Room selectedRoom;
    private com.example.milestone2.amrinder.MODELS.Guest newGuest;
    private int reservationId;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        // Initialize welcome step
        // In a real application, this would load a video showing how to use the kiosk

        // Initialize guest count spinner
        SpinnerValueFactory<Integer> valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 1);
        guestCountSpinner.setValueFactory(valueFactory);

        // Initialize date pickers
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));

        // Add listener to check-out date picker to ensure it's after check-in date
        checkOutDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.isBefore(checkInDatePicker.getValue())) {
                showAlert(Alert.AlertType.WARNING, "Invalid Date",
                        "Check-out date cannot be before check-in date.");
                checkOutDatePicker.setValue(oldValue);
            }
        });

        // Initialize room type combo box
        roomTypeComboBox.getItems().setAll(RoomType.values());

        // Setup custom cell factories for better display
        setupRoomSuggestionsListView();
        setupAvailableRoomsListView();

        // Show only welcome step initially
        showOnlyStep(welcomeStep);
    }

    /**
     * Sets up the cell factory for the room suggestions list view
     * to display suggestions with better formatting
     */
    private void setupRoomSuggestionsListView() {
        roomSuggestionsListView.setCellFactory(param -> new ListCell<String>() {
            @Override
            protected void updateItem(String suggestion, boolean empty) {
                super.updateItem(suggestion, empty);

                if (empty || suggestion == null) {
                    setText(null);
                } else {
                    setText(suggestion);
                    setStyle("-fx-text-fill: #f1c40f; -fx-font-size: 13px; -fx-padding: 3px 0px;");
                }
            }
        });
    }

    /**
     * Sets up the cell factory for the available rooms list view
     * to display room information in a more user-friendly format
     */
    private void setupAvailableRoomsListView() {
        availableRoomsListView.setCellFactory(param -> new ListCell<com.example.milestone2.amrinder.MODELS.Room>() {
            @Override
            protected void updateItem(com.example.milestone2.amrinder.MODELS.Room room, boolean empty) {
                super.updateItem(room, empty);

                if (empty || room == null) {
                    setText(null);
                    setStyle("-fx-text-fill: white;");
                } else {
                    // Format the room information in a clear, readable way
                    String roomInfo = String.format("Room %d - %s - $%.2f per night",
                            room.getRoomID(),
                            room.getRoomType().getDisplayName(),
                            room.getPrice());

                    setText(roomInfo);
                    setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 5px 0px;");
                }
            }
        });
    }

    /**
     * Handles the start booking button click event
     * @param event The action event
     */
    @FXML
    private void handleStartBookingButton(ActionEvent event) {
        showOnlyStep(guestCountStep);
    }

    /**
     * Handles the guest count next button click event
     * @param event The action event
     */
    @FXML
    private void handleGuestCountNextButton(ActionEvent event) {
        numberOfGuests = guestCountSpinner.getValue();
        showOnlyStep(dateSelectionStep);
    }

    /**
     * Handles the date selection next button click event
     * @param event The action event
     */
    @FXML
    private void handleDateSelectionNextButton(ActionEvent event) {
        checkInDate = checkInDatePicker.getValue();
        checkOutDate = checkOutDatePicker.getValue();

        // Get room suggestions based on guest count
        List<String> suggestions = Room.suggestRoomCombinations(numberOfGuests);
        roomSuggestionsListView.setItems(FXCollections.observableArrayList(suggestions));

        showOnlyStep(roomSelectionStep);
    }

    /**
     * Handles the date selection back button click event
     * @param event The action event
     */
    @FXML
    private void handleDateSelectionBackButton(ActionEvent event) {
        showOnlyStep(guestCountStep);
    }

    /**
     * Handles the room type selection event
     * @param event The action event
     */
    @FXML
    private void handleRoomTypeSelection(ActionEvent event) {
        RoomType selectedType = roomTypeComboBox.getValue();

        if (selectedType != null && checkInDate != null && checkOutDate != null) {
            // Find available rooms of the selected type
            List<com.example.milestone2.amrinder.MODELS.Room> availableRooms = Room.findAvailableRooms(selectedType, checkInDate, checkOutDate);

            if (availableRooms.isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "No Rooms Available",
                        "No " + selectedType.getDisplayName() + " rooms available for the selected dates");
                roomSelectionNextButton.setDisable(true);
            } else {
                availableRoomsListView.setItems(FXCollections.observableArrayList(availableRooms));

                // Add listener to room selection
                availableRoomsListView.getSelectionModel().selectedItemProperty().addListener(
                        (observable, oldValue, newValue) -> {
                            selectedRoom = newValue;
                            roomSelectionNextButton.setDisable(selectedRoom == null);
                        });
            }
        }
    }

    /**
     * Handles the room selection next button click event
     * @param event The action event
     */
    @FXML
    private void handleRoomSelectionNextButton(ActionEvent event) {
        if (selectedRoom == null) {
            showAlert(Alert.AlertType.WARNING, "No Room Selected", "Please select a room");
            return;
        }

        showOnlyStep(guestDetailsStep);
    }

    /**
     * Handles the room selection back button click event
     * @param event The action event
     */
    @FXML
    private void handleRoomSelectionBackButton(ActionEvent event) {
        showOnlyStep(dateSelectionStep);
    }

    /**
     * Handles the guest details next button click event
     * @param event The action event
     */
    @FXML
    private void handleGuestDetailsNextButton(ActionEvent event) {
        // Validate guest details
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || address.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Information",
                    "Please fill in all required fields");
            return;
        }

        // Validate phone format
        if (!phone.matches("\\d{10}")) {
            showAlert(Alert.AlertType.WARNING, "Invalid Phone",
                    "Phone number must be 10 digits");
            return;
        }

        // Validate email format
        if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            showAlert(Alert.AlertType.WARNING, "Invalid Email",
                    "Please enter a valid email address");
            return;
        }

        // Create guest object
        newGuest = new com.example.milestone2.amrinder.MODELS.Guest(0, name, phone, email, address);

        // Prepare booking summary
        StringBuilder summary = new StringBuilder();
        summary.append("Guest: ").append(name).append("\n");
        summary.append("Phone: ").append(phone).append("\n");
        summary.append("Email: ").append(email).append("\n");
        summary.append("Address: ").append(address).append("\n\n");

        summary.append("Check-In: ").append(checkInDate).append("\n");
        summary.append("Check-Out: ").append(checkOutDate).append("\n");
        summary.append("Number of Nights: ").append(checkOutDate.toEpochDay() - checkInDate.toEpochDay()).append("\n");
        summary.append("Number of Guests: ").append(numberOfGuests).append("\n\n");

        summary.append("Room Type: ").append(selectedRoom.getRoomType().getDisplayName()).append("\n");
        summary.append("Room Number: ").append(selectedRoom.getRoomID()).append("\n");

        bookingSummaryLabel.setText(summary.toString());

        // Calculate estimated price
        double basePrice = selectedRoom.getPrice() * (checkOutDate.toEpochDay() - checkInDate.toEpochDay());
        double tax = basePrice * 0.13; // 13% tax
        double totalPrice = basePrice + tax;

        estimatePriceLabel.setText(String.format(
                "Base Price: $%.2f\nTax (13%%): $%.2f\nTotal: $%.2f",
                basePrice, tax, totalPrice));

        showOnlyStep(confirmationStep);
    }

    /**
     * Handles the guest details back button click event
     * @param event The action event
     */
    @FXML
    private void handleGuestDetailsBackButton(ActionEvent event) {
        showOnlyStep(roomSelectionStep);
    }

    /**
     * Handles the confirm booking button click event
     * @param event The action event
     */
    @FXML
    private void handleConfirmBookingButton(ActionEvent event) {
        try {
            // Add guest to database
            int guestId = Guest.addGuest(newGuest);

            if (guestId > 0) {
                // Create reservation
                com.example.milestone2.amrinder.MODELS.Reservation reservation = new com.example.milestone2.amrinder.MODELS.Reservation(0, guestId, selectedRoom.getRoomID(),
                        checkInDate, checkOutDate, numberOfGuests, "Confirmed");

                reservationId = Reservation.createReservation(reservation);

                if (reservationId > 0) {
                    // Generate bill (won't be shown to guest, but will be available to admin)
                    Billing.generateBillForReservation(reservationId);

                    // Show success step
                    reservationIdLabel.setText("Your reservation has been confirmed!\n\n" +
                            "Reservation ID: " + reservationId + "\n\n" +
                            "Visit at reception during the day of your check in.");

                    showOnlyStep(successStep);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Reservation Failed",
                            "Failed to create reservation. Please try again or contact staff for assistance.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Registration Failed",
                        "Failed to register guest. Please try again or contact staff for assistance.");
            }
        } catch (Exception e) {
            LoggerUtil.logException(Level.SEVERE, "Error creating booking", e);
            showAlert(Alert.AlertType.ERROR, "Booking Error",
                    "An error occurred during booking. Please try again or contact staff for assistance.");
        }
    }

    /**
     * Handles the confirmation back button click event
     * @param event The action event
     */
    @FXML
    private void handleConfirmationBackButton(ActionEvent event) {
        showOnlyStep(guestDetailsStep);
    }

    /**
     * Handles the finish button click event
     * @param event The action event
     */
    @FXML
    private void handleFinishButton(ActionEvent event) {
        try {
            // Return to main screen
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            Stage stage = (Stage) finishButton.getScene().getWindow();
            stage.setTitle("Mandarin Oriental Reservation System");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
            e.printStackTrace();
        }
    }

    /**
     * Handles the rules button click event
     * @param event The action event
     */
    @FXML
    private void handleRulesButton(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Hotel Rules & Regulations");
        alert.setHeaderText("Important Information");

        StringBuilder rules = new StringBuilder();
        rules.append("• Single room: Max two people.\n");
        rules.append("• Double room: Max 4 people.\n");
        rules.append("• Deluxe and Pent rooms: Max two people but the prices are higher.\n");
        rules.append("• Check-in time is 3:00 PM and check-out time is 12:00 PM.\n");
        rules.append("• No smoking is allowed in any room or indoor area.\n");
        rules.append("• Pets are not allowed unless specifically booked in pet-friendly rooms.\n");
        rules.append("• Quiet hours are from 10:00 PM to 7:00 AM.\n");
        rules.append("• Cancellations must be made at least 24 hours before check-in to avoid charges.\n");
        rules.append("• The hotel is not responsible for any valuables left in rooms.\n");
        rules.append("• Any damage to hotel property will be charged to the guest.");

        alert.setContentText(rules.toString());
        alert.showAndWait();
    }

    /**
     * Handles the home button click event
     * @param event The action event
     */
    @FXML
    private void handleHomeButton(ActionEvent event) {
        try {
            // Return to main screen
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            Stage stage = (Stage) homeButton.getScene().getWindow();
            stage.setTitle("Mandarin Oriental Reservation System");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
            e.printStackTrace();
        }
    }

    /**
     * Shows only the specified step and hides all others
     * @param stepToShow The step to show
     */
    private void showOnlyStep(VBox stepToShow) {
        welcomeStep.setVisible(false);
        guestCountStep.setVisible(false);
        dateSelectionStep.setVisible(false);
        roomSelectionStep.setVisible(false);
        guestDetailsStep.setVisible(false);
        confirmationStep.setVisible(false);
        successStep.setVisible(false);

        stepToShow.setVisible(true);
    }

    /**
     * Shows an alert dialog
     * @param type Alert type
     * @param title Alert title
     * @param message Alert message
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}