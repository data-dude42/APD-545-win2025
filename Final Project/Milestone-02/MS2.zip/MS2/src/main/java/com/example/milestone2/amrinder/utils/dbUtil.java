package com.example.milestone2.amrinder.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utility class for database operations
 */
public class dbUtil {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "amrinderHanda"; // Set your MySQL password here

    private static final Logger logger = Logger.getLogger(dbUtil.class.getName());

    private static Connection connection = null;

    /**
     * Gets a connection to the database
     * @return Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                // Load MySQL JDBC Driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Create connection
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                logger.log(Level.INFO, "Database connection established successfully");
            } catch (ClassNotFoundException e) {
                logger.log(Level.SEVERE, "MySQL JDBC Driver not found", e);
                throw new SQLException("MySQL JDBC Driver not found", e);
            } catch (SQLException e) {
                logger.log(Level.SEVERE, "Failed to connect to database", e);
                throw e;
            }
        }
        return connection;
    }

    /**
     * Closes database resources
     * @param connection Database connection to close
     * @param statement Statement to close
     * @param resultSet ResultSet to close
     */
    public static void closeResources(Connection connection, Statement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null && connection != dbUtil.connection) {
                connection.close();
            }
        } catch (SQLException e) {
            logger.log(Level.WARNING, "Error closing database resources", e);
        }
    }

    /**
     * Executes a SQL query to create the initial database tables if they don't exist
     */
    public static void initializeDatabase() {
        Connection conn = null;
        Statement stmt = null;

        try {
            conn = getConnection();
            stmt = conn.createStatement();

            // Create Admin table
            stmt.execute("CREATE TABLE IF NOT EXISTS admin (" +
                    "admin_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "username VARCHAR(50) NOT NULL UNIQUE," +
                    "password VARCHAR(100) NOT NULL" +
                    ")");

            // Create Guest table
            stmt.execute("CREATE TABLE IF NOT EXISTS guest (" +
                    "guest_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "name VARCHAR(100) NOT NULL," +
                    "phone_number VARCHAR(20) NOT NULL," +
                    "email VARCHAR(100) NOT NULL," +
                    "address VARCHAR(255) NOT NULL," +
                    "feedback TEXT" +
                    ")");

            // Create Room table
            stmt.execute("CREATE TABLE IF NOT EXISTS room (" +
                    "room_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "room_type ENUM('SINGLE', 'DOUBLE', 'DELUXE', 'PENT_HOUSE') NOT NULL," +
                    "number_of_beds INT NOT NULL," +
                    "price DOUBLE NOT NULL," +
                    "status VARCHAR(20) NOT NULL DEFAULT 'Available'" +
                    ")");

            // Create Reservation table
            stmt.execute("CREATE TABLE IF NOT EXISTS reservation (" +
                    "reservation_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "guest_id INT NOT NULL," +
                    "room_id INT NOT NULL," +
                    "check_in_date DATE NOT NULL," +
                    "check_out_date DATE NOT NULL," +
                    "number_of_guests INT NOT NULL," +
                    "status VARCHAR(20) NOT NULL DEFAULT 'Confirmed'," +
                    "FOREIGN KEY (guest_id) REFERENCES guest(guest_id)," +
                    "FOREIGN KEY (room_id) REFERENCES room(room_id)" +
                    ")");

            // Create Billing table
            stmt.execute("CREATE TABLE IF NOT EXISTS billing (" +
                    "bill_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "reservation_id INT NOT NULL," +
                    "amount DOUBLE NOT NULL," +
                    "tax DOUBLE NOT NULL," +
                    "total_amount DOUBLE NOT NULL," +
                    "discount DOUBLE NOT NULL DEFAULT 0," +
                    "FOREIGN KEY (reservation_id) REFERENCES reservation(reservation_id)" +
                    ")");

            // Create Feedback table
            stmt.execute("CREATE TABLE IF NOT EXISTS feedback (" +
                    "feedback_id INT PRIMARY KEY AUTO_INCREMENT," +
                    "guest_id INT NOT NULL," +
                    "reservation_id INT NOT NULL," +
                    "comments TEXT," +
                    "rating DOUBLE NOT NULL," +
                    "FOREIGN KEY (guest_id) REFERENCES guest(guest_id)," +
                    "FOREIGN KEY (reservation_id) REFERENCES reservation(reservation_id)" +
                    ")");

            // Insert default admin users if they don't exist
            String checkAdmin = "SELECT COUNT(*) FROM admin";
            ResultSet rs = stmt.executeQuery(checkAdmin);
            rs.next();
            int adminCount = rs.getInt(1);

            if (adminCount == 0) {
                stmt.execute("INSERT INTO admin (username, password) VALUES ('admin1', 'password1')");
                stmt.execute("INSERT INTO admin (username, password) VALUES ('admin2', 'password2')");
                logger.log(Level.INFO, "Default admin users created");
            }

            // Insert sample rooms if they don't exist
            String checkRooms = "SELECT COUNT(*) FROM room";
            rs = stmt.executeQuery(checkRooms);
            rs.next();
            int roomCount = rs.getInt(1);

            if (roomCount == 0) {
                // Add 5 single rooms
                for (int i = 101; i <= 105; i++) {
                    stmt.execute("INSERT INTO room (room_id, room_type, number_of_beds, price, status) " +
                            "VALUES (" + i + ", 'SINGLE', 1, 100.00, 'Available')");
                }

                // Add 5 double rooms
                for (int i = 201; i <= 205; i++) {
                    stmt.execute("INSERT INTO room (room_id, room_type, number_of_beds, price, status) " +
                            "VALUES (" + i + ", 'DOUBLE', 2, 200.00, 'Available')");
                }

                // Add 3 deluxe rooms
                for (int i = 301; i <= 303; i++) {
                    stmt.execute("INSERT INTO room (room_id, room_type, number_of_beds, price, status) " +
                            "VALUES (" + i + ", 'DELUXE', 1, 250.00, 'Available')");
                }

                // Add 2 penthouse rooms
                for (int i = 401; i <= 402; i++) {
                    stmt.execute("INSERT INTO room (room_id, room_type, number_of_beds, price, status) " +
                            "VALUES (" + i + ", 'PENT_HOUSE', 1, 500.00, 'Available')");
                }

                logger.log(Level.INFO, "Sample rooms created");
            }

            logger.log(Level.INFO, "Database initialized successfully");

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to initialize database", e);
        } finally {
            closeResources(null, stmt, null);
        }
    }
}