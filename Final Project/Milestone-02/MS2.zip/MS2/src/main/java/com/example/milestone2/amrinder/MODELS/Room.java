package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

/**
 * Model class for Room information
 */
public class Room {
    private final IntegerProperty roomID;
    private final ObjectProperty<RoomType> roomType;
    private final IntegerProperty numberOfBeds;
    private final DoubleProperty price;
    private final StringProperty status; // Available, Occupied, Maintenance

    /**
     * Constructor for Room class
     * @param roomID Unique identifier for the room
     * @param roomType Type of room (SINGLE, DOUBLE, DELUXE, PENT_HOUSE)
     * @param numberOfBeds Number of beds in the room
     * @param price Price of the room per night
     * @param status Current status of the room (Available, Occupied, Maintenance)
     */
    public Room(int roomID, RoomType roomType, int numberOfBeds, double price, String status) {
        this.roomID = new SimpleIntegerProperty(roomID);
        this.roomType = new SimpleObjectProperty<>(roomType);
        this.numberOfBeds = new SimpleIntegerProperty(numberOfBeds);
        this.price = new SimpleDoubleProperty(price);
        this.status = new SimpleStringProperty(status);
    }

    // Getters and Setters
    public int getRoomID() {
        return roomID.get();
    }

    public IntegerProperty roomIDProperty() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID.set(roomID);
    }

    public RoomType getRoomType() {
        return roomType.get();
    }

    public ObjectProperty<RoomType> roomTypeProperty() {
        return roomType;
    }

    public void setRoomType(RoomType roomType) {
        this.roomType.set(roomType);
    }

    public int getNumberOfBeds() {
        return numberOfBeds.get();
    }

    public IntegerProperty numberOfBedsProperty() {
        return numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds.set(numberOfBeds);
    }

    public double getPrice() {
        return price.get();
    }

    public DoubleProperty priceProperty() {
        return price;
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

    public String getStatus() {
        return status.get();
    }

    public StringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    /**
     * Gets all room details as a formatted string
     * @return String containing all room information
     */
    public String getRoomDetails() {
        return "Room ID: " + getRoomID() +
                "\nRoom Type: " + getRoomType().getDisplayName() +
                "\nBeds: " + getNumberOfBeds() +
                "\nPrice: $" + getPrice() +
                "\nStatus: " + getStatus();
    }

    /**
     * Sets room details
     * @param roomType Type of room
     * @param numberOfBeds Number of beds in the room
     * @param price Price of the room per night
     * @param status Current status of the room
     */
    public void setRoomDetails(RoomType roomType, int numberOfBeds, double price, String status) {
        setRoomType(roomType);
        setNumberOfBeds(numberOfBeds);
        setPrice(price);
        setStatus(status);
    }

    /**
     * Checks if the room is available for booking
     * @return true if room is available, false otherwise
     */
    public boolean checkRoomAvailability() {
        return "Available".equalsIgnoreCase(getStatus());
    }
}