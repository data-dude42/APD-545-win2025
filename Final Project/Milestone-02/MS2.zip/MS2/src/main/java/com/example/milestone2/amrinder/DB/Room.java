package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import com.example.milestone2.amrinder.MODELS.RoomType;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Room-related database operations
 */
public class Room {
    private static final Logger logger = Logger.getLogger(Room.class.getName());

    /**
     * Retrieves a room by its ID
     * @param roomID ID of the room to retrieve
     * @return Room object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Room getRoomByID(int roomID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Room room = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM room WHERE room_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, roomID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                RoomType roomType = RoomType.valueOf(rs.getString("room_type"));
                int numberOfBeds = rs.getInt("number_of_beds");
                double price = rs.getDouble("price");
                String status = rs.getString("status");

                room = new com.example.milestone2.amrinder.MODELS.Room(roomID, roomType, numberOfBeds, price, status);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving room by ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving room", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return room;
    }

    /**
     * Retrieves all rooms from the database
     * @return List of Room objects
     */
    public static List<com.example.milestone2.amrinder.MODELS.Room> getAllRooms() {
        List<com.example.milestone2.amrinder.MODELS.Room> rooms = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();
            stmt = conn.createStatement();
            String query = "SELECT * FROM room";

            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int roomID = rs.getInt("room_id");
                RoomType roomType = RoomType.valueOf(rs.getString("room_type"));
                int numberOfBeds = rs.getInt("number_of_beds");
                double price = rs.getDouble("price");
                String status = rs.getString("status");

                com.example.milestone2.amrinder.MODELS.Room room = new com.example.milestone2.amrinder.MODELS.Room(roomID, roomType, numberOfBeds, price, status);
                rooms.add(room);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving all rooms", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving rooms", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return rooms;
    }

    /**
     * Updates the status of a room
     * @param roomID ID of the room to update
     * @param status New status for the room
     * @return true if room status is successfully updated, false otherwise
     */
    public static boolean updateRoomStatus(int roomID, String status) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "UPDATE room SET status = ? WHERE room_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, status);
            stmt.setInt(2, roomID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Room {0} status updated to: {1}", new Object[]{roomID, status});
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating room status", e);
            LoggerUtil.logException(Level.SEVERE, "Database error updating room status", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Finds available rooms based on room type and date range
     * @param roomType Type of room required
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return List of available Room objects matching the criteria
     */
    public static List<com.example.milestone2.amrinder.MODELS.Room> findAvailableRooms(RoomType roomType, LocalDate checkInDate, LocalDate checkOutDate) {
        List<com.example.milestone2.amrinder.MODELS.Room> availableRooms = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();

            // Find rooms of the specified type that are not in any reservation during the date range
            String query = "SELECT r.* FROM room r WHERE r.room_type = ? AND r.status = 'Available' " +
                    "AND r.room_id NOT IN (SELECT res.room_id FROM reservation res " +
                    "WHERE ((res.check_in_date <= ? AND res.check_out_date > ?) " +
                    "OR (res.check_in_date < ? AND res.check_out_date >= ?) " +
                    "OR (res.check_in_date >= ? AND res.check_out_date <= ?)) " +
                    "AND res.status = 'Confirmed')";

            stmt = conn.prepareStatement(query);
            stmt.setString(1, roomType.name());
            stmt.setDate(2, Date.valueOf(checkOutDate));
            stmt.setDate(3, Date.valueOf(checkInDate));
            stmt.setDate(4, Date.valueOf(checkOutDate));
            stmt.setDate(5, Date.valueOf(checkInDate));
            stmt.setDate(6, Date.valueOf(checkInDate));
            stmt.setDate(7, Date.valueOf(checkOutDate));

            rs = stmt.executeQuery();

            while (rs.next()) {
                int roomID = rs.getInt("room_id");
                int numberOfBeds = rs.getInt("number_of_beds");
                double price = rs.getDouble("price");
                String status = rs.getString("status");

                com.example.milestone2.amrinder.MODELS.Room room = new com.example.milestone2.amrinder.MODELS.Room(roomID, roomType, numberOfBeds, price, status);
                availableRooms.add(room);
            }

            logger.log(Level.INFO, "Found {0} available {1} rooms for date range {2} to {3}",
                    new Object[]{availableRooms.size(), roomType, checkInDate, checkOutDate});

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error finding available rooms", e);
            LoggerUtil.logException(Level.SEVERE, "Database error finding available rooms", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return availableRooms;
    }

    /**
     * Suggests room types and combinations based on the number of guests
     * @param numberOfGuests Total number of guests
     * @return List of suggested room combinations (as strings)
     */
    public static List<String> suggestRoomCombinations(int numberOfGuests) {
        List<String> suggestions = new ArrayList<>();

        // Apply business rules for room suggestions
        if (numberOfGuests <= 2) {
            suggestions.add("1 SINGLE room (max 5 people)");
            suggestions.add("1 DELUXE set (max 2 people, premium amenities)");
            suggestions.add("1 PENT_HOUSE accomodation (max 2 people, luxury features)");
        } else if (numberOfGuests <= 4) {
            suggestions.add("1 DOUBLE room (max 4 people)");
            suggestions.add("2 SINGLE rooms (max 4 people)");
            suggestions.add("1 DELUXE room + 1 SINGLE room (max 4 people, some premium amenities)");
        } else if (numberOfGuests <= 6) {
            suggestions.add("1 DOUBLE room + 1 SINGLE room (max 6 people)");
            suggestions.add("3 SINGLE rooms (max 6 people)");
        } else if (numberOfGuests <= 8) {
            suggestions.add("2 DOUBLE rooms (max 8 people)");
            suggestions.add("4 SINGLE rooms (max 8 people)");
            suggestions.add("1 DOUBLE room + 2 SINGLE rooms (max 8 people)");
        } else {
            // For larger groups
            int doubleRooms = numberOfGuests / 4;
            int singleRooms = (numberOfGuests % 4 > 0) ? 1 : 0;

            suggestions.add(doubleRooms + " DOUBLE rooms" +
                    (singleRooms > 0 ? " + " + singleRooms + " SINGLE room" : ""));
            suggestions.add((numberOfGuests / 2) + " SINGLE rooms");
        }

        return suggestions;
    }
}