package com.example.milestone2.amrinder.MODELS;

import javafx.beans.property.*;

/**
 * Model class for Kiosk information
 */
public class Kiosk {
    private final IntegerProperty kioskID;
    private final StringProperty location;

    /**
     * Constructor for Kiosk class
     * @param kioskID Unique identifier for the kiosk
     * @param location Physical location of the kiosk in the hotel
     */
    public Kiosk(int kioskID, String location) {
        this.kioskID = new SimpleIntegerProperty(kioskID);
        this.location = new SimpleStringProperty(location);
    }

    // Getters and Setters
    public int getKioskID() {
        return kioskID.get();
    }

    public IntegerProperty kioskIDProperty() {
        return kioskID;
    }

    public void setKioskID(int kioskID) {
        this.kioskID.set(kioskID);
    }

    public String getLocation() {
        return location.get();
    }

    public StringProperty locationProperty() {
        return location;
    }

    public void setLocation(String location) {
        this.location.set(location);
    }

    /**
     * Displays a welcome message to users of the kiosk
     * @return Welcome message string
     */
    public String displayWelcomeMessage() {
        return "Welcome.";
    }

    /**
     * Guides the user through the booking process
     * @return Instructions for booking process
     */
    public String guideBookingProcess() {
        return "1. Enter the number of guests\n" +
                "2. Select check-in and check-out dates\n" +
                "3. Choose a room type based on our recommendations\n" +
                "4. Enter your personal details\n" +
                "5. Confirm your booking";
    }

    /**
     * Validates user input for the booking process
     * @param input User input to validate
     * @param inputType Type of input being validated (e.g., "name", "email")
     * @return true if input is valid, false otherwise
     */
    public boolean validateInput(String input, String inputType) {
        switch (inputType.toLowerCase()) {
            case "name":
                return input != null && !input.trim().isEmpty();
            case "email":
                return input != null && input.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
            case "phone":
                return input != null && input.matches("\\d{10}");
            case "guests":
                try {
                    int guests = Integer.parseInt(input);
                    return guests > 0 && guests <= 10; // Arbitrary max of 10 guests
                } catch (NumberFormatException e) {
                    return false;
                }
            default:
                return true; // Default validation passes
        }
    }

    /**
     * Confirms a booking made through the kiosk
     * @param reservationID ID of the reservation to confirm
     * @return Confirmation message
     */
    public String confirmBooking(int reservationID) {
        return "Your booking has been confirmed! Your reservation ID is: " + reservationID +
                "\nPlease visit the front desk for any assistance during your stay.";
    }
}