package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Billing-related database operations
 */
public class Billing {
    private static final Logger logger = Logger.getLogger(Billing.class.getName());

    /**
     * Creates a new bill in the database
     * @param billing Billing object to add
     * @return ID of the newly created bill, or -1 if operation failed
     */
    public static int createBill(com.example.milestone2.amrinder.MODELS.Billing billing) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int billID = -1;

        try {
            conn = dbUtil.getConnection();
            String query = "INSERT INTO billing (reservation_id, amount, tax, total_amount, discount) " +
                    "VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, billing.getReservationID());
            stmt.setDouble(2, billing.getAmount());
            stmt.setDouble(3, billing.getTax());
            stmt.setDouble(4, billing.getTotalAmount());
            stmt.setDouble(5, billing.getDiscount());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    billID = rs.getInt(1);
                    logger.log(Level.INFO, "New bill created: ID {0}, Reservation ID {1}, Amount ${2}",
                            new Object[]{billID, billing.getReservationID(), billing.getTotalAmount()});
                }
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error creating bill", e);
            LoggerUtil.logException(Level.SEVERE, "Database error creating bill", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return billID;
    }

    /**
     * Retrieves a bill by its ID
     * @param billID ID of the bill to retrieve
     * @return Billing object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Billing getBillByID(int billID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Billing billing = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM billing WHERE bill_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, billID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int reservationID = rs.getInt("reservation_id");
                double amount = rs.getDouble("amount");
                double tax = rs.getDouble("tax");
                double totalAmount = rs.getDouble("total_amount");
                double discount = rs.getDouble("discount");

                billing = new com.example.milestone2.amrinder.MODELS.Billing(billID, reservationID, amount, discount);
                // We need to set tax and total manually since the constructor calculates them
                billing.setTax(tax);
                billing.setTotalAmount(totalAmount);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving bill by ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving bill", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return billing;
    }

    /**
     * Retrieves a bill by reservation ID
     * @param reservationID ID of the reservation
     * @return Billing object if found, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Billing getBillByReservationID(int reservationID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Billing billing = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM billing WHERE reservation_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, reservationID);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int billID = rs.getInt("bill_id");
                double amount = rs.getDouble("amount");
                double tax = rs.getDouble("tax");
                double totalAmount = rs.getDouble("total_amount");
                double discount = rs.getDouble("discount");

                billing = new com.example.milestone2.amrinder.MODELS.Billing(billID, reservationID, amount, discount);
                // We need to set tax and total manually since the constructor calculates them
                billing.setTax(tax);
                billing.setTotalAmount(totalAmount);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving bill by reservation ID", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving bill", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return billing;
    }

    /**
     * Updates a bill with new discount
     * @param billID ID of the bill to update
     * @param discount New discount amount
     * @return true if bill is successfully updated, false otherwise
     */
    public static boolean updateBillDiscount(int billID, double discount) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();

            // First get the current bill
            com.example.milestone2.amrinder.MODELS.Billing currentBill = getBillByID(billID);
            if (currentBill == null) {
                return false;
            }

            // Calculate new total amount
            double newTotalAmount = currentBill.getAmount() + currentBill.getTax() - discount;

            // Update bill
            String query = "UPDATE billing SET discount = ?, total_amount = ? WHERE bill_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setDouble(1, discount);
            stmt.setDouble(2, newTotalAmount);
            stmt.setInt(3, billID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Bill {0} updated with discount: ${1}", new Object[]{billID, discount});
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating bill discount", e);
            LoggerUtil.logException(Level.SEVERE, "Database error updating bill discount", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Generates a bill for a reservation
     * @param reservationID ID of the reservation
     * @return ID of the newly created bill, or -1 if operation failed
     */
    public static int generateBillForReservation(int reservationID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int billID = -1;

        try {
            conn = dbUtil.getConnection();

            // First check if a bill already exists for this reservation
            com.example.milestone2.amrinder.MODELS.Billing existingBill = getBillByReservationID(reservationID);
            if (existingBill != null) {
                return existingBill.getBillID();
            }

            // Get reservation details
            com.example.milestone2.amrinder.MODELS.Reservation reservation = Reservation.getReservationByID(reservationID);
            if (reservation == null) {
                return -1;
            }

            // Get room details
            com.example.milestone2.amrinder.MODELS.Room room = Room.getRoomByID(reservation.getRoomID());
            if (room == null) {
                return -1;
            }

            // Calculate total amount
            long nights = reservation.calculateNumberOfNights();
            double amount = room.getPrice() * nights;

            // Create billing object
            com.example.milestone2.amrinder.MODELS.Billing billing = new com.example.milestone2.amrinder.MODELS.Billing(0, reservationID, amount, 0);

            // Save bill to database
            billID = createBill(billing);

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error generating bill for reservation", e);
            LoggerUtil.logException(Level.SEVERE, "Error generating bill for reservation", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return billID;
    }
}