package com.example.milestone2.amrinder.DB;

import com.example.milestone2.amrinder.utils.dbUtil;
import com.example.milestone2.amrinder.utils.LoggerUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for Admin-related database operations
 */
public class Admin {
    private static final Logger logger = Logger.getLogger(Admin.class.getName());

    /**
     * Validates admin credentials against the database
     * @param username Admin username
     * @param password Admin password
     * @return Admin object if credentials are valid, null otherwise
     */
    public static com.example.milestone2.amrinder.MODELS.Admin validateAdmin(String username, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        com.example.milestone2.amrinder.MODELS.Admin admin = null;

        try {
            conn = dbUtil.getConnection();
            String query = "SELECT * FROM admin WHERE username = ? AND password = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            rs = stmt.executeQuery();

            if (rs.next()) {
                int adminId = rs.getInt("admin_id");
                admin = new com.example.milestone2.amrinder.MODELS.Admin(adminId, username, password);

                // Log successful login
                LoggerUtil.logAdminActivity(username, "logged in", "successfully");
            } else {
                // Log failed login attempt
                LoggerUtil.logAdminActivity(username, "failed login attempt", "invalid credentials");
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error validating admin credentials", e);
            LoggerUtil.logException(Level.SEVERE, "Database error during admin validation", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return admin;
    }

    /**
     * Retrieves a list of all admins from the database
     * @return List of Admin objects
     */
    public static List<com.example.milestone2.amrinder.MODELS.Admin> getAllAdmins() {
        List<com.example.milestone2.amrinder.MODELS.Admin> admins = new ArrayList<>();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = dbUtil.getConnection();
            stmt = conn.createStatement();
            String query = "SELECT * FROM admin";

            rs = stmt.executeQuery(query);

            while (rs.next()) {
                int adminId = rs.getInt("admin_id");
                String username = rs.getString("username");
                String password = rs.getString("password");

                com.example.milestone2.amrinder.MODELS.Admin admin = new com.example.milestone2.amrinder.MODELS.Admin(adminId, username, password);
                admins.add(admin);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error retrieving all admins", e);
            LoggerUtil.logException(Level.SEVERE, "Database error retrieving admins", e);
        } finally {
            dbUtil.closeResources(conn, stmt, rs);
        }

        return admins;
    }

    /**
     * Adds a new admin to the database
     * @param admin Admin object to add
     * @return true if admin is successfully added, false otherwise
     */
    public static boolean addAdmin(com.example.milestone2.amrinder.MODELS.Admin admin) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "INSERT INTO admin (username, password) VALUES (?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, admin.getUsername());
            stmt.setString(2, admin.getPassword());

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "New admin added: {0}", admin.getUsername());
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error adding new admin", e);
            LoggerUtil.logException(Level.SEVERE, "Database error adding admin", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Updates an existing admin in the database
     * @param admin Admin object with updated information
     * @return true if admin is successfully updated, false otherwise
     */
    public static boolean updateAdmin(com.example.milestone2.amrinder.MODELS.Admin admin) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "UPDATE admin SET username = ?, password = ? WHERE admin_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, admin.getUsername());
            stmt.setString(2, admin.getPassword());
            stmt.setInt(3, admin.getAdminID());

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Admin updated: {0}", admin.getUsername());
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error updating admin", e);
            LoggerUtil.logException(Level.SEVERE, "Database error updating admin", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }

    /**
     * Deletes an admin from the database
     * @param adminID ID of the admin to delete
     * @return true if admin is successfully deleted, false otherwise
     */
    public static boolean deleteAdmin(int adminID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = dbUtil.getConnection();
            String query = "DELETE FROM admin WHERE admin_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, adminID);

            int rowsAffected = stmt.executeUpdate();
            success = rowsAffected > 0;

            if (success) {
                logger.log(Level.INFO, "Admin deleted: ID {0}", adminID);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Error deleting admin", e);
            LoggerUtil.logException(Level.SEVERE, "Database error deleting admin", e);
        } finally {
            dbUtil.closeResources(conn, stmt, null);
        }

        return success;
    }
}