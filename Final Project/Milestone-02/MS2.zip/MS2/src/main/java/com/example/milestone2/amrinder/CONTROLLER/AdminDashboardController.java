package com.example.milestone2.amrinder.CONTROLLER;

import com.example.milestone2.amrinder.HelloApplication;
import com.example.milestone2.amrinder.DB.Billing;
import com.example.milestone2.amrinder.DB.Feedback;
import com.example.milestone2.amrinder.DB.Guest;
import com.example.milestone2.amrinder.DB.Reservation;
import com.example.milestone2.amrinder.DB.Room;
import com.example.milestone2.amrinder.MODELS.Admin;
import com.example.milestone2.amrinder.MODELS.RoomType;
import com.example.ms2.models.*;
import com.example.milestone2.amrinder.utils.LoggerUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;

/**
 * Controller for the admin dashboard view
 */
public class AdminDashboardController {
    private Admin currentAdmin;

    @FXML
    private Label welcomeLabel;

    @FXML
    private TabPane tabPane;

    @FXML
    private Tab searchTab;

    @FXML
    private Tab bookingTab;

    @FXML
    private Tab checkoutTab;

    // Search tab components
    @FXML
    private TextField searchField;

    @FXML
    private Button searchButton;

    @FXML
    private TableView<com.example.milestone2.amrinder.MODELS.Guest> guestTableView;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, Integer> guestIdColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, String> guestNameColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, String> guestPhoneColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Guest, String> guestEmailColumn;

    // Booking tab components
    @FXML
    private ComboBox<com.example.milestone2.amrinder.MODELS.Guest> guestComboBox;

    @FXML
    private TextField numberOfGuestsField;

    @FXML
    private DatePicker checkInDatePicker;

    @FXML
    private DatePicker checkOutDatePicker;

    @FXML
    private ComboBox<RoomType> roomTypeComboBox;

    @FXML
    private TableView<com.example.milestone2.amrinder.MODELS.Room> availableRoomsTableView;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, Integer> roomIdColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, RoomType> roomTypeColumn;

    @FXML
    private TableColumn<com.example.milestone2.amrinder.MODELS.Room, Double> roomPriceColumn;

    @FXML
    private Button createReservationButton;

    // Checkout tab components
    @FXML
    private TextField reservationIdField;

    @FXML
    private Button searchReservationButton;

    @FXML
    private TextArea reservationDetailsLabel;

    @FXML
    private TextArea billDetailsLabel;

    @FXML
    private TextField discountField;

    @FXML
    private Button applyDiscountButton;

    @FXML
    private Button checkoutButton;

    @FXML
    private Button cancelReservationButton;

    @FXML
    private Button feedbackReminderButton;

    @FXML
    private Button logoutButton;

    // Currently selected items
    private com.example.milestone2.amrinder.MODELS.Guest selectedGuest;
    private com.example.milestone2.amrinder.MODELS.Room selectedRoom;
    private com.example.milestone2.amrinder.MODELS.Reservation currentReservation;
    private com.example.milestone2.amrinder.MODELS.Billing currentBill;

    /**
     * Initializes the controller class
     */
    @FXML
    public void initialize() {
        // Initialize guest table columns
        guestIdColumn.setCellValueFactory(new PropertyValueFactory<>("guestID"));
        guestNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        guestPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        guestEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));

        // Initialize available rooms table columns
        roomIdColumn.setCellValueFactory(new PropertyValueFactory<>("roomID"));
        roomTypeColumn.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Format price column with currency format
        roomPriceColumn.setCellFactory(column -> new TableCell<com.example.milestone2.amrinder.MODELS.Room, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("$%.2f", price));
                }
            }
        });

        // Setup cell factory for guest combo box to display guest name and ID
        guestComboBox.setConverter(new StringConverter<com.example.milestone2.amrinder.MODELS.Guest>() {
            @Override
            public String toString(com.example.milestone2.amrinder.MODELS.Guest guest) {
                if (guest == null) {
                    return null;
                }
                return guest.getName() + " (ID: " + guest.getGuestID() + ")";
            }

            @Override
            public com.example.milestone2.amrinder.MODELS.Guest fromString(String string) {
                // Not needed for this implementation
                return null;
            }
        });

        // Setup cell factory for room type combo box
        roomTypeComboBox.setConverter(new StringConverter<RoomType>() {
            @Override
            public String toString(RoomType roomType) {
                if (roomType == null) {
                    return null;
                }
                return roomType.getDisplayName();
            }

            @Override
            public RoomType fromString(String string) {
                // Not needed for this implementation
                return null;
            }
        });

        // Initialize room type combo box
        roomTypeComboBox.getItems().setAll(RoomType.values());

        // Initialize date pickers with default values
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));

        // Add listener to guest table selection
        guestTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        selectedGuest = newValue;
                        // Add guest to combo box if not already there
                        if (!guestComboBox.getItems().contains(selectedGuest)) {
                            guestComboBox.getItems().add(selectedGuest);
                        }
                        guestComboBox.setValue(selectedGuest);
                    }
                });

        // Add listener to available rooms table selection
        availableRoomsTableView.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        selectedRoom = newValue;
                        createReservationButton.setDisable(false);
                    }
                });

        // Add listener to room type combo box
        roomTypeComboBox.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && checkInDatePicker.getValue() != null && checkOutDatePicker.getValue() != null) {
                loadAvailableRooms();
            }
        });

        // Add listeners to date pickers
        checkInDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && roomTypeComboBox.getValue() != null) {
                // Ensure check-out date is after check-in date
                if (checkOutDatePicker.getValue().isBefore(newValue)) {
                    checkOutDatePicker.setValue(newValue.plusDays(1));
                }
                loadAvailableRooms();
            }
        });

        checkOutDatePicker.valueProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && roomTypeComboBox.getValue() != null) {
                // Ensure check-out date is after check-in date
                if (newValue.isBefore(checkInDatePicker.getValue())) {
                    showAlert(Alert.AlertType.WARNING, "Invalid Date",
                            "Check-out date cannot be before check-in date.");
                    checkOutDatePicker.setValue(oldValue);
                } else {
                    loadAvailableRooms();
                }
            }
        });

        // Style the TextAreas for better readability
        reservationDetailsLabel.setStyle("-fx-background-color: #ffffff; -fx-text-fill: black; -fx-font-size: 13px; -fx-background-radius: 5; -fx-border-color: #3498db; -fx-border-radius: 5; -fx-border-width: 1;");
        billDetailsLabel.setStyle("-fx-background-color: #ffffff; -fx-text-fill: black; -fx-font-size: 13px; -fx-background-radius: 5; -fx-border-color: #3498db; -fx-border-radius: 5; -fx-border-width: 1;");
        // Disable buttons initially
        createReservationButton.setDisable(true);
        checkoutButton.setDisable(true);
        cancelReservationButton.setDisable(true);
        applyDiscountButton.setDisable(true);
        feedbackReminderButton.setDisable(true);
        discountField.setDisable(true);

        // Clear forms
        clearCheckoutForm();
    }

    /**
     * Sets the admin for this dashboard
     * @param admin Admin object
     */
    public void setAdmin(Admin admin) {
        this.currentAdmin = admin;
        welcomeLabel.setText("Welcome, " + admin.getUsername() + "!");

        // Log admin activity
        LoggerUtil.logAdminActivity(admin.getUsername(), "accessed dashboard", "successfully");
    }

    /**
     * Handles the search button click event
     * @param event The action event
     */
    @FXML
    private void handleSearchButton(ActionEvent event) {
        String searchTerm = searchField.getText().trim();

        if (searchTerm.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Empty Search", "Please enter a search term");
            return;
        }

        List<com.example.milestone2.amrinder.MODELS.Guest> guests = Guest.searchGuests(searchTerm);

        if (guests.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "No Results",
                    "No guests found matching '" + searchTerm + "'");
        } else {
            ObservableList<com.example.milestone2.amrinder.MODELS.Guest> guestList = FXCollections.observableArrayList(guests);
            guestTableView.setItems(guestList);

            // Log admin activity
            LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "searched for guests",
                    "term: " + searchTerm + ", found: " + guests.size());
        }
    }

    /**
     * Handles the create reservation button click event
     * @param event The action event
     */
    @FXML
    private void handleCreateReservationButton(ActionEvent event) {
        // Validate input
        if (guestComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "No Guest Selected", "Please select a guest");
            return;
        }

        if (selectedRoom == null) {
            showAlert(Alert.AlertType.WARNING, "No Room Selected", "Please select a room");
            return;
        }

        String numGuestsText = numberOfGuestsField.getText().trim();
        if (numGuestsText.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Missing Information", "Please enter the number of guests");
            return;
        }

        int numberOfGuests;
        try {
            numberOfGuests = Integer.parseInt(numGuestsText);
            if (numberOfGuests <= 0) {
                throw new NumberFormatException("Number of guests must be positive");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Invalid Input", "Please enter a valid number of guests");
            return;
        }

        // Check if number of guests exceeds room capacity
        RoomType roomType = selectedRoom.getRoomType();
        if (numberOfGuests > roomType.getMaxOccupancy()) {
            showAlert(Alert.AlertType.WARNING, "Too Many Guests",
                    "The selected room can only accommodate " + roomType.getMaxOccupancy() + " guests");
            return;
        }

        // Create reservation
        com.example.milestone2.amrinder.MODELS.Guest guest = guestComboBox.getValue();
        LocalDate checkInDate = checkInDatePicker.getValue();
        LocalDate checkOutDate = checkOutDatePicker.getValue();

        com.example.milestone2.amrinder.MODELS.Reservation reservation = new com.example.milestone2.amrinder.MODELS.Reservation(0, guest.getGuestID(), selectedRoom.getRoomID(),
                checkInDate, checkOutDate, numberOfGuests, "Confirmed");

        int reservationId = Reservation.createReservation(reservation);

        if (reservationId > 0) {
            // Generate bill
            int billId = Billing.generateBillForReservation(reservationId);

            if (billId > 0) {
                // Log admin activity
                LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "created reservation",
                        "ID: " + reservationId + " for guest: " + guest.getName());

                showAlert(Alert.AlertType.INFORMATION, "Reservation Created",
                        "Reservation created successfully with ID: " + reservationId +
                                "\nBill generated with ID: " + billId);

                // Clear form
                clearBookingForm();
            } else {
                showAlert(Alert.AlertType.ERROR, "Bill Creation Failed",
                        "Reservation created but failed to generate bill");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Reservation Failed",
                    "Failed to create reservation");
        }
    }

    /**
     * Handles the search reservation button click event
     * @param event The action event
     */
    @FXML
    private void handleSearchReservationButton(ActionEvent event) {
        String reservationIdText = reservationIdField.getText().trim();

        if (reservationIdText.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Empty Input", "Please enter a reservation ID");
            return;
        }

        int reservationId;
        try {
            reservationId = Integer.parseInt(reservationIdText);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Invalid Input", "Please enter a valid reservation ID");
            return;
        }

        // Retrieve reservation
        currentReservation = Reservation.getReservationByID(reservationId);

        if (currentReservation == null) {
            showAlert(Alert.AlertType.WARNING, "Not Found", "No reservation found with ID: " + reservationId);
            clearCheckoutForm();
            return;
        }

        // Get guest information
        com.example.milestone2.amrinder.MODELS.Guest guest = Guest.getGuestByID(currentReservation.getGuestID());

        // Get room information
        com.example.milestone2.amrinder.MODELS.Room room = Room.getRoomByID(currentReservation.getRoomID());

        // Get or generate bill
        currentBill = Billing.getBillByReservationID(currentReservation.getReservationID());
        if (currentBill == null) {
            int billId = Billing.generateBillForReservation(currentReservation.getReservationID());
            if (billId > 0) {
                currentBill = Billing.getBillByID(billId);
            }
        }

        // Update UI
        StringBuilder reservationDetails = new StringBuilder();
        reservationDetails.append("Reservation ID: ").append(currentReservation.getReservationID()).append("\n");
        reservationDetails.append("Status: ").append(currentReservation.getStatus()).append("\n\n");

        if (guest != null) {
            reservationDetails.append("Guest: ").append(guest.getName()).append("\n");
            reservationDetails.append("Phone: ").append(guest.getPhoneNumber()).append("\n");
            reservationDetails.append("Email: ").append(guest.getEmail()).append("\n\n");
        }

        if (room != null) {
            reservationDetails.append("Room: ").append(room.getRoomID()).append(" (").append(room.getRoomType().getDisplayName()).append(")\n");
            reservationDetails.append("Price per Night: $").append(String.format("%.2f", room.getPrice())).append("\n\n");
        }

        reservationDetails.append("Check-In: ").append(currentReservation.getCheckInDate()).append("\n");
        reservationDetails.append("Check-Out: ").append(currentReservation.getCheckOutDate()).append("\n");
        reservationDetails.append("Nights: ").append(currentReservation.calculateNumberOfNights()).append("\n");
        reservationDetails.append("Number of Guests: ").append(currentReservation.getNumberOfGuests());

        reservationDetailsLabel.setText(reservationDetails.toString());

        // Update bill details
        if (currentBill != null) {
            updateBillDetailsLabel();
        } else {
            billDetailsLabel.setText("No bill found for this reservation");
        }

        // Enable/disable buttons based on reservation status
        boolean isActive = "Confirmed".equals(currentReservation.getStatus());
        checkoutButton.setDisable(!isActive);
        cancelReservationButton.setDisable(!isActive);
        applyDiscountButton.setDisable(!isActive);
        discountField.setDisable(!isActive);

        // Enable/disable feedback reminder button
        boolean isCheckedOut = "CheckedOut".equals(currentReservation.getStatus());
        boolean hasFeedback = Feedback.feedbackExistsForReservation(currentReservation.getReservationID());
        feedbackReminderButton.setDisable(!(isCheckedOut && !hasFeedback));

        // Log admin activity
        LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "searched for reservation",
                "ID: " + reservationId);
    }

    /**
     * Handles the apply discount button click event
     * @param event The action event
     */
    @FXML
    private void handleApplyDiscountButton(ActionEvent event) {
        if (currentBill == null) {
            showAlert(Alert.AlertType.WARNING, "No Bill", "No bill found for this reservation");
            return;
        }

        String discountText = discountField.getText().trim();

        if (discountText.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Empty Input", "Please enter a discount amount");
            return;
        }

        double discount;
        try {
            discount = Double.parseDouble(discountText);
            if (discount < 0) {
                throw new NumberFormatException("Discount cannot be negative");
            }
            if (discount > currentBill.getAmount()) {
                throw new NumberFormatException("Discount cannot exceed base amount");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Invalid Input", "Please enter a valid discount amount");
            return;
        }

        // Apply discount
        if (Billing.updateBillDiscount(currentBill.getBillID(), discount)) {
            // Refresh bill
            currentBill = Billing.getBillByID(currentBill.getBillID());
            updateBillDetailsLabel();

            // Log admin activity
            LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "applied discount",
                    "Amount: $" + String.format("%.2f", discount) +
                            " to reservation ID: " + currentReservation.getReservationID());

            showAlert(Alert.AlertType.INFORMATION, "Discount Applied",
                    "Discount of $" + String.format("%.2f", discount) + " applied successfully");
        } else {
            showAlert(Alert.AlertType.ERROR, "Discount Failed", "Failed to apply discount");
        }
    }

    /**
     * Handles the checkout button click event
     * @param event The action event
     */
    @FXML
    private void handleCheckoutButton(ActionEvent event) {
        if (currentReservation == null) {
            showAlert(Alert.AlertType.WARNING, "No Reservation", "No reservation selected");
            return;
        }

        if (!"Confirmed".equals(currentReservation.getStatus())) {
            showAlert(Alert.AlertType.WARNING, "Invalid Status",
                    "Only confirmed reservations can be checked out");
            return;
        }

        // Confirm checkout
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Checkout");
        alert.setHeaderText("Check Out Reservation #" + currentReservation.getReservationID());
        alert.setContentText("Are you sure you want to check out this reservation?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Process checkout
            if (Reservation.checkOutReservation(currentReservation.getReservationID())) {
                // Refresh reservation
                currentReservation = Reservation.getReservationByID(currentReservation.getReservationID());

                // Log admin activity
                LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "checked out reservation",
                        "ID: " + currentReservation.getReservationID());

                // Update UI
                handleSearchReservationButton(null);

                // Show reminder for feedback
                Alert reminderAlert = new Alert(Alert.AlertType.INFORMATION);
                reminderAlert.setTitle("Feedback Reminder");
                reminderAlert.setHeaderText("Remind Guest About Feedback");
                reminderAlert.setContentText("Please remind the guest that they can provide feedback about their stay using the kiosk.");
                reminderAlert.showAndWait();
            } else {
                showAlert(Alert.AlertType.ERROR, "Checkout Failed", "Failed to check out reservation");
            }
        }
    }

    /**
     * Handles the cancel reservation button click event
     * @param event The action event
     */
    @FXML
    private void handleCancelReservationButton(ActionEvent event) {
        if (currentReservation == null) {
            showAlert(Alert.AlertType.WARNING, "No Reservation", "No reservation selected");
            return;
        }

        if (!"Confirmed".equals(currentReservation.getStatus())) {
            showAlert(Alert.AlertType.WARNING, "Invalid Status",
                    "Only confirmed reservations can be cancelled");
            return;
        }

        // Confirm cancellation
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Cancellation");
        alert.setHeaderText("Cancel Reservation #" + currentReservation.getReservationID());
        alert.setContentText("Are you sure you want to cancel this reservation?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Process cancellation
            if (Reservation.cancelReservation(currentReservation.getReservationID())) {
                // Refresh reservation
                currentReservation = Reservation.getReservationByID(currentReservation.getReservationID());

                // Log admin activity
                LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "cancelled reservation",
                        "ID: " + currentReservation.getReservationID());

                // Update UI
                handleSearchReservationButton(null);

                showAlert(Alert.AlertType.INFORMATION, "Reservation Cancelled",
                        "Reservation has been cancelled successfully");
            } else {
                showAlert(Alert.AlertType.ERROR, "Cancellation Failed", "Failed to cancel reservation");
            }
        }
    }

    /**
     * Handles the feedback reminder button click event
     * @param event The action event
     */
    @FXML
    private void handleFeedbackReminderButton(ActionEvent event) {
        if (currentReservation == null) {
            showAlert(Alert.AlertType.WARNING, "No Reservation", "No reservation selected");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Feedback Information");
        alert.setHeaderText("Feedback Instructions for Guest");
        alert.setContentText("Please inform the guest that they can provide feedback about their stay " +
                "using the kiosk. They will need their reservation ID: " + currentReservation.getReservationID());
        alert.showAndWait();

        // Log admin activity
        LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "sent feedback reminder",
                "for reservation ID: " + currentReservation.getReservationID());
    }

    /**
     * Handles the logout button click event
     * @param event The action event
     */
    @FXML
    private void handleLogoutButton(ActionEvent event) {
        try {
            LoggerUtil.logAdminActivity(currentAdmin.getUsername(), "logged out", "successfully");

            // Load the main view
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/hello_View.fxml"));
            Scene scene = new Scene(loader.load(), 800, 600);

            // Get the stage from the event source
            Stage stage = (Stage) logoutButton.getScene().getWindow();

            // Set the new scene
            stage.setTitle("Mandarin Oriental");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            LoggerUtil.logException(Level.SEVERE, "Error loading main view", e);
            e.printStackTrace();
        }
    }

    /**
     * Loads available rooms based on the selected room type and dates
     */
    private void loadAvailableRooms() {
        RoomType roomType = roomTypeComboBox.getValue();
        LocalDate checkInDate = checkInDatePicker.getValue();
        LocalDate checkOutDate = checkOutDatePicker.getValue();

        if (roomType == null || checkInDate == null || checkOutDate == null) {
            return;
        }

        List<com.example.milestone2.amrinder.MODELS.Room> availableRooms = Room.findAvailableRooms(roomType, checkInDate, checkOutDate);
        availableRoomsTableView.setItems(FXCollections.observableArrayList(availableRooms));

        if (availableRooms.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "No Rooms Available",
                    "No " + roomType.getDisplayName() + " rooms available for the selected dates");
            createReservationButton.setDisable(true);
        }
    }

    /**
     * Updates the bill details label with current bill information
     */
    private void updateBillDetailsLabel() {
        if (currentBill == null) {
            billDetailsLabel.setText("No bill information available");
            return;
        }

        StringBuilder billDetails = new StringBuilder();
        billDetails.append("Bill ID: ").append(currentBill.getBillID()).append("\n\n");
        billDetails.append("Base Amount: $").append(String.format("%.2f", currentBill.getAmount())).append("\n");
        billDetails.append("Tax (13%): $").append(String.format("%.2f", currentBill.getTax())).append("\n");

        if (currentBill.getDiscount() > 0) {
            billDetails.append("Discount: $").append(String.format("%.2f", currentBill.getDiscount())).append("\n");
        }

        billDetails.append("\nTotal Amount: $").append(String.format("%.2f", currentBill.getTotalAmount()));

        billDetailsLabel.setText(billDetails.toString());
    }

    /**
     * Clears the booking form fields
     */
    private void clearBookingForm() {
        guestComboBox.setValue(null);
        numberOfGuestsField.clear();
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));
        roomTypeComboBox.setValue(null);
        availableRoomsTableView.getItems().clear();
        selectedRoom = null;
        createReservationButton.setDisable(true);
    }

    /**
     * Clears the checkout form fields
     */
    private void clearCheckoutForm() {
        reservationDetailsLabel.setText("");
        billDetailsLabel.setText("");
        discountField.clear();
        checkoutButton.setDisable(true);
        cancelReservationButton.setDisable(true);
        applyDiscountButton.setDisable(true);
        feedbackReminderButton.setDisable(true);
        discountField.setDisable(true);
        currentReservation = null;
        currentBill = null;
    }

    /**
     * Shows an alert dialog
     * @param type Alert type
     * @param title Alert title
     * @param message Alert message
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void switchToSearchTab(ActionEvent actionEvent) {
    }

    public void switchToBookingTab(ActionEvent actionEvent) {
    }

    public void switchToCheckoutTab(ActionEvent actionEvent) {
    }
}