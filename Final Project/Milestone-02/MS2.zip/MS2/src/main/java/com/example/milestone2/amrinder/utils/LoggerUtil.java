package com.example.milestone2.amrinder.utils;

import java.io.IOException;
import java.util.logging.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Formatter;

/**
 * Utility class for setting up and managing logging
 */
public class LoggerUtil {
    private static final Logger LOGGER = Logger.getLogger("HotelReservationSystemLogger");
    private static FileHandler fileHandler;

    /**
     * Initializes the logger
     */
    public static void initializeLogger() {
        try {
            // Configure the logger with a file handler that rotates logs
            fileHandler = new FileHandler("system_logs.%g.log", 1024 * 1024, 10, true);
            fileHandler.setFormatter(new CustomLogFormatter());

            // Set log level
            LOGGER.setLevel(Level.ALL);
            fileHandler.setLevel(Level.ALL);

            // Add handler to logger
            LOGGER.addHandler(fileHandler);

            // Prevent logging from being passed to parent handlers
            LOGGER.setUseParentHandlers(false);

            LOGGER.info("Logger initialized successfully");
        } catch (IOException e) {
            System.err.println("Failed to initialize logger: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Gets the logger instance
     * @return Logger instance
     */
    public static Logger getLogger() {
        return LOGGER;
    }

    /**
     * Logs exception details
     * @param level Severity level of the exception
     * @param message Description of what happened
     * @param exception The exception that occurred
     */
    public static void logException(Level level, String message, Exception exception) {
        LOGGER.log(level, message, exception);
    }

    /**
     * Logs admin activity
     * @param adminUsername Username of the admin
     * @param action Action performed by the admin
     * @param details Additional details about the action
     */
    public static void logAdminActivity(String adminUsername, String action, String details) {
        LOGGER.log(Level.INFO, "Admin '{0}' {1}: {2}", new Object[]{adminUsername, action, details});
    }

    /**
     * Custom formatter for log messages
     */
    private static class CustomLogFormatter extends Formatter {
        private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        @Override
        public String format(LogRecord record) {
            StringBuilder sb = new StringBuilder();

            // Format the timestamp
            sb.append("[")
                    .append(DATE_FORMAT.format(LocalDateTime.now()))
                    .append("] ");

            // Format the level
            sb.append(record.getLevel().getName()).append(": ");

            // Format the message
            sb.append(formatMessage(record)).append("\n");

            // Format the exception if present
            if (record.getThrown() != null) {
                sb.append("Exception: ").append(record.getThrown().getClass().getName()).append(": ")
                        .append(record.getThrown().getMessage()).append("\n");

                for (StackTraceElement element : record.getThrown().getStackTrace()) {
                    sb.append("\tat ").append(element.toString()).append("\n");
                }
            }

            return sb.toString();
        }
    }
}