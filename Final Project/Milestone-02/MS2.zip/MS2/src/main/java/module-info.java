module com.example.ms2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.logging;

    exports com.example.milestone2.amrinder;
    exports com.example.milestone2.amrinder.CONTROLLER;
    exports com.example.milestone2.amrinder.DB;
    requires javafx.web;

    opens com.example.milestone2.amrinder to javafx.fxml;
    opens com.example.milestone2.amrinder.CONTROLLER to javafx.fxml;
    opens com.example.milestone2.amrinder.MODELS to javafx.fxml;

    opens com.example.milestone2.amrinder.DB to javafx.fxml;
    exports com.example.milestone2.amrinder.utils;
    exports com.example.milestone2.amrinder.MODELS;

    opens com.example.milestone2.amrinder.utils to javafx.fxml;
}