module com.example.w45 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.w45 to javafx.fxml;
    opens com.example.w45.controller to javafx.fxml;
    exports com.example.w45;
    exports com.example.w45.controller;
    opens com.example.w45.model to javafx.fxml;
    exports com.example.w45.model;
}