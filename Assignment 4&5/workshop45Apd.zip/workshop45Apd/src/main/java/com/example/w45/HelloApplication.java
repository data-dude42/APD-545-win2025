package com.example.w45;

import com.example.w45.model.Inventory;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    private static Inventory inventory;

    @Override
    public void start(Stage stage) throws IOException {
        inventory = new Inventory();

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/view/login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 900, 800);
        stage.setTitle("IMS - Login Page");
        stage.setScene(scene);
        stage.show();
    }

    public static Inventory getInventory() {
        return inventory;
    }

    public static void main(String[] args) {
        launch();
    }
}