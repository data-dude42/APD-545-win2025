/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/

package com.example.w45.controller;

import com.example.w45.HelloApplication;
import com.example.w45.model.Inventory;
import com.example.w45.model.Part;
import com.example.w45.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ModifyProduct implements Initializable {

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField maxField;

    @FXML
    private TextField minField;

    @FXML
    private TextField partSearchField;

    @FXML
    private TableView<Part> availablePartsTable;

    @FXML
    private TableColumn<Part, Integer> availablePartIdColumn;

    @FXML
    private TableColumn<Part, String> availablePartNameColumn;

    @FXML
    private TableColumn<Part, Integer> availablePartStockColumn;

    @FXML
    private TableColumn<Part, Double> availablePartPriceColumn;

    @FXML
    private TableView<Part> associatedPartsTable;

    @FXML
    private TableColumn<Part, Integer> associatedPartIdColumn;

    @FXML
    private TableColumn<Part, String> associatedPartNameColumn;

    @FXML
    private TableColumn<Part, Integer> associatedPartStockColumn;

    @FXML
    private TableColumn<Part, Double> associatedPartPriceColumn;

    @FXML
    private Button addPartButton;

    @FXML
    private Button removePartButton;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Inventory inventorySystem;
    private ObservableList<Part> productComponents = FXCollections.observableArrayList();
    private Product currentProduct;
    private int productPosition;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        inventorySystem = HelloApplication.getInventory();

        configureAvailablePartsTable();
        configureAssociatedPartsTable();

        loadAvailableParts();
    }

    private void configureAvailablePartsTable() {
        availablePartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        availablePartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        availablePartStockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        availablePartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void configureAssociatedPartsTable() {
        associatedPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartStockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void loadAvailableParts() {
        availablePartsTable.setItems(inventorySystem.getAllParts());
    }

    public void setProduct(Product product, int index) {
        this.currentProduct = product;
        this.productPosition = index;

        populateFormFields(product);
        loadAssociatedParts(product);

        idField.setDisable(true);
    }

    private void populateFormFields(Product product) {
        idField.setText(String.valueOf(product.getId()));
        nameField.setText(product.getName());
        stockField.setText(String.valueOf(product.getStock()));
        priceField.setText(String.valueOf(product.getPrice()));
        maxField.setText(String.valueOf(product.getMax()));
        minField.setText(String.valueOf(product.getMin()));
    }

    private void loadAssociatedParts(Product product) {
        productComponents.clear();
        productComponents.addAll(product.getAllAssociatedParts());
        associatedPartsTable.setItems(productComponents);
    }

    @FXML
    private void handleAddPartButton() {
        Part selectedPart = availablePartsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            productComponents.add(selectedPart);
            associatedPartsTable.setItems(productComponents);
        } else {
            showNotification(Alert.AlertType.WARNING, "Component Selection", "Please select a component from the available list to add to this product.");
        }
    }

    @FXML
    private void handleRemovePartButton() {
        Part selectedPart = associatedPartsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDialog.setTitle("Remove Component");
            confirmDialog.setHeaderText("Component Removal Request");
            confirmDialog.setContentText("Do you want to remove this component from the product specification?");

            Optional<ButtonType> result = confirmDialog.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                productComponents.remove(selectedPart);
                associatedPartsTable.setItems(productComponents);
            }
        } else {
            showNotification(Alert.AlertType.WARNING, "Component Selection", "Please select a component from the product's list to remove.");
        }
    }

    @FXML
    private void handleSearchPartButton() {
        String searchQuery = partSearchField.getText().trim();
        if (searchQuery.isEmpty()) {
            loadAvailableParts();
            return;
        }

        try {
            int id = Integer.parseInt(searchQuery);
            Part foundPart = inventorySystem.searchPartByID(id);
            if (foundPart != null) {
                ObservableList<Part> searchResults = FXCollections.observableArrayList();
                searchResults.add(foundPart);
                availablePartsTable.setItems(searchResults);
            } else {
                availablePartsTable.setItems(FXCollections.observableArrayList());
            }
        } catch (NumberFormatException e) {
            // Search by name if not a number
            availablePartsTable.setItems(inventorySystem.searchPartByName(searchQuery));
        }
    }

    @FXML
    private void handleSaveButton(ActionEvent event) {
        try {
            if (!validateProductData()) {
                return;
            }

            String name = nameField.getText().trim();
            double price = Double.parseDouble(priceField.getText().trim());
            int stock = Integer.parseInt(stockField.getText().trim());
            int min = Integer.parseInt(minField.getText().trim());
            int max = Integer.parseInt(maxField.getText().trim());
            int id = Integer.parseInt(idField.getText().trim());

            // Create updated product
            Product updatedProduct = new Product(id, name, price, stock, min, max);

            // Add all associated components
            for (Part component : productComponents) {
                updatedProduct.addAssociatedPart(component);
            }

            // Update in inventory
            inventorySystem.updateProduct(productPosition, updatedProduct);

            // Close window
            closeWindow(event);

        } catch (Exception e) {
            showNotification(Alert.AlertType.ERROR, "Processing Error", "An unexpected error occurred: " + e.getMessage());
        }
    }

    private boolean validateProductData() {
        // Name validation
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            showNotification(Alert.AlertType.ERROR, "Validation Error", "Product name is required and cannot be left blank.");
            return false;
        }

        // Price validation
        double price;
        try {
            price = Double.parseDouble(priceField.getText().trim());
            if (price < 0) {
                showNotification(Alert.AlertType.ERROR, "Validation Error", "Product pricing must be a positive value.");
                return false;
            }
        } catch (NumberFormatException e) {
            showNotification(Alert.AlertType.ERROR, "Validation Error", "Please enter a valid numerical value for product price.");
            return false;
        }

        // Stock validation
        int stock;
        try {
            stock = Integer.parseInt(stockField.getText().trim());
            if (stock < 0) {
                showNotification(Alert.AlertType.ERROR, "Validation Error", "Inventory quantity cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            showNotification(Alert.AlertType.ERROR, "Validation Error", "Please enter a whole number for inventory quantity.");
            return false;
        }

        // Min validation
        int min;
        try {
            min = Integer.parseInt(minField.getText().trim());
            if (min < 0) {
                showNotification(Alert.AlertType.ERROR, "Validation Error", "Minimum inventory level cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            showNotification(Alert.AlertType.ERROR, "Validation Error", "Please enter a whole number for minimum inventory level.");
            return false;
        }

        // Max validation
        int max;
        try {
            max = Integer.parseInt(maxField.getText().trim());
            if (max < 0) {
                showNotification(Alert.AlertType.ERROR, "Validation Error", "Maximum inventory level cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            showNotification(Alert.AlertType.ERROR, "Validation Error", "Please enter a whole number for maximum inventory level.");
            return false;
        }

        // Min/Max relationship validation
        if (min > max) {
            showNotification(Alert.AlertType.ERROR, "Validation Error",
                    "Minimum inventory level must not exceed maximum inventory level.");
            return false;
        }

        // Stock within bounds validation
        if (stock < min || stock > max) {
            showNotification(Alert.AlertType.ERROR, "Validation Error",
                    "Current inventory quantity must be between minimum and maximum levels.");
            return false;
        }

        // Component requirement validation
        if (productComponents.isEmpty()) {
            showNotification(Alert.AlertType.ERROR, "Validation Error",
                    "A product must contain at least one component. Please add components before saving.");
            return false;
        }

        // Cost validation
        double totalComponentCost = calculateTotalComponentCost();
        if (price < totalComponentCost) {
            showNotification(Alert.AlertType.ERROR, "Validation Error",
                    String.format("Product price ($%.2f) must be equal to or greater than the total cost of components ($%.2f)",
                            price, totalComponentCost));
            return false;
        }

        return true;
    }

    private double calculateTotalComponentCost() {
        double totalCost = 0.0;
        for (Part component : productComponents) {
            totalCost += component.getPrice();
        }
        return totalCost;
    }

    @FXML
    private void handleCancelButton(ActionEvent event) {
        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Abandon Changes");
        confirmDialog.setHeaderText("Unsaved Product Modifications");
        confirmDialog.setContentText("You have made changes to this product. If you proceed, all modifications will be lost. Continue anyway?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            closeWindow(event);
        }
    }

    private void closeWindow(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void showNotification(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}