/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/
package com.example.w45.controller;

import com.example.w45.HelloApplication;
import com.example.w45.model.Inventory;
import com.example.w45.model.Part;
import com.example.w45.model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class AddProduct implements Initializable {

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField maxField;

    @FXML
    private TextField minField;

    @FXML
    private TextField partSearchField;

    @FXML
    private TableView<Part> availablePartsTable;

    @FXML
    private TableColumn<Part, Integer> availablePartIdColumn;

    @FXML
    private TableColumn<Part, String> availablePartNameColumn;

    @FXML
    private TableColumn<Part, Integer> availablePartStockColumn;

    @FXML
    private TableColumn<Part, Double> availablePartPriceColumn;

    @FXML
    private TableView<Part> associatedPartsTable;

    @FXML
    private TableColumn<Part, Integer> associatedPartIdColumn;

    @FXML
    private TableColumn<Part, String> associatedPartNameColumn;

    @FXML
    private TableColumn<Part, Integer> associatedPartStockColumn;

    @FXML
    private TableColumn<Part, Double> associatedPartPriceColumn;

    @FXML
    private Button addPartButton;

    @FXML
    private Button removePartButton;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Inventory inventory;
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        inventory = HelloApplication.getInventory();

        // Setup available parts table
        availablePartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        availablePartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        availablePartStockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        availablePartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Setup associated parts table
        associatedPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        associatedPartStockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        associatedPartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Load available parts
        availablePartsTable.setItems(inventory.getAllParts());

        // Set auto-generated ID
        idField.setText(String.valueOf(Inventory.getNextProductId()));
        idField.setDisable(true);
    }

    @FXML
    private void handleAddPartButton() {
        Part selectedPart = availablePartsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            associatedParts.add(selectedPart);
            associatedPartsTable.setItems(associatedParts);
        } else {
            displayNotification(Alert.AlertType.WARNING, "Selection Required", "Please select a component from the list to add to your product.");
        }
    }

    @FXML
    private void handleRemovePartButton() {
        Part selectedPart = associatedPartsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            // Confirm removal
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Remove Component");
            alert.setHeaderText("Component Removal Confirmation");
            alert.setContentText("This will remove the selected component from your product specification. Do you wish to proceed?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                associatedParts.remove(selectedPart);
                associatedPartsTable.setItems(associatedParts);
            }
        } else {
            displayNotification(Alert.AlertType.WARNING, "Selection Required", "Please select a component from the associated parts list to remove.");
        }
    }

    @FXML
    private void handleSearchPartButton() {
        String searchText = partSearchField.getText().trim();
        if (searchText.isEmpty()) {
            availablePartsTable.setItems(inventory.getAllParts());
        } else {
            try {
                int id = Integer.parseInt(searchText);
                Part part = inventory.searchPartByID(id);
                if (part != null) {
                    ObservableList<Part> searchResult = FXCollections.observableArrayList();
                    searchResult.add(part);
                    availablePartsTable.setItems(searchResult);
                } else {
                    availablePartsTable.setItems(FXCollections.observableArrayList());
                }
            } catch (NumberFormatException e) {
                // If not a number, search by name
                availablePartsTable.setItems(inventory.searchPartByName(searchText));
            }
        }
    }

    @FXML
    private void handleSaveButton(ActionEvent event) {
        try {
            // Validate inputs
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "Product name is a required field and cannot be left empty.");
                return;
            }

            double price;
            try {
                price = Double.parseDouble(priceField.getText().trim());
                if (price < 0) {
                    displayNotification(Alert.AlertType.ERROR, "Form Validation", "Product price must be a positive value.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "Please enter a valid decimal number for the product price.");
                return;
            }

            int stock;
            try {
                stock = Integer.parseInt(stockField.getText().trim());
                if (stock < 0) {
                    displayNotification(Alert.AlertType.ERROR, "Form Validation", "Stock quantity cannot be negative.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "Please enter a whole number for stock quantity.");
                return;
            }

            int min;
            try {
                min = Integer.parseInt(minField.getText().trim());
                if (min < 0) {
                    displayNotification(Alert.AlertType.ERROR, "Form Validation", "Minimum stock level cannot be negative.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "Please enter a whole number for minimum stock level.");
                return;
            }

            int max;
            try {
                max = Integer.parseInt(maxField.getText().trim());
                if (max < 0) {
                    displayNotification(Alert.AlertType.ERROR, "Form Validation", "Maximum stock level cannot be negative.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "Please enter a whole number for maximum stock level.");
                return;
            }

            // Validate min <= stock <= max
            if (min > max) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "The minimum stock level must be less than or equal to the maximum stock level.");
                return;
            }

            if (stock < min || stock > max) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation",
                        "Current stock quantity must be between the minimum and maximum levels specified.");
                return;
            }

            // Validate that product has at least one associated part
            if (associatedParts.isEmpty()) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation", "A product must contain at least one component. Please add at least one part.");
                return;
            }

            // Calculate total parts cost
            double totalPartsCost = 0.0;
            for (Part part : associatedParts) {
                totalPartsCost += part.getPrice();
            }

            // Validate product price >= total parts cost
            if (price < totalPartsCost) {
                displayNotification(Alert.AlertType.ERROR, "Form Validation",
                        "Product price ($" + price + ") must be equal to or greater than the total cost of components ($" + String.format("%.2f", totalPartsCost) + ")");
                return;
            }

            // Get ID from field
            int id = Integer.parseInt(idField.getText().trim());

            // Create new product and add associated parts
            Product newProduct = new Product(id, name, price, stock, min, max);
            for (Part part : associatedParts) {
                newProduct.addAssociatedPart(part);
            }

            // Add product to inventory
            inventory.addProduct(newProduct);

            // Close window
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            displayNotification(Alert.AlertType.ERROR, "System Error", "An unexpected error occurred: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancelButton(ActionEvent event) {
        // Confirm cancellation
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Product Creation");
        alert.setHeaderText("Discard Product Changes");
        alert.setContentText("You have unsaved changes in this product form. If you exit now, all your changes will be discarded. Continue?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    private void displayNotification(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}