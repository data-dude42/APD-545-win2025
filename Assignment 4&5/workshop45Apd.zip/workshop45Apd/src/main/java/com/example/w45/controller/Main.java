/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/

package com.example.w45.controller;

import com.example.w45.HelloApplication;
import com.example.w45.model.Inventory;
import com.example.w45.model.Part;
import com.example.w45.model.Product;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class Main implements Initializable {

    @FXML
    private TableView<Part> partsTable;

    @FXML
    private TableColumn<Part, Integer> partIdColumn;

    @FXML
    private TableColumn<Part, String> partNameColumn;

    @FXML
    private TableColumn<Part, Integer> partInventoryColumn;

    @FXML
    private TableColumn<Part, Double> partPriceColumn;

    @FXML
    private TextField partSearchField;

    @FXML
    private Button addPartButton;

    @FXML
    private Button modifyPartButton;

    @FXML
    private Button deletePartButton;

    @FXML
    private TableView<Product> productsTable;

    @FXML
    private TableColumn<Product, Integer> productIdColumn;

    @FXML
    private TableColumn<Product, String> productNameColumn;

    @FXML
    private TableColumn<Product, Integer> productInventoryColumn;

    @FXML
    private TableColumn<Product, Double> productPriceColumn;

    @FXML
    private TextField productSearchField;

    @FXML
    private Button addProductButton;

    @FXML
    private Button modifyProductButton;

    @FXML
    private Button deleteProductButton;

    @FXML
    private Button exitButton;

    private Inventory inventory;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        inventory = HelloApplication.getInventory();

        configurePartsTableColumns();
        configureProductsTableColumns();

        refreshInventoryData();
    }

    private void configurePartsTableColumns() {
        partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void configureProductsTableColumns() {
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    private void refreshInventoryData() {
        partsTable.setItems(inventory.getAllParts());
        productsTable.setItems(inventory.getAllProducts());
    }

    @FXML
    private void handleAddPartButton(ActionEvent event) {
        try {
            openForm("/view/addPart.fxml", "Add New Component");
            refreshPartsTable();
        } catch (IOException e) {
            notifyUser(Alert.AlertType.ERROR, "Navigation Failure", "Unable to open component creation form: " + e.getMessage());
        }
    }

    @FXML
    private void handleModifyPartButton(ActionEvent event) {
        Part selectedPart = partsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyPart.fxml"));
                Parent root = loader.load();

                ModifyPart controller = loader.getController();
                controller.setPart(selectedPart, partsTable.getSelectionModel().getSelectedIndex());

                Stage stage = new Stage();
                stage.setTitle("Edit Component Details");
                stage.setScene(new Scene(root));
                stage.showAndWait();

                refreshPartsTable();
            } catch (IOException e) {
                notifyUser(Alert.AlertType.ERROR, "Navigation Failure", "Unable to open component editing form: " + e.getMessage());
            }
        } else {
            notifyUser(Alert.AlertType.WARNING, "Selection Required", "You must select a component to modify from the table.");
        }
    }

    @FXML
    private void handleDeletePartButton(ActionEvent event) {
        Part selectedPart = partsTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Removal");
            alert.setHeaderText("Component Deletion");
            alert.setContentText("Are you sure you want to permanently remove this component from inventory?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                if (isPartAssociatedWithProduct(selectedPart)) {
                    notifyUser(Alert.AlertType.ERROR, "Deletion Blocked", "This component cannot be removed because it is currently used in one or more products.");
                } else {
                    inventory.deletePart(selectedPart);
                    refreshPartsTable();
                }
            }
        } else {
            notifyUser(Alert.AlertType.WARNING, "Selection Required", "You must select a component to delete from the table.");
        }
    }

    private boolean isPartAssociatedWithProduct(Part part) {
        for (Product product : inventory.getAllProducts()) {
            for (Part associatedPart : product.getAllAssociatedParts()) {
                if (associatedPart.getId() == part.getId()) {
                    return true;
                }
            }
        }
        return false;
    }

    @FXML
    private void handleSearchPartButton(ActionEvent event) {
        String query = partSearchField.getText().trim();
        if (query.isEmpty()) {
            refreshPartsTable();
            return;
        }

        try {
            int id = Integer.parseInt(query);
            Part part = inventory.searchPartByID(id);
            if (part != null) {
                ObservableList<Part> result = FXCollections.observableArrayList();
                result.add(part);
                partsTable.setItems(result);
            } else {
                partsTable.setItems(FXCollections.observableArrayList());
            }
        } catch (NumberFormatException e) {
            partsTable.setItems(inventory.searchPartByName(query));
        }
    }

    @FXML
    private void handleAddProductButton(ActionEvent event) {
        try {
            openForm("/view/addProduct.fxml", "Create New Product");
            refreshProductsTable();
        } catch (IOException e) {
            notifyUser(Alert.AlertType.ERROR, "Navigation Failure", "Unable to open product creation form: " + e.getMessage());
        }
    }

    @FXML
    private void handleModifyProductButton(ActionEvent event) {
        Product selectedProduct = productsTable.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/modifyProduct.fxml"));
                Parent root = loader.load();

                ModifyProduct controller = loader.getController();
                controller.setProduct(selectedProduct, productsTable.getSelectionModel().getSelectedIndex());

                Stage stage = new Stage();
                stage.setTitle("Edit Product Specifications");
                stage.setScene(new Scene(root));
                stage.showAndWait();

                refreshProductsTable();
            } catch (IOException e) {
                notifyUser(Alert.AlertType.ERROR, "Navigation Failure", "Unable to open product editing form: " + e.getMessage());
            }
        } else {
            notifyUser(Alert.AlertType.WARNING, "Selection Required", "You must select a product to modify from the table.");
        }
    }

    @FXML
    private void handleDeleteProductButton(ActionEvent event) {
        Product selectedProduct = productsTable.getSelectionModel().getSelectedItem();
        if (selectedProduct != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Removal");
            alert.setHeaderText("Product Deletion");
            alert.setContentText("Are you sure you want to permanently remove this product from inventory?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                if (selectedProduct.getAllAssociatedParts().size() > 0) {
                    notifyUser(Alert.AlertType.ERROR, "Deletion Blocked",
                            "This product has associated components. Remove all components from this product before deleting.");
                } else {
                    inventory.deleteProduct(selectedProduct);
                    refreshProductsTable();
                }
            }
        } else {
            notifyUser(Alert.AlertType.WARNING, "Selection Required", "You must select a product to delete from the table.");
        }
    }

    @FXML
    private void handleSearchProductButton(ActionEvent event) {
        String query = productSearchField.getText().trim();
        if (query.isEmpty()) {
            refreshProductsTable();
            return;
        }

        try {
            int id = Integer.parseInt(query);
            Product product = inventory.searchProductByID(id);
            if (product != null) {
                ObservableList<Product> result = FXCollections.observableArrayList();
                result.add(product);
                productsTable.setItems(result);
            } else {
                productsTable.setItems(FXCollections.observableArrayList());
            }
        } catch (NumberFormatException e) {
            productsTable.setItems(inventory.searchProductByName(query));
        }
    }

    @FXML
    private void handleExitButton(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Application");
        alert.setHeaderText("Close Inventory System");
        alert.setContentText("Are you sure you want to exit? Any unsaved changes will be lost.");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) exitButton.getScene().getWindow();
            stage.close();
        }
    }

    private void refreshPartsTable() {
        partsTable.setItems(inventory.getAllParts());
    }

    private void refreshProductsTable() {
        productsTable.setItems(inventory.getAllProducts());
    }

    private void openForm(String resourcePath, String title) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(resourcePath));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.showAndWait();
    }

    private void notifyUser(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}