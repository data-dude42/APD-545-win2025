/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/

package com.example.w45.controller;

import com.example.w45.HelloApplication;
import com.example.w45.model.InHouse;
import com.example.w45.model.Inventory;
import com.example.w45.model.Outsourced;
import com.example.w45.model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ModifyPart implements Initializable {

    @FXML
    private RadioButton inHouseRadio;

    @FXML
    private RadioButton outsourcedRadio;

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField maxField;

    @FXML
    private TextField minField;

    @FXML
    private TextField machineIdField;

    @FXML
    private Label machineIdLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Inventory inventoryManager;
    private ToggleGroup partSourceGroup;
    private Part existingPart;
    private int partIndex;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        inventoryManager = HelloApplication.getInventory();

        partSourceGroup = new ToggleGroup();
        inHouseRadio.setToggleGroup(partSourceGroup);
        outsourcedRadio.setToggleGroup(partSourceGroup);
    }

    public void setPart(Part part, int index) {
        this.existingPart = part;
        this.partIndex = index;

        populateFormFields(part);
        configureSourceTypeRadio(part);

        idField.setDisable(true);
    }

    private void populateFormFields(Part part) {
        idField.setText(String.valueOf(part.getId()));
        nameField.setText(part.getName());
        stockField.setText(String.valueOf(part.getStock()));
        priceField.setText(String.valueOf(part.getPrice()));
        maxField.setText(String.valueOf(part.getMax()));
        minField.setText(String.valueOf(part.getMin()));
    }

    private void configureSourceTypeRadio(Part part) {
        if (part instanceof InHouse) {
            inHouseRadio.setSelected(true);
            machineIdLabel.setText("Machine ID");
            machineIdField.setText(String.valueOf(((InHouse) part).getMachine()));
        } else {
            outsourcedRadio.setSelected(true);
            machineIdLabel.setText("Company Name");
            machineIdField.setText(((Outsourced) part).getCompanyName());
        }
    }

    @FXML
    private void handleInHouseRadio() {
        machineIdLabel.setText("Machine ID");
        machineIdField.setPromptText("Enter manufacturing machine ID");

        if (existingPart instanceof Outsourced) {
            machineIdField.clear();
        }
    }

    @FXML
    private void handleOutsourcedRadio() {
        machineIdLabel.setText("Company Name");
        machineIdField.setPromptText("Enter supplier company name");

        if (existingPart instanceof InHouse) {
            machineIdField.clear();
        }
    }

    @FXML
    private void handleSaveButton(ActionEvent event) {
        try {
            if (!validateInputs()) {
                return;
            }

            String name = nameField.getText().trim();
            double price = Double.parseDouble(priceField.getText().trim());
            int stock = Integer.parseInt(stockField.getText().trim());
            int min = Integer.parseInt(minField.getText().trim());
            int max = Integer.parseInt(maxField.getText().trim());
            int id = Integer.parseInt(idField.getText().trim());

            saveModifiedPart(id, name, price, stock, min, max);
            closeWindow(event);

        } catch (Exception e) {
            displayFeedback(Alert.AlertType.ERROR, "System Error", "Unexpected error occurred: " + e.getMessage());
        }
    }

    private boolean validateInputs() {
        if (nameField.getText().trim().isEmpty()) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Component name field cannot be empty.");
            return false;
        }

        double price;
        try {
            price = Double.parseDouble(priceField.getText().trim());
            if (price < 0) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Unit price must be a positive value.");
                return false;
            }
        } catch (NumberFormatException e) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Please enter a valid decimal number for unit price.");
            return false;
        }

        int stock;
        try {
            stock = Integer.parseInt(stockField.getText().trim());
            if (stock < 0) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Current stock cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Please enter a whole number for current stock level.");
            return false;
        }

        int min;
        try {
            min = Integer.parseInt(minField.getText().trim());
            if (min < 0) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Minimum stock threshold cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Please enter a whole number for minimum stock threshold.");
            return false;
        }

        int max;
        try {
            max = Integer.parseInt(maxField.getText().trim());
            if (max < 0) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Maximum stock capacity cannot be negative.");
                return false;
            }
        } catch (NumberFormatException e) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Please enter a whole number for maximum stock capacity.");
            return false;
        }

        if (min > max) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation",
                    "Minimum stock threshold cannot exceed maximum stock capacity.");
            return false;
        }

        int stock2 = Integer.parseInt(stockField.getText().trim());
        if (stock2 < min || stock2 > max) {
            displayFeedback(Alert.AlertType.ERROR, "Data Validation",
                    "Current stock level must be between minimum threshold and maximum capacity.");
            return false;
        }

        return true;
    }

    private void saveModifiedPart(int id, String name, double price, int stock, int min, int max) {
        if (inHouseRadio.isSelected()) {
            int machineId;
            try {
                machineId = Integer.parseInt(machineIdField.getText().trim());
            } catch (NumberFormatException e) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Please enter a valid numeric machine ID.");
                return;
            }

            InHouse updatedPart = new InHouse(id, name, price, stock, min, max, machineId);
            inventoryManager.updatePart(partIndex, updatedPart);
        } else {
            String companyName = machineIdField.getText().trim();
            if (companyName.isEmpty()) {
                displayFeedback(Alert.AlertType.ERROR, "Data Validation", "Supplier company name cannot be empty.");
                return;
            }

            Outsourced updatedPart = new Outsourced(id, name, price, stock, min, max, companyName);
            inventoryManager.updatePart(partIndex, updatedPart);
        }
    }

    @FXML
    private void handleCancelButton(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Discard Changes");
        alert.setHeaderText("Unsaved Modifications");
        alert.setContentText("You have modified this component. If you continue, all changes will be discarded. Are you sure?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            closeWindow(event);
        }
    }

    private void closeWindow(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void displayFeedback(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}