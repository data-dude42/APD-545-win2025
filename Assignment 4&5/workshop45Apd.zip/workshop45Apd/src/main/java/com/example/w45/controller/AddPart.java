/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/
package com.example.w45.controller;
import com.example.w45.HelloApplication;
import com.example.w45.model.InHouse;
import com.example.w45.model.Inventory;
import com.example.w45.model.Outsourced;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class AddPart implements Initializable {

    @FXML
    private RadioButton inHouseRadio;

    @FXML
    private RadioButton outsourcedRadio;

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField stockField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField maxField;

    @FXML
    private TextField minField;

    @FXML
    private TextField machineIdField;

    @FXML
    private Label machineIdLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Inventory inventory;
    private ToggleGroup sourceToggleGroup;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        inventory = HelloApplication.getInventory();

        // Setup toggle group for radio buttons
        sourceToggleGroup = new ToggleGroup();
        inHouseRadio.setToggleGroup(sourceToggleGroup);
        outsourcedRadio.setToggleGroup(sourceToggleGroup);
        inHouseRadio.setSelected(true);

        // Set auto-generated ID
        idField.setText(String.valueOf(Inventory.getNextPartId()));
        idField.setDisable(true);
    }

    @FXML
    private void handleInHouseRadio() {
        machineIdLabel.setText("Machine ID");
        machineIdField.setPromptText("Enter machine ID");
    }

    @FXML
    private void handleOutsourcedRadio() {
        machineIdLabel.setText("Company Name");
        machineIdField.setPromptText("Enter company name");
    }

    @FXML
    private void handleSaveButton(ActionEvent event) {
        try {
            // Validate inputs
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Part name field cannot be left blank.");
                return;
            }

            double price;
            try {
                price = Double.parseDouble(priceField.getText().trim());
                if (price < 0) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Price must be a positive value.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Please enter a valid numerical value for price.");
                return;
            }

            int stock;
            try {
                stock = Integer.parseInt(stockField.getText().trim());
                if (stock < 0) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Inventory count must be a positive number.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Please enter a whole number for inventory count.");
                return;
            }

            int min;
            try {
                min = Integer.parseInt(minField.getText().trim());
                if (min < 0) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Minimum value must be non-negative.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Please enter a whole number for minimum value.");
                return;
            }

            int max;
            try {
                max = Integer.parseInt(maxField.getText().trim());
                if (max < 0) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Maximum value must be non-negative.");
                    return;
                }
            } catch (NumberFormatException e) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Please enter a whole number for maximum value.");
                return;
            }

            // Validate min <= stock <= max
            if (min > max) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed",
                        "Logical error: Minimum value exceeds maximum value.");
                return;
            }

            if (stock < min || stock > max) {
                displayWarning(Alert.AlertType.ERROR, "Validation Failed",
                        "Inventory count must be within minimum and maximum limits.");
                return;
            }

            // Get ID from field
            int id = Integer.parseInt(idField.getText().trim());

            // Create part based on radio button selection
            if (inHouseRadio.isSelected()) {
                int machineId;
                try {
                    machineId = Integer.parseInt(machineIdField.getText().trim());
                } catch (NumberFormatException e) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Machine ID must be a numerical.");
                    return;
                }

                InHouse newPart = new InHouse(id, name, price, stock, min, max, machineId);
                inventory.addPart(newPart);
            } else {
                String companyName = machineIdField.getText().trim();
                if (companyName.isEmpty()) {
                    displayWarning(Alert.AlertType.ERROR, "Validation Failed", "Supplier name cannot be left blank.");
                    return;
                }

                Outsourced newPart = new Outsourced(id, name, price, stock, min, max, companyName);
                inventory.addPart(newPart);
            }

            // Close window
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            displayWarning(Alert.AlertType.ERROR, "System Error", "Unexpected error occurred: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancelButton(ActionEvent event) {
        // Confirm cancellation
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Abort Operation");
        alert.setHeaderText("Discard Changes?");
        alert.setContentText("You have unsaved changes that will be lost if you continue. Proceed anyway?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    private void displayWarning(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}