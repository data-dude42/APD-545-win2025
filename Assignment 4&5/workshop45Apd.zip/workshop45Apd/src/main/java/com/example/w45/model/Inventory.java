package com.example.w45.model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Inventory {
    private ObservableList<Part> allParts;
    private ObservableList<Product> allProducts;
    private static int partIdCounter = 1;
    private static int productIdCounter = 1;

    public Inventory() {
        allParts = FXCollections.observableArrayList();
        allProducts = FXCollections.observableArrayList();
        loadInitialData();
    }

    public static int getNextPartId() {
        return partIdCounter++;
    }

    public static int getNextProductId() {
        return productIdCounter++;
    }

    public void addPart(Part newPart) {
        allParts.add(newPart);
    }

    public void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    public Part searchPartByID(int partId) {
        for (Part part : allParts) {
            if (part.getId() == partId) {
                return part;
            }
        }
        return null;
    }

    public Product searchProductByID(int productId) {
        for (Product product : allProducts) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null;
    }

    public ObservableList<Part> searchPartByName(String name) {
        ObservableList<Part> resultList = FXCollections.observableArrayList();
        for (Part part : allParts) {
            if (part.getName().toLowerCase().contains(name.toLowerCase())) {
                resultList.add(part);
            }
        }
        return resultList;
    }

    public ObservableList<Product> searchProductByName(String name) {
        ObservableList<Product> resultList = FXCollections.observableArrayList();
        for (Product product : allProducts) {
            if (product.getName().toLowerCase().contains(name.toLowerCase())) {
                resultList.add(product);
            }
        }
        return resultList;
    }

    public void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }

    public void updateProduct(int index, Product newProduct) {
        allProducts.set(index, newProduct);
    }

    public boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    public boolean deleteProduct(Product selectedProduct) {
        // Check if product has associated parts
        if (selectedProduct.getAllAssociatedParts().size() > 0) {
            return false;
        }
        return allProducts.remove(selectedProduct);
    }

    public ObservableList<Part> getAllParts() {
        return allParts;
    }

    public ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    // Load initial data with 10 products and at least 1 part per product
    private void loadInitialData() {
        // Create some parts
        Part part1 = new InHouse(getNextPartId(), "LCD Panel", 199.50, 25, 5, 60, 401);
        Part part2 = new InHouse(getNextPartId(), "CPU Chip", 129.99, 40, 10, 80, 402);
        Part part3 = new Outsourced(getNextPartId(), "Power Cell", 74.50, 30, 8, 50, "PowerTech");
        Part part4 = new Outsourced(getNextPartId(), "RAM Module", 89.99, 45, 10, 100, "MemorySolutions");
        Part part5 = new InHouse(getNextPartId(), "Image Sensor", 42.75, 35, 12, 70, 403);
        Part part6 = new InHouse(getNextPartId(), "Audio Driver", 18.25, 50, 15, 100, 404);
        Part part7 = new Outsourced(getNextPartId(), "Biometric Scanner", 32.50, 22, 6, 45, "SecureScan");
        Part part8 = new InHouse(getNextPartId(), "Power Port", 12.99, 60, 20, 120, 405);
        Part part9 = new Outsourced(getNextPartId(), "Voice Pickup", 9.75, 40, 15, 80, "AudioTech");
        Part part10 = new InHouse(getNextPartId(), "Antenna Module", 7.50, 70, 25, 150, 406);
        Part part11 = new Outsourced(getNextPartId(), "Signal Module", 5.99, 55, 18, 110, "VibraTronics");
        Part part12 = new InHouse(getNextPartId(), "Logic Board", 45.25, 20, 5, 40, 407);

        addPart(part1);
        addPart(part2);
        addPart(part3);
        addPart(part4);
        addPart(part5);
        addPart(part6);
        addPart(part7);
        addPart(part8);
        addPart(part9);
        addPart(part10);
        addPart(part11);
        addPart(part12);

        Product product1 = new Product(getNextProductId(), "Galaxy Elite", 999.99, 15, 5, 30);
        product1.addAssociatedPart(part1);
        product1.addAssociatedPart(part2);
        product1.addAssociatedPart(part3);
        product1.addAssociatedPart(part5);

        Product product2 = new Product(getNextProductId(), "SlateBook Pro", 749.99, 12, 3, 25);
        product2.addAssociatedPart(part1);
        product2.addAssociatedPart(part2);
        product2.addAssociatedPart(part4);

        Product product3 = new Product(getNextProductId(), "WristTech 3", 349.99, 20, 8, 40);
        product3.addAssociatedPart(part1);
        product3.addAssociatedPart(part11);

        Product product4 = new Product(getNextProductId(), "PlayBox 5", 499.99, 8, 2, 15);
        product4.addAssociatedPart(part2);
        product4.addAssociatedPart(part4);
        product4.addAssociatedPart(part6);
        Product product5 = new Product(getNextProductId(), "EchoWave", 179.99, 25, 10, 50);
        product5.addAssociatedPart(part6);
        product5.addAssociatedPart(part9);

        Product product6 = new Product(getNextProductId(), "AirBuds Pro", 159.99, 30, 10, 60);
        product6.addAssociatedPart(part6);
        product6.addAssociatedPart(part3);

        Product product7 = new Product(getNextProductId(), "Fitness Tracker", 129.99, 22, 8, 45);
        product7.addAssociatedPart(part3);
        product7.addAssociatedPart(part11);

        Product product8 = new Product(getNextProductId(), "PowerStation X", 1299.99, 5, 2, 12);
        product8.addAssociatedPart(part2);
        product8.addAssociatedPart(part4);
        product8.addAssociatedPart(part12);

        Product product9 = new Product(getNextProductId(), "UltraBook Elite", 1499.99, 10, 3, 20);
        product9.addAssociatedPart(part1);
        product9.addAssociatedPart(part2);
        product9.addAssociatedPart(part3);

        Product product10 = new Product(getNextProductId(), "VisionPro X", 399.99, 7, 2, 15);
        product10.addAssociatedPart(part1);
        product10.addAssociatedPart(part10);

        addProduct(product1);
        addProduct(product2);
        addProduct(product3);
        addProduct(product4);
        addProduct(product5);
        addProduct(product6);
        addProduct(product7);
        addProduct(product8);
        addProduct(product9);
        addProduct(product10);
    }
}