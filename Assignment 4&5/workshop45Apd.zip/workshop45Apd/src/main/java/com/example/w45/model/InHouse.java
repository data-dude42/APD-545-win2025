package com.example.w45.model;

public class InHouse extends Part {
    private int machineId;

    /**
     * Constructor to create a new InHouse part
     *
     * @param id The unique identifier for this part
     * @param name The name of the part
     * @param price The unit price of the part
     * @param stock The current inventory level
     * @param min The minimum allowed inventory level
     * @param max The maximum allowed inventory level
     * @param machineId The ID of the machine that manufactures this part
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        // Initialize the parent class fields
        super(id, name, price, stock, min, max);
        // Initialize the machine ID
        this.machineId = machineId;
    }

    /**
     * Sets the machine ID for this part
     *
     * @param machineId The ID of the machine to be assigned
     */
    public void setMachine(int machineId) {
        this.machineId = machineId;
    }

    public int getMachine() {
        return machineId;
    }
}