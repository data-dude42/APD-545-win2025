/**********************************************
 Workshop #
 Course:APD 545 - Semester-5
 Last Name:singh
 First Name:paras
 ID:165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:16 March 2025
 **********************************************/
package com.example.w45.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Login {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Button cancelButton;

    private final String AUTH_USER_CRED = "paras";
    private final String AUTH_PASS_CRED = "7905";

    @FXML
    private void handleLoginButton(ActionEvent event) {
        String inputUser = usernameField.getText();
        String inputPass = passwordField.getText();

        if (inputUser.equals(AUTH_USER_CRED) && inputPass.equals(AUTH_PASS_CRED)) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main.fxml"));
                Parent root = loader.load();
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setTitle("Inventory Management System");
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                displayMessage(Alert.AlertType.ERROR, "System Error", "Navigation failed: " + e.getMessage());
            }
        } else {
            displayMessage(Alert.AlertType.ERROR, "Authentication Failed", "The credentials you entered are not recognized. Please verify and try again.");
        }
    }

    @FXML
    private void handleCancelButton(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    private void displayMessage(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}