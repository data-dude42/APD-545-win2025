/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/fxml/login.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        stage.setTitle("Autoloan Login.ca");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}