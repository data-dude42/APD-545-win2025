/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.controller;

import com.example.carloan.model.Loan;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.util.List;
import java.util.function.Consumer;

public class SavedRateController {

    // ListView component to display saved loan rates
    @FXML
    private ListView<String> savedRatesListView;

    // Button to close the saved rates window
    @FXML
    private Button closeButton;

    // List to store loan objects associated with the saved rates
    private List<Loan> loans;

    // Consumer function to handle loan selection
    private Consumer<Loan> onLoanSelected;

    /**
     * Initializes the Saved Rate Controller.
     * Sets up the event listener for the close button to ensure proper window
     * closure.
     */
    @FXML
    public void initialize() {
        closeButton.setOnAction(event -> closeWindow());
    }

    /**
     * Populates the ListView with saved rates and initializes loan data.
     *
     * @param savedRates     List of saved rates as observable strings for display.
     * @param loans          Corresponding list of Loan objects.
     * @param onLoanSelected Consumer function to handle the selected loan when a
     *                       user double-clicks an item.
     */
    public void setSavedRates(ObservableList<String> savedRates, List<Loan> loans, Consumer<Loan> onLoanSelected) {
        this.savedRatesListView.setItems(savedRates);
        this.loans = loans;
        this.onLoanSelected = onLoanSelected;
    }

    /**
     * Handles a double-click event on the ListView.
     * If a valid item is selected, the corresponding loan is passed to the consumer
     * function.
     *
     * @param event The MouseEvent triggering this method.
     */
    @FXML
    public void handleDoubleClick(MouseEvent event) {
        // Check if the user performed a double-click
        if (event.getClickCount() == 2) {
            int selectedIndex = savedRatesListView.getSelectionModel().getSelectedIndex();

            // Ensure the selected index is valid before proceeding
            if (selectedIndex >= 0 && selectedIndex < loans.size()) {
                Loan selectedLoan = loans.get(selectedIndex);
                onLoanSelected.accept(selectedLoan); // Trigger the consumer function with the selected loan
                closeWindow(); // Close the window after selection
            }
        }
    }

    /**
     * Handles the close button action by calling the closeWindow method.
     */
    @FXML
    public void handleClose() {
        closeWindow();
    }

    /**
     * Closes the current window associated with this controller.
     */
    private void closeWindow() {
        Stage stage = (Stage) closeButton.getScene().getWindow();
        stage.close();
    }
}
