/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;

public class Loan {
    private double amount; // Total loan amount
    private double downPayment; // Initial payment made upfront
    private double interestRate; // Annual interest rate (percentage)
    private int duration; // Loan term duration in months
    private String frequency; // Payment frequency (Monthly, Weekly, Bi-weekly)
    private Customer customer; // Associated customer details
    private Vehicle vehicle; // Associated vehicle details

    /**
     * Default constructor initializing an empty Loan object.
     */
    public Loan() {
    }

    /**
     * Parameterized constructor for initializing a Loan object with specific values.
     *
     * @param amount       Total loan amount
     * @param downPayment  Initial down payment
     * @param interestRate Annual interest rate in percentage
     * @param duration     Loan term in months
     * @param frequency    Payment frequency (e.g., Monthly, Weekly, Bi-weekly)
     * @param customer     Customer associated with the loan
     * @param vehicle      Vehicle associated with the loan
     */
    public Loan(double amount, double downPayment, double interestRate, int duration, String frequency, Customer customer, Vehicle vehicle) {
        this.amount = amount;
        this.downPayment = downPayment;
        this.interestRate = interestRate;
        this.duration = duration;
        this.frequency = frequency;
        this.customer = customer;
        this.vehicle = vehicle;
    }

    // Getter and Setter methods

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getDownPayment() {
        return downPayment;
    }

    public void setDownPayment(double downPayment) {
        this.downPayment = downPayment;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    /**
     * Overrides the default toString method to return a formatted string representation of the Loan object.
     *
     * @return String representation of the Loan object.
     */
    @Override
    public String toString() {
        return "Loan{" +
                "amount=" + amount +
                ", downPayment=" + downPayment +
                ", interestRate=" + interestRate +
                ", duration=" + duration +
                ", frequency='" + frequency + '\'' +
                ", customer=" + customer +
                ", vehicle=" + vehicle +
                '}';
    }
}

