/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;

/**
 * The {@code Vehicle} class represents a vehicle with essential attributes such as type, age, and price.
 * This class provides getter and setter methods for encapsulation, along with a parameterized constructor
 * for initializing vehicle details. Additionally, a default constructor is provided for flexibility in object creation.
 */
public class Vehicle {
    // Represents the type or category of the vehicle (e.g., Car, Truck, SUV, Motorcycle)
    private String type;

    // Represents the age of the vehicle, typically expressed in years or descriptive terms like "New" or "Used"
    private String age;

    // Represents the price of the vehicle in monetary value
    private double price;

    /**
     * Default constructor that initializes a Vehicle object without setting any attributes.
     * This constructor is useful when attributes will be assigned later using setter methods.
     */
    public Vehicle() {
        // No initialization required in the default constructor
    }

    /**
     * Parameterized constructor that initializes a Vehicle object with specific values.
     *
     * @param type  The type or category of the vehicle (e.g., Sedan, SUV, Truck, etc.)
     * @param age   The age of the vehicle (e.g., "New", "Used", "2 years old")
     * @param price The price of the vehicle in monetary value
     */
    public Vehicle(String type, String age, double price) {
        this.type = type;
        this.age = age;
        this.price = price;
    }

    /**
     * Retrieves the type of the vehicle.
     *
     * @return A string representing the type of the vehicle (e.g., "Sedan", "SUV", "Truck").
     */
    public String getType() {
        return type;
    }

    /**
     * Updates the type of the vehicle.
     *
     * @param type A string representing the new type of the vehicle.
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * Retrieves the age of the vehicle.
     *
     * @return A string representing the age of the vehicle (e.g., "New", "Used", "3 years old").
     */
    public String getAge() {
        return age;
    }

    /**
     * Updates the age of the vehicle.
     *
     * @param age A string representing the new age of the vehicle.
     */
    public void setAge(String age) {
        this.age = age;
    }

    /**
     * Retrieves the price of the vehicle.
     *
     * @return A double value representing the price of the vehicle.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Updates the price of the vehicle.
     *
     * @param price A double value representing the new price of the vehicle.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Returns a string representation of the Vehicle object, including its type, age, and price.
     *
     * @return A formatted string containing vehicle details.
     */
    @Override
    public String toString() {
        return "Vehicle{" +
                "type='" + type + '\'' +
                ", age='" + age + '\'' +
                ", price=" + price +
                '}';
    }
}
