/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.time.LocalDate;

public class LoanAmortization {
    private final SimpleIntegerProperty paymentNo;
    private final SimpleObjectProperty<LocalDate> paymentDate;
    private final SimpleDoubleProperty paymentAmount;
    private final SimpleDoubleProperty principalPayment;
    private final SimpleDoubleProperty interestPayment;
    private final SimpleDoubleProperty remainingBalance;

    /**
     * Constructs a LoanAmortization object representing a single loan payment.
     *
     * @param paymentNo        The sequential payment number.
     * @param paymentDate      The date on which the payment is due.
     * @param paymentAmount    The total amount of the payment.
     * @param principalPayment The portion of the payment that goes towards the principal.
     * @param interestPayment  The portion of the payment that covers interest.
     * @param remainingBalance The remaining loan balance after this payment.
     */
    public LoanAmortization(int paymentNo, LocalDate paymentDate, double paymentAmount, double principalPayment, double interestPayment, double remainingBalance) {
        this.paymentNo = new SimpleIntegerProperty(paymentNo);
        this.paymentDate = new SimpleObjectProperty<>(paymentDate);
        this.paymentAmount = new SimpleDoubleProperty(paymentAmount);
        this.principalPayment = new SimpleDoubleProperty(principalPayment);
        this.interestPayment = new SimpleDoubleProperty(interestPayment);
        this.remainingBalance = new SimpleDoubleProperty(remainingBalance);
    }

    /**
     * Gets the payment number.
     * @return The sequential payment number.
     */
    public int getPaymentNo() {
        return paymentNo.get();
    }

    /**
     * Sets the payment number.
     * @param paymentNo The new payment number.
     */
    public void setPaymentNo(int paymentNo) {
        this.paymentNo.set(paymentNo);
    }

    /**
     * Gets the payment date.
     * @return The date of the payment.
     */
    public LocalDate getPaymentDate() {
        return paymentDate.get();
    }

    /**
     * Sets the payment date.
     * @param paymentDate The new payment date.
     */
    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate.set(paymentDate);
    }

    /**
     * Gets the total payment amount.
     * @return The total payment amount.
     */
    public double getPaymentAmount() {
        return paymentAmount.get();
    }

    /**
     * Sets the payment amount.
     * @param paymentAmount The new payment amount.
     */
    public void setPaymentAmount(double paymentAmount) {
        this.paymentAmount.set(paymentAmount);
    }

    /**
     * Gets the principal portion of the payment.
     * @return The principal payment amount.
     */
    public double getPrincipalPayment() {
        return principalPayment.get();
    }

    /**
     * Sets the principal payment amount.
     * @param principalPayment The new principal payment amount.
     */
    public void setPrincipalPayment(double principalPayment) {
        this.principalPayment.set(principalPayment);
    }

    /**
     * Gets the interest portion of the payment.
     * @return The interest payment amount.
     */
    public double getInterestPayment() {
        return interestPayment.get();
    }

    /**
     * Sets the interest payment amount.
     * @param interestPayment The new interest payment amount.
     */
    public void setInterestPayment(double interestPayment) {
        this.interestPayment.set(interestPayment);
    }

    /**
     * Gets the remaining balance after this payment.
     * @return The remaining balance.
     */
    public double getRemainingBalance() {
        return remainingBalance.get();
    }

    /**
     * Sets the remaining balance after this payment.
     * @param remainingBalance The new remaining balance.
     */
    public void setRemainingBalance(double remainingBalance) {
        this.remainingBalance.set(remainingBalance);
    }

    /**
     * Provides property access methods for data binding in UI applications.
     */
    public SimpleIntegerProperty paymentNoProperty() {
        return paymentNo;
    }

    public SimpleObjectProperty<LocalDate> paymentDateProperty() {
        return paymentDate;
    }

    public SimpleDoubleProperty paymentAmountProperty() {
        return paymentAmount;
    }

    public SimpleDoubleProperty principalPaymentProperty() {
        return principalPayment;
    }

    public SimpleDoubleProperty interestPaymentProperty() {
        return interestPayment;
    }

    public SimpleDoubleProperty remainingBalanceProperty() {
        return remainingBalance;
    }
}
