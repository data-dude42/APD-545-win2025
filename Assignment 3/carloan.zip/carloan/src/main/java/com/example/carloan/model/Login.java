/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;
import java.util.HashMap;
import java.util.Map;
public class Login {

    /** The username entered by the user during login. */
    private String userName;

    /** The password entered by the user during login. */
    private String password;

    /**
     * A static map that stores predefined valid user credentials.
     * The keys represent usernames, and the values are their corresponding passwords.
     */
    private static final Map<String, String> VALID_CREDENTIALS = new HashMap<>();

    // Static initializer block to populate the valid credentials map
    static {
        VALID_CREDENTIALS.put("paras", "paras7905");
        VALID_CREDENTIALS.put("sukh", "sukh7905");
    }

    /**
     * Constructs a new {@code Login} instance with the provided username and password.
     *
     * @param userName The username input provided by the user.
     * @param password The password input provided by the user.
     */
    public Login(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    /**
     * Validates the entered credentials by checking them against the predefined valid credentials.
     *
     * @return {@code true} if the provided username and password match a valid entry, {@code false} otherwise.
     */
    public boolean validate() {
        return VALID_CREDENTIALS.containsKey(userName) &&
                VALID_CREDENTIALS.get(userName).equals(password);
    }

    /**
     * Retrieves the username associated with this login attempt.
     *
     * @return The username entered by the user.
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Updates the username associated with this login instance.
     *
     * @param userName The new username to be set.
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Updates the password associated with this login instance.
     * <p><b>Note:</b> There is no getter method for the password due to security concerns.</p>
     *
     * @param password The new password to be set.
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
