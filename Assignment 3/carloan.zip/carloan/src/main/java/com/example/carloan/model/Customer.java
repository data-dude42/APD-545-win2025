/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;

public class Customer {

    // Private fields to store customer details
    private String name;     // Stores the customer's full name
    private String phone;    // Stores the customer's contact phone number
    private String city;     // Stores the name of the city where the customer resides
    private String province; // Stores the name of the province where the customer resides

    /**
     * Default constructor that initializes a Customer object with no values.
     * This constructor allows the creation of an empty Customer instance,
     * where attributes can be set later using setter methods.
     */
    public Customer() {
        // No-argument constructor is used here to create instances dynamically.
    }

    /**
     * Parameterized constructor that initializes a Customer object with specific values.
     *
     * @param name     The full name of the customer
     * @param phone    The contact phone number of the customer
     * @param city     The city where the customer resides
     * @param province The province where the customer resides
     */
    public Customer(String name, String phone, String city, String province) {
        this.name = name;
        this.phone = phone;
        this.city = city;
        this.province = province;
    }

    /**
     * Retrieves the name of the customer.
     *
     * @return A string representing the customer's full name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the customer's name with a new value.
     *
     * @param name The new name to set for the customer
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Retrieves the phone number of the customer.
     *
     * @return A string representing the customer's contact phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Updates the customer's phone number with a new value.
     *
     * @param phone The new phone number to set for the customer
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Retrieves the city where the customer resides.
     *
     * @return A string representing the name of the customer's city
     */
    public String getCity() {
        return city;
    }

    /**
     * Updates the customer's city with a new value.
     *
     * @param city The new city to set for the customer
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Retrieves the province where the customer resides.
     *
     * @return A string representing the name of the customer's province
     */
    public String getProvince() {
        return province;
    }

    /**
     * Updates the customer's province with a new value.
     *
     * @param province The new province to set for the customer
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * Provides a string representation of the Customer object,
     * displaying all attribute values in a formatted manner.
     *
     * @return A string describing the customer with their name, phone, city, and province
     */
    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", city='" + city + '\'' +
                ", province='" + province + '\'' +
                '}';
    }
}

