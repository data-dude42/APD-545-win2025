/**********************************************
        Workshop #
        Course:APD545 - SEM-05
        Last Name: SINGH
        First Name: PARAS
        ID: 165-114-232
        Section:NCC
        This assignment represents my own work in accordance with Seneca Academic Policy.
        Signature
        Date: 2 March 2025
        **********************************************/

package com.example.carloan.controller;

import com.example.carloan.model.LoanAmortization;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import java.util.Locale;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class AmortizationController {

        @FXML
        private TableView<LoanAmortization> amortizationTable; // TableView to display amortization details

        @FXML
        private TableColumn<LoanAmortization, Integer> paymentNoColumn; // Column for payment number

        @FXML
        private TableColumn<LoanAmortization, String> paymentDateColumn; // Column for payment date

        @FXML
        private TableColumn<LoanAmortization, String> paymentAmountColumn; // Column for total payment amount

        @FXML
        private TableColumn<LoanAmortization, String> principalPaymentColumn; // Column for principal payment amount

        @FXML
        private TableColumn<LoanAmortization, String> interestPaymentColumn; // Column for interest payment amount

        @FXML
        private TableColumn<LoanAmortization, String> remainingBalanceColumn; // Column for remaining balance after
                                                                              // payment

        @FXML
        private Button closeButton; // Button to close the amortization window

        // Formatter for displaying currency values in US format
        private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

        // Formatter for displaying dates in "MMM dd, yyyy" format (e.g., "Jan 01,
        // 2025")
        private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MMM dd, yyyy");

        /**
         * Initializes the controller and sets up the TableView columns with appropriate
         * data formatting.
         * This method is automatically called by JavaFX after the FXML file is loaded.
         */
        @FXML
        public void initialize() {

                // Configuring the payment number column to display integer values
                paymentNoColumn.setCellValueFactory(cellData -> cellData.getValue().paymentNoProperty().asObject());

                // Configuring the payment date column with formatted date values
                paymentDateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                                cellData.getValue().getPaymentDate().format(dateFormatter)));

                // Configuring the payment amount column with formatted currency values
                paymentAmountColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                                currencyFormat.format(cellData.getValue().getPaymentAmount())));

                // Configuring the principal payment column with formatted currency values
                principalPaymentColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                                currencyFormat.format(cellData.getValue().getPrincipalPayment())));

                // Configuring the interest payment column with formatted currency values
                interestPaymentColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                                currencyFormat.format(cellData.getValue().getInterestPayment())));

                // Configuring the remaining balance column with formatted currency values
                remainingBalanceColumn.setCellValueFactory(cellData -> new SimpleStringProperty(
                                currencyFormat.format(cellData.getValue().getRemainingBalance())));

                // Setting the action event for the close button
                closeButton.setOnAction(event -> handleClose());
        }

        /**
         * Populates the amortization TableView with a list of LoanAmortization objects.
         *
         * @param data A list of LoanAmortization records representing amortization
         *             schedule details.
         */
        public void setAmortizationData(List<LoanAmortization> data) {
                // Converting the input list into an observable list and assigning it to the
                // TableView
                amortizationTable.setItems(FXCollections.observableArrayList(data));
        }

        /**
         * Handles the closing of the amortization window when the user clicks the close
         * button.
         * This method retrieves the current stage and closes it.
         */
        @FXML
        public void handleClose() {
                // Retrieve the stage associated with the close button and close the window
                Stage stage = (Stage) closeButton.getScene().getWindow();
                stage.close();
        }
}
