/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.controller;

import com.example.carloan.HelloApplication;
import com.example.carloan.model.Login;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField; // Text field for entering the username

    @FXML
    private PasswordField passwordField; // Password field for entering the password

    @FXML
    private Button loginButton; // Button to trigger login process

    /**
     * This method is automatically called when the FXML file is loaded.
     * It initializes the login screen and sets up event listeners for UI
     * components.
     */
    @FXML
    public void initialize() {
        // Attach event listener to the login button, ensuring it triggers login
        // handling when clicked
        loginButton.setOnAction(event -> handleLogin());
    }

    /**
     * Handles the login process by validating the entered username and password.
     * If the credentials are correct, it proceeds to open the main application
     * window.
     * Otherwise, it displays an alert indicating a failed login attempt.
     */
    @FXML
    public void handleLogin() {
        // Retrieve user inputs from the respective text fields, trimming unnecessary
        // spaces from username
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        // Create a Login object to validate the user credentials
        Login login = new Login(username, password);

        // Check if the provided username and password are valid
        if (login.validate()) {
            try {
                // If credentials are valid, proceed to open the main application window
                openMainApplication();
            } catch (IOException e) {
                // Display an error message if opening the main application fails
                showAlert("Error", "Failed to open the main application: " + e.getMessage());
            }
        } else {
            // Display an alert to inform the user of failed login attempt
            showAlert("Login Failed", "Invalid Credentials. Try again 😥.");

            // Reset the login fields for a new attempt
            usernameField.requestFocus(); // Set focus back to the username field
            usernameField.selectAll(); // Highlight existing text for easy replacement
            passwordField.clear(); // Clear the password field
        }
    }

    /**
     * Opens the main application window by loading the associated FXML file.
     * This method closes the current login window and launches the Auto Loan
     * Application interface.
     *
     * @throws IOException If loading the FXML file fails
     */
    private void openMainApplication() throws IOException {
        // Load the main application UI from the corresponding FXML file
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/fxml/autoLoan.fxml"));
        Parent root = loader.load();

        // Retrieve the current stage from the login button and close the login window
        Stage currentStage = (Stage) loginButton.getScene().getWindow();
        currentStage.close();

        // Create a new stage for the main application window
        Stage mainStage = new Stage();
        mainStage.setTitle("Auto Loan Java Application"); // Set the title of the main application window
        mainStage.setScene(new Scene(root)); // Set the scene with the loaded UI layout
        mainStage.setResizable(true); // Allow resizing of the window
        mainStage.show(); // Display the main application window
    }

    /**
     * Displays an alert dialog with the given title and message.
     * The alert informs users of errors or important notifications.
     *
     * @param title   The title of the alert dialog
     * @param message The message to be displayed inside the alert
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR); // Create an error alert dialog
        alert.setTitle(title); // Set the title of the alert
        alert.setHeaderText(null); // Remove the header text for a cleaner look
        alert.setContentText(message); // Set the alert message
        alert.showAndWait(); // Display the alert and wait for user acknowledgment
    }
}
