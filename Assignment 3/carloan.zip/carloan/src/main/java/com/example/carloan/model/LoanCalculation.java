/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/
package com.example.carloan.model;
import java.util.List;
public interface LoanCalculation {
    double calculateMonthlyPayment();
    List<LoanAmortization> generateAmortizationSchedule();
}
