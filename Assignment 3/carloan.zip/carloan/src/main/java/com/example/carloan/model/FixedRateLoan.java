/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/

package com.example.carloan.model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;



/**
 * The FixedRateLoan class represents a loan with a fixed interest rate. It extends the Loan class and implements the LoanCalculation interface.
 * This class provides methods for calculating loan payments and generating an amortization schedule based on the given parameters.
 */
public class FixedRateLoan extends Loan implements LoanCalculation {

    /**
     * Default constructor that initializes a FixedRateLoan instance with default values.
     * Calls the superclass Loan's default constructor to ensure proper initialization.
     */
    public FixedRateLoan() {
        super();
    }

    /**
     * Parameterized constructor that initializes a FixedRateLoan instance with specific values.
     * It calls the superclass constructor to set the initial values of the loan.
     *
     * @param amount       The total loan amount before deductions.
     * @param downPayment  The initial down payment made towards the loan.
     * @param interestRate The fixed annual interest rate (expressed as a percentage).
     * @param duration     The total duration of the loan in months.
     * @param frequency    The payment frequency (Monthly, Weekly, Bi-weekly).
     * @param customer     The customer associated with the loan agreement.
     * @param vehicle      The vehicle being financed through the loan.
     */
    public FixedRateLoan(double amount, double downPayment, double interestRate, int duration,
                         String frequency, Customer customer, Vehicle vehicle) {
        super(amount, downPayment, interestRate, duration, frequency, customer, vehicle);
    }

    /**
     * Calculates the payment amount per period based on the fixed interest rate and loan terms.
     * The formula used for calculation is the standard loan payment formula:
     *
     * P = (P0 * r * (1 + r)^n) / ((1 + r)^n - 1)
     *
     * where:
     * P  = Monthly Payment Amount
     * P0 = Loan Principal (Vehicle Price - Down Payment)
     * r  = Monthly Interest Rate (Annual Rate / 12)
     * n  = Total Number of Months
     *
     * If the interest rate is 0%, the payment is simply the principal divided over the number of months.
     * The method also adjusts the payment amount based on the frequency specified (Monthly, Weekly, Bi-weekly).
     *
     * @return The calculated payment amount per payment cycle.
     */
    @Override
    public double calculateMonthlyPayment() {
        double loanPrincipal = getVehicle().getPrice() - getDownPayment(); // Principal amount after down payment
        double monthlyInterestRate = getInterestRate() / 100 / 12; // Convert annual interest rate to monthly decimal
        int totalMonths = getDuration(); // Loan duration in months

        // If interest rate is 0%, return a simple division of principal over months
        if (monthlyInterestRate == 0) {
            return loanPrincipal / totalMonths;
        }

        // Loan payment formula calculation
        double paymentFactor = (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths)) /
                (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);
        double monthlyPayment = loanPrincipal * paymentFactor;

        // Adjust payment based on the specified payment frequency
        switch (getFrequency()) {
            case "Weekly":
                return (monthlyPayment * 12) / 52; // Convert monthly payment to weekly equivalent
            case "Bi-weekly":
                return (monthlyPayment * 12) / 26; // Convert monthly payment to bi-weekly equivalent
            default: // Default case: Monthly payments
                return monthlyPayment;
        }
    }

    /**
     * Generates an amortization schedule, detailing each scheduled payment's breakdown.
     * The amortization schedule consists of:
     * - Payment number
     * - Payment date
     * - Total payment amount per period
     * - Interest portion of the payment
     * - Principal portion of the payment
     * - Remaining loan balance
     *
     * The payment schedule adjusts based on the selected payment frequency (Monthly, Weekly, Bi-weekly).
     *
     * @return A list of LoanAmortization objects representing the complete payment schedule.
     */
    @Override
    public List<LoanAmortization> generateAmortizationSchedule() {
        List<LoanAmortization> schedule = new ArrayList<>(); // List to store amortization entries

        double loanPrincipal = getVehicle().getPrice() - getDownPayment(); // Principal amount after down payment
        double monthlyInterestRate = getInterestRate() / 100 / 12; // Convert annual interest rate to monthly decimal
        double baseMonthlyPayment = calculateMonthlyPayment(); // Base monthly payment amount

        // Determine the number of payments per year and adjust the periodic payment amount accordingly
        int paymentsPerYear;
        double paymentPerPeriod;

        switch (getFrequency()) {
            case "Weekly":
                paymentsPerYear = 52;
                paymentPerPeriod = (baseMonthlyPayment * 12) / 52;
                break;
            case "Bi-weekly":
                paymentsPerYear = 26;
                paymentPerPeriod = (baseMonthlyPayment * 12) / 26;
                break;
            default: // Monthly
                paymentsPerYear = 12;
                paymentPerPeriod = baseMonthlyPayment;
                break;
        }

        int totalPayments = getDuration() * paymentsPerYear / 12; // Total number of payments over the loan period
        double periodicInterestRate = monthlyInterestRate * 12 / paymentsPerYear; // Adjusted interest rate per payment period

        double remainingBalance = loanPrincipal; // Initial balance
        LocalDate paymentDate = LocalDate.now(); // Start date of payments

        for (int paymentNumber = 1; paymentNumber <= totalPayments; paymentNumber++) {
            double interestPayment = remainingBalance * periodicInterestRate; // Interest portion of payment
            double principalPayment = paymentPerPeriod - interestPayment; // Principal portion of payment

            // Ensure last payment does not overpay due to rounding errors
            if (paymentNumber == totalPayments && Math.abs(remainingBalance - principalPayment) > 0.01) {
                principalPayment = remainingBalance;
                paymentPerPeriod = principalPayment + interestPayment;
            }

            remainingBalance -= principalPayment; // Reduce remaining balance
            if (remainingBalance < 0.01) remainingBalance = 0; // Prevent negative balance due to rounding

            // Adjust payment date based on frequency
            switch (getFrequency()) {
                case "Weekly":
                    paymentDate = paymentDate.plusWeeks(1);
                    break;
                case "Bi-weekly":
                    paymentDate = paymentDate.plusWeeks(2);
                    break;
                default: // Monthly
                    paymentDate = paymentDate.plusMonths(1);
                    break;
            }

            // Create and add an amortization entry to the schedule
            LoanAmortization paymentEntry = new LoanAmortization(
                    paymentNumber, paymentDate, paymentPerPeriod, interestPayment, principalPayment, remainingBalance
            );

            schedule.add(paymentEntry);
        }

        return schedule; // Return the complete amortization schedule
    }
}

