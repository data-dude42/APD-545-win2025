/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/
package com.example.carloan.controller;

import com.example.carloan.HelloApplication;

import com.example.carloan.model.*;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AutoLoanController {
    // Customer Information
    @FXML
    private TextField nameField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField cityField;
    @FXML
    private ComboBox<String> provinceComboBox;

    // Vehicle Information
    @FXML
    private ToggleGroup vehicleTypeGroup;
    @FXML
    private RadioButton carRadioButton;
    @FXML
    private RadioButton truckRadioButton;
    @FXML
    private RadioButton vanRadioButton;

    @FXML
    private ToggleGroup vehicleAgeGroup;
    @FXML
    private RadioButton newRadioButton;
    @FXML
    private RadioButton usedRadioButton;

    @FXML
    private TextField vehiclePriceField;

    // Loan Information
    @FXML
    private TextField downPaymentField;

    @FXML
    private ToggleGroup interestRateGroup;
    @FXML
    private RadioButton interestRate099;
    @FXML
    private RadioButton interestRate199;
    @FXML
    private RadioButton interestRate299;
    @FXML
    private RadioButton interestRateOther;
    @FXML
    private TextField customInterestRateField;

    @FXML
    private Slider durationSlider;
    @FXML
    private Label durationLabel;

    @FXML
    private ToggleGroup paymentFrequencyGroup;
    @FXML
    private RadioButton weeklyRadioButton;
    @FXML
    private RadioButton biWeeklyRadioButton;
    @FXML
    private RadioButton monthlyRadioButton;

    @FXML
    private Label paymentAmountLabel;

    // Buttons
    @FXML
    private Button clearButton;
    @FXML
    private Button calculateButton;
    @FXML
    private Button saveRatesButton;
    @FXML
    private Button showSavedRatesButton;
    @FXML
    private Button showAmortizationButton;

    // Stored data
    private List<Loan> savedLoans = new ArrayList<>();
    private List<LoanAmortization> currentAmortizationSchedule;
    private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

    @FXML
    public void initialize() {
        // Initialize provinces dropdown
        provinceComboBox.setItems(FXCollections.observableArrayList(
                "Alberta", "British Columbia", "Manitoba", "New Brunswick",
                "Newfoundland and Labrador", "Nova Scotia", "Ontario",
                "Prince Edward Island", "Quebec", "Saskatchewan"));

        // Set default values for radio buttons
        carRadioButton.setSelected(true);
        newRadioButton.setSelected(true);
        interestRate099.setSelected(true);
        monthlyRadioButton.setSelected(true);

        // Setup slider with tick marks
        durationSlider.setMin(12);
        durationSlider.setMax(96);
        durationSlider.setMajorTickUnit(12);
        durationSlider.setMinorTickCount(0);
        durationSlider.setSnapToTicks(true);
        durationSlider.setShowTickMarks(true);
        durationSlider.setShowTickLabels(true);

        // Bind duration label to slider value
        durationLabel.textProperty().bind(
                Bindings.createStringBinding(
                        () -> String.format("%d months", (int) durationSlider.getValue()),
                        durationSlider.valueProperty()));

        // Setup custom interest rate field
        customInterestRateField.setDisable(true);
        interestRateOther.selectedProperty().addListener((obs, oldVal, newVal) -> {
            customInterestRateField.setDisable(!newVal);
            if (newVal) {
                customInterestRateField.requestFocus();
            }
        });

        // Setup button actions
        clearButton.setOnAction(event -> clearFields());
        calculateButton.setOnAction(event -> calculateLoan());
        saveRatesButton.setOnAction(event -> saveCurrentRate());
        showSavedRatesButton.setOnAction(event -> openSavedRatesView());
        showAmortizationButton.setOnAction(event -> openAmortizationView());

        // Initially disable some buttons
        saveRatesButton.setDisable(true);
        showAmortizationButton.setDisable(true);
    }

    @FXML
    public void clearFields() {
        // Clear customer information
        nameField.clear();
        phoneField.clear();
        cityField.clear();
        provinceComboBox.getSelectionModel().clearSelection();

        // Reset vehicle information
        carRadioButton.setSelected(true);
        newRadioButton.setSelected(true);
        vehiclePriceField.clear();

        // Reset loan information
        downPaymentField.clear();
        interestRate099.setSelected(true);
        customInterestRateField.clear();
        customInterestRateField.setDisable(true);
        durationSlider.setValue(12);
        monthlyRadioButton.setSelected(true);

        // Clear calculated payment
        paymentAmountLabel.setText("$0.00");

        // Disable buttons that depend on calculation
        saveRatesButton.setDisable(true);
        showAmortizationButton.setDisable(true);

        // Clear current amortization schedule
        currentAmortizationSchedule = null;
    }

    @FXML
    public void calculateLoan() {
        if (!validateInputs()) {
            return;
        }

        try {
            // Create customer object
            Customer customer = new Customer(
                    nameField.getText().trim(),
                    phoneField.getText().trim(),
                    cityField.getText().trim(),
                    provinceComboBox.getValue());

            // Create vehicle object
            RadioButton selectedVehicleType = (RadioButton) vehicleTypeGroup.getSelectedToggle();
            RadioButton selectedVehicleAge = (RadioButton) vehicleAgeGroup.getSelectedToggle();

            double vehiclePrice = Double.parseDouble(vehiclePriceField.getText().trim());

            Vehicle vehicle = new Vehicle(
                    selectedVehicleType.getText(),
                    selectedVehicleAge.getText(),
                    vehiclePrice);

            // Get loan parameters
            double downPayment = Double.parseDouble(downPaymentField.getText().trim());

            double interestRate;
            RadioButton selectedInterestRate = (RadioButton) interestRateGroup.getSelectedToggle();
            if (selectedInterestRate == interestRateOther) {
                interestRate = Double.parseDouble(customInterestRateField.getText().trim());
            } else {
                interestRate = Double.parseDouble(selectedInterestRate.getText().replace("%", ""));
            }

            int duration = (int) durationSlider.getValue();

            RadioButton selectedFrequency = (RadioButton) paymentFrequencyGroup.getSelectedToggle();
            String frequency = selectedFrequency.getText();

            // Create loan object
            FixedRateLoan loan = new FixedRateLoan(
                    vehiclePrice - downPayment,
                    downPayment,
                    interestRate,
                    duration,
                    frequency,
                    customer,
                    vehicle);

            // Calculate payment
            double paymentAmount = loan.calculateMonthlyPayment();
            paymentAmountLabel.setText(currencyFormat.format(paymentAmount));

            // Generate amortization schedule
            currentAmortizationSchedule = loan.generateAmortizationSchedule();

            // Enable buttons
            saveRatesButton.setDisable(false);
            showAmortizationButton.setDisable(false);

        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter valid numbers for price, down payment, and interest rate.");
        } catch (Exception e) {
            showAlert("Error", "An unexpected error occurred: " + e.getMessage());
        }
    }

    private boolean validateInputs() {
        StringBuilder errorMessage = new StringBuilder();

        // Validate customer information
        if (nameField.getText().trim().isEmpty()) {
            errorMessage.append("- Name is required\n");
        }

        if (phoneField.getText().trim().isEmpty()) {
            errorMessage.append("- Phone number is required\n");
        }

        if (cityField.getText().trim().isEmpty()) {
            errorMessage.append("- City is required\n");
        }

        if (provinceComboBox.getValue() == null) {
            errorMessage.append("- Province must be selected\n");
        }

        // Validate vehicle information
        if (vehiclePriceField.getText().trim().isEmpty()) {
            errorMessage.append("- Vehicle price is required\n");
        } else {
            try {
                double price = Double.parseDouble(vehiclePriceField.getText().trim());
                if (price <= 0) {
                    errorMessage.append("- Vehicle price must be greater than zero\n");
                }
            } catch (NumberFormatException e) {
                errorMessage.append("- Vehicle price must be a valid number\n");
            }
        }

        // Validate loan information
        if (downPaymentField.getText().trim().isEmpty()) {
            errorMessage.append("- Down payment is required\n");
        } else {
            try {
                double downPayment = Double.parseDouble(downPaymentField.getText().trim());
                if (downPayment < 0) {
                    errorMessage.append("- Down payment cannot be negative\n");
                }

                if (!vehiclePriceField.getText().trim().isEmpty()) {
                    double vehiclePrice = Double.parseDouble(vehiclePriceField.getText().trim());
                    if (downPayment >= vehiclePrice) {
                        errorMessage.append("- Down payment must be less than vehicle price\n");
                    }
                }
            } catch (NumberFormatException e) {
                errorMessage.append("- Down payment must be a valid number\n");
            }
        }

        // Validate interest rate
        RadioButton selectedInterestRate = (RadioButton) interestRateGroup.getSelectedToggle();
        if (selectedInterestRate == interestRateOther) {
            if (customInterestRateField.getText().trim().isEmpty()) {
                errorMessage.append("- Custom interest rate is required\n");
            } else {
                try {
                    double rate = Double.parseDouble(customInterestRateField.getText().trim());
                    if (rate < 0) {
                        errorMessage.append("- Interest rate cannot be negative\n");
                    }
                } catch (NumberFormatException e) {
                    errorMessage.append("- Interest rate must be a valid number\n");
                }
            }
        }

        if (errorMessage.length() > 0) {
            showAlert("Validation Error", "Please correct the following errors:\n" + errorMessage.toString());
            return false;
        }

        return true;
    }

    @FXML
    public void saveCurrentRate() {
        if (currentAmortizationSchedule == null) {
            showAlert("Error", "Please calculate the loan first.");
            return;
        }

        // Create customer object
        Customer customer = new Customer(
                nameField.getText().trim(),
                phoneField.getText().trim(),
                cityField.getText().trim(),
                provinceComboBox.getValue());

        // Create vehicle object
        RadioButton selectedVehicleType = (RadioButton) vehicleTypeGroup.getSelectedToggle();
        RadioButton selectedVehicleAge = (RadioButton) vehicleAgeGroup.getSelectedToggle();

        double vehiclePrice = Double.parseDouble(vehiclePriceField.getText().trim());

        Vehicle vehicle = new Vehicle(
                selectedVehicleType.getText(),
                selectedVehicleAge.getText(),
                vehiclePrice);

        // Get loan parameters
        double downPayment = Double.parseDouble(downPaymentField.getText().trim());

        double interestRate;
        RadioButton selectedInterestRate = (RadioButton) interestRateGroup.getSelectedToggle();
        if (selectedInterestRate == interestRateOther) {
            interestRate = Double.parseDouble(customInterestRateField.getText().trim());
        } else {
            interestRate = Double.parseDouble(selectedInterestRate.getText().replace("%", ""));
        }

        int duration = (int) durationSlider.getValue();

        RadioButton selectedFrequency = (RadioButton) paymentFrequencyGroup.getSelectedToggle();
        String frequency = selectedFrequency.getText();

        // Create loan object
        FixedRateLoan loan = new FixedRateLoan(
                vehiclePrice - downPayment,
                downPayment,
                interestRate,
                duration,
                frequency,
                customer,
                vehicle);

        // Add to saved loans
        savedLoans.add(loan);

        showAlert("Success", "Loan details saved successfully.", Alert.AlertType.INFORMATION);
    }

    @FXML
    public void openSavedRatesView() {
        if (savedLoans.isEmpty()) {
            showAlert("No Saved Rates", "There are no saved rates to display.", Alert.AlertType.INFORMATION);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/fxml/savedRates.fxml"));
            Parent root = loader.load();

            SavedRateController controller = loader.getController();

            // Create list of display strings
            ObservableList<String> displayItems = FXCollections.observableArrayList();
            for (Loan loan : savedLoans) {
                String displayString = String.format("%s - %s - %.2f%%",
                        loan.getCustomer().getName(),
                        loan.getVehicle().getType(),
                        loan.getInterestRate());
                displayItems.add(displayString);
            }

            // Configure controller with data and callback
            controller.setSavedRates(displayItems, savedLoans, this::loadSelectedLoan);

            // Show window
            Stage stage = new Stage();
            stage.setTitle("Saved Rates");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            showAlert("Error", "Could not open saved rates window: " + e.getMessage());
        }
    }

    @FXML
    public void openAmortizationView() {
        if (currentAmortizationSchedule == null) {
            showAlert("Error", "Please calculate the loan first.");
            return;
        }

        try {
            // Print resource URL for debugging
            URL resource = HelloApplication.class.getResource("/fxml/amortization.fxml");
            if (resource == null) {
                throw new FileNotFoundException("Cannot find amortization.fxml resource");
            }
            System.out.println("Resource URL: " + resource.toString());

            FXMLLoader loader = new FXMLLoader(resource);
            Parent root = loader.load();

            AmortizationController controller = loader.getController();
            if (controller == null) {
                throw new NullPointerException("Failed to get AmortizationController instance");
            }

            controller.setAmortizationData(currentAmortizationSchedule);

            Stage stage = new Stage();
            stage.setTitle("Amortization Schedule");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            showAlert("Resource Error", "Could not find the amortization.fxml file: " + e.getMessage());
        } catch (NullPointerException e) {
            e.printStackTrace();
            showAlert("Controller Error", "Controller initialization failed: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("I/O Error", "Failed to load amortization view: " + e.getMessage() +
                    "\nCheck your console for more detailed error information.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Unexpected Error", "An unexpected error occurred: " + e.getMessage());
        }
    }

    public void loadSelectedLoan(Loan loan) {
        // Set customer information
        nameField.setText(loan.getCustomer().getName());
        phoneField.setText(loan.getCustomer().getPhone());
        cityField.setText(loan.getCustomer().getCity());
        provinceComboBox.setValue(loan.getCustomer().getProvince());

        // Set vehicle information
        String vehicleType = loan.getVehicle().getType();
        vehicleTypeGroup.getToggles().forEach(toggle -> {
            RadioButton rb = (RadioButton) toggle;
            if (rb.getText().equals(vehicleType)) {
                rb.setSelected(true);
            }
        });

        String vehicleAge = loan.getVehicle().getAge();
        vehicleAgeGroup.getToggles().forEach(toggle -> {
            RadioButton rb = (RadioButton) toggle;
            if (rb.getText().equals(vehicleAge)) {
                rb.setSelected(true);
            }
        });

        vehiclePriceField.setText(String.format("%.2f", loan.getVehicle().getPrice()));

        // Set loan information
        downPaymentField.setText(String.format("%.2f", loan.getDownPayment()));

        double interestRate = loan.getInterestRate();
        if (interestRate == 0.99) {
            interestRate099.setSelected(true);
        } else if (interestRate == 1.99) {
            interestRate199.setSelected(true);
        } else if (interestRate == 2.99) {
            interestRate299.setSelected(true);
        } else {
            interestRateOther.setSelected(true);
            customInterestRateField.setText(String.format("%.2f", interestRate));
        }

        durationSlider.setValue(loan.getDuration());

        String frequency = loan.getFrequency();
        paymentFrequencyGroup.getToggles().forEach(toggle -> {
            RadioButton rb = (RadioButton) toggle;
            if (rb.getText().equals(frequency)) {
                rb.setSelected(true);
            }
        });

        // Calculate payment for the loaded loan
        calculateLoan();
    }

    private void showAlert(String title, String message) {
        showAlert(title, message, Alert.AlertType.ERROR);
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
