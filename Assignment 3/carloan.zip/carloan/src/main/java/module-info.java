/**********************************************
 Workshop #
 Course:APD545 - SEM-05
 Last Name: SINGH
 First Name: PARAS
 ID: 165-114-232
 Section:NCC
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date: 2 March 2025
 **********************************************/


module com.example.carloan {
    requires javafx.controls;
    requires javafx.fxml;

    exports com.example.carloan;
    exports com.example.carloan.controller; 

    opens com.example.carloan.controller to javafx.fxml; // Allowing reflection access for FXML
}
