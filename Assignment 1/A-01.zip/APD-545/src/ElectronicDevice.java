/**********************************************
Workshop: 1 
Course:APD-545 - Semester: 5 Last Name:Singh First Name:Paras ID:165-114-232
Section: NCC
This assignment represents my own work in accordance with Seneca Academic Policy. Signature
Date: 22 Jan. 2025
**********************************************/

public abstract class ElectronicDevice implements IDeviceMaintainable, IDeviceOperable, Comparable<ElectronicDevice> {
    protected String name;
    protected String functionality;
    protected double price;
    protected String operatingInstructions;
    protected String maintenanceInstructions;
    protected String functionType;

    public ElectronicDevice(String name, String functionality, double price, 
                           String operatingInstructions, String maintenanceInstructions, 
                           String functionType) {
        this.name = name;
        this.functionality = functionality;
        this.price = price;
        this.operatingInstructions = operatingInstructions;
        this.maintenanceInstructions = maintenanceInstructions;
        this.functionType = functionType;
    }

    @Override
    public int compareTo(ElectronicDevice other) {
        return Double.compare(other.price, this.price); // For descending order
    }

    @Override
    public String toString() {
        return name;
    }

    public String getFunctionality() {
        return functionality;
    }

    public double getPrice() {
        return price;
    }

    public String getFunctionType() {
        return functionType;
    }

    @Override
    public String getOperatingInstructions() {
        return operatingInstructions;
    }

    @Override
    public String getMaintenanceInstructions() {
        return maintenanceInstructions;
    }
} 