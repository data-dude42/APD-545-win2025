/**********************************************
Workshop: 1 
Course:APD-545 - Semester: 5 Last Name:Singh First Name:Paras ID:165-114-232
Section: NCC
This assignment represents my own work in accordance with Seneca Academic Policy. Signature
Date: 22 Jan. 2025
**********************************************/

public interface IDeviceMaintainable {
    String getMaintenanceInstructions();
} 