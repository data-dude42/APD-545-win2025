/**********************************************
Workshop: 1 
Course:APD-545 - Semester: 5 Last Name:Singh First Name:Paras ID:165-114-232
Section: NCC
This assignment represents my own work in accordance with Seneca Academic Policy. Signature
Date: 22 Jan. 2025
**********************************************/


public class Tablet extends CommunicationDevices {
    public Tablet(double price) {
        super("Tablet",
              "Larger screen communication",
              price,
              "By using touchscreen",
              "Regular software updates",
              "Multi-functional");
    }
} 