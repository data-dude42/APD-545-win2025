/**********************************************
Workshop: 1 
Course:APD-545 - Semester: 5 Last Name:Singh First Name:Paras ID:165-114-232
Section: NCC
This assignment represents my own work in accordance with Seneca Academic Policy. Signature
Date: 22 Jan. 2025
**********************************************/

public abstract class CommunicationDevices extends ElectronicDevice {
    public CommunicationDevices(String name, String functionality, double price, 
                               String operatingInstructions, String maintenanceInstructions, 
                               String functionType) {
        super(name, functionality, price, operatingInstructions, maintenanceInstructions, functionType);
    }
} 