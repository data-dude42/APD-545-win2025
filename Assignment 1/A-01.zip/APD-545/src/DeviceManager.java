/**********************************************
Workshop: 1 
Course:APD-545 - Semester: 5 Last Name:Singh First Name:Paras ID:165-114-232
Section: NCC
This assignment represents my own work in accordance with Seneca Academic Policy. Signature
Date: 22 Jan. 2025
**********************************************/

import java.util.Arrays;
import java.util.Scanner;

public class DeviceManager {
    private ElectronicDevice[] devices;
    private Scanner scanner;

    public DeviceManager() {
        devices = new ElectronicDevice[5];
        scanner = new Scanner(System.in);
    }

    public void createDevices() {
        System.out.println("--:Requirement 1:--");
        
        System.out.print("Enter the price for smartphone: ");
        devices[0] = new SmartPhone(scanner.nextDouble());
        
        System.out.print("Enter the price for Tablet: ");
        devices[1] = new Tablet(scanner.nextDouble());
        
        System.out.print("Enter the price for GamingConsole: ");
        devices[2] = new GamingConsole(scanner.nextDouble());
        
        System.out.print("Enter the price for SmartTV: ");
        devices[3] = new SmartTV(scanner.nextDouble());
        
        System.out.print("Enter the price for SmartSpeaker: ");
        devices[4] = new SmartSpeaker(scanner.nextDouble());
    }

    public void displayMostExpensiveDevice() {
        System.out.println("\n--:Requirement 2:--");
        ElectronicDevice mostExpensive = devices[0];
        for (ElectronicDevice device : devices) {
            if (device.getPrice() > mostExpensive.getPrice()) {
                mostExpensive = device;
            }
        }

        System.out.println("The most expensive device is: " + mostExpensive);
        System.out.printf("%s's cost is: $%.2f%n", mostExpensive, mostExpensive.getPrice());
        System.out.println(mostExpensive + " is operated: " + mostExpensive.getOperatingInstructions());
        System.out.println(mostExpensive + " function type: " + mostExpensive.getFunctionType());
    }

    public void displayDevicesInPriceOrder() {
        System.out.println("\n--:Requirement 3:--");
        System.out.println("Devices in Descending Order of Price:");
        Arrays.sort(devices);
        for (ElectronicDevice device : devices) {
            System.out.println(device);
        }
    }

    public void displayDevicesByCategory() {
        System.out.println("\n--:Requirement 4:--");
        System.out.print("Enter a device Category (CommunicationDevices, EntertainmentDevices, UtilityDevices): ");
        String category = scanner.next();

        System.out.println("\nFunctionality of " + category + ":");
        for (ElectronicDevice device : devices) {
            if ((category.equals("CommunicationDevices") && device instanceof CommunicationDevices) ||
                (category.equals("EntertainmentDevices") && device instanceof EntertainmentDevices) ||
                (category.equals("UtilityDevices") && device instanceof UtilityDevices)) {
                System.out.println(device + ": " + device.getFunctionality());
            }
        }
    }

    public static void main(String[] args) {
        DeviceManager manager = new DeviceManager();
        manager.createDevices();
        manager.displayMostExpensiveDevice();
        manager.displayDevicesInPriceOrder();
        manager.displayDevicesByCategory();
    }
} 