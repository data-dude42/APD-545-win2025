/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/

module com.example.Workshop2 {
    /*Requires Statements:

requires javafx.controls;

requires javafx.fxml; These lines indicate that the module depends on the javafx.controls and javafx.fxml modules. */
    requires javafx.controls; 
    requires javafx.fxml;
    /*Opens Statements:

opens com.example.Workshop2 to javafx.fxml;

opens com.example.Workshop2.controllers to javafx.fxml;

opens com.example.Workshop2.models to javafx.base; These lines open the specified packages to the javafx.fxml and javafx.base modules, allowing reflection at runtime for features like dependency injection and dynamic object creation. */
    opens com.example.Workshop2 to javafx.fxml;
    opens com.example.Workshop2.controllers to javafx.fxml;
    opens com.example.Workshop2.models to javafx.base;
    /*Exports Statements:

exports com.example.Workshop2;

exports com.example.Workshop2.controllers; These lines make the specified packages accessible to other modules, enabling them to use the public classes and interfaces within these packages. */
    exports com.example.Workshop2;
    exports com.example.Workshop2.controllers;
}
