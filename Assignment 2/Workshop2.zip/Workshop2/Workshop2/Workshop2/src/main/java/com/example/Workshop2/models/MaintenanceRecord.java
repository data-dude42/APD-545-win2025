/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/

// setting up the package
package com.example.Workshop2.models; // Specifies the package where this class is located

import java.time.LocalDate; // Importing LocalDate to work with date values
import javafx.beans.property.*; // Importing JavaFX property classes to enable binding

/**
 * This class represents a maintenance record for a vehicle.
 * It stores information about a maintenance event, including the date of the event,
 * a description of the work done, the cost of the maintenance, and the vehicle ID.
 */
public class MaintenanceRecord {

    // ObjectProperty for storing the date of maintenance
    private final ObjectProperty<LocalDate> date;

    // StringProperty for storing a description of the maintenance work done
    private final StringProperty description;

    // DoubleProperty for storing the cost of the maintenance
    private final DoubleProperty cost;

    // StringProperty for storing the unique ID of the vehicle the maintenance was done on
    private final StringProperty vehicleId;

    /**
     * Constructor to initialize a new MaintenanceRecord object.
     *
     * @param date        The date when the maintenance was performed
     * @param description A description of the maintenance work
     * @param cost        The cost of the maintenance
     * @param vehicleId   The unique identifier for the vehicle
     */
    public MaintenanceRecord(LocalDate date, String description, double cost, String vehicleId) {
        // Initialize each property with the provided values
        this.date = new SimpleObjectProperty<>(date); // Using SimpleObjectProperty for LocalDate
        this.description = new SimpleStringProperty(description); // Using SimpleStringProperty for description
        this.cost = new SimpleDoubleProperty(cost); // Using SimpleDoubleProperty for cost
        this.vehicleId = new SimpleStringProperty(vehicleId); // Using SimpleStringProperty for vehicle ID
    }

    /**
     * Gets the date of the maintenance.
     *
     * @return The date when the maintenance was performed
     */
    public LocalDate getDate() {
        return date.get(); // Returns the value of the date property
    }

    /**
     * Sets the date of the maintenance.
     *
     * @param value The new date for the maintenance record
     */
    public void setDate(LocalDate value) {
        date.set(value); // Sets the new date for the property
    }

    /**
     * Provides the date property for binding.
     *
     * @return The ObjectProperty representing the date of the maintenance
     */
    public ObjectProperty<LocalDate> dateProperty() {
        return date; // Returns the ObjectProperty for date
    }

    /**
     * Gets the description of the maintenance.
     *
     * @return The description of the maintenance work done
     */
    public String getDescription() {
        return description.get(); // Returns the value of the description property
    }

    /**
     * Sets the description of the maintenance.
     *
     * @param value The new description for the maintenance
     */
    public void setDescription(String value) {
        description.set(value); // Sets the new description for the property
    }

    /**
     * Provides the description property for binding.
     *
     * @return The StringProperty representing the description of the maintenance
     */
    public StringProperty descriptionProperty() {
        return description; // Returns the StringProperty for description
    }

    /**
     * Gets the cost of the maintenance.
     *
     * @return The cost of the maintenance
     */
    public double getCost() {
        return cost.get(); // Returns the value of the cost property
    }

    /**
     * Sets the cost of the maintenance.
     *
     * @param value The new cost for the maintenance
     */
    public void setCost(double value) {
        cost.set(value); // Sets the new cost for the property
    }

    /**
     * Provides the cost property for binding.
     *
     * @return The DoubleProperty representing the cost of the maintenance
     */
    public DoubleProperty costProperty() {
        return cost; // Returns the DoubleProperty for cost
    }

    /**
     * Gets the vehicle ID associated with the maintenance record.
     *
     * @return The ID of the vehicle the maintenance was performed on
     */
    public String getVehicleId() {
        return vehicleId.get(); // Returns the value of the vehicle ID property
    }

    /**
     * Sets the vehicle ID for the maintenance record.
     *
     * @param value The new vehicle ID associated with the maintenance
     */
    public void setVehicleId(String value) {
        vehicleId.set(value); // Sets the new vehicle ID for the property
    }

    /**
     * Provides the vehicle ID property for binding.
     *
     * @return The StringProperty representing the vehicle ID
     */
    public StringProperty vehicleIdProperty() {
        return vehicleId; // Returns the StringProperty for vehicle ID
    }
}
