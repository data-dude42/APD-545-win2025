/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/
package com.example.Workshop2.controllers;
import com.example.Workshop2.models.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class VehicleController implements Initializable {
    @FXML
    private TextField modelField;
    @FXML
    private TextField makeField;
    @FXML
    private TextField yearField;
    @FXML
    private ComboBox<String> typeComboBox;
    @FXML
    private DatePicker maintenanceDatePicker;
    @FXML
    private TextField descriptionField;
    @FXML
    private TextField costField;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private TextField kilometersDrivenField;
    @FXML
    private TableView<VehicleDetails> vehicleTable;
    @FXML
    private TableView<MaintenanceRecord> maintenanceTable;
    @FXML
    private TableView<UsageLog> usageTable;

    private final ObservableList<VehicleDetails> vehicles = FXCollections.observableArrayList();
    private final ObservableList<MaintenanceRecord> maintenanceRecords = FXCollections.observableArrayList();
    private final ObservableList<UsageLog> usageLogs = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Populate typeComboBox with vehicle types
        typeComboBox.getItems().addAll("SEDAN", "SUV", "TRUCK", "COUPE");

        // Initialize all tables
        initializeTables();

        // Set current date for date pickers
        maintenanceDatePicker.setValue(LocalDate.now());
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
    }

    @FXML
    private void handleSaveVehicle() {
        try {
            // Retrieve values from form fields
            String model = modelField.getText();
            String make = makeField.getText();
            int year = Integer.parseInt(yearField.getText());
            String type = typeComboBox.getValue();

            // Add new vehicle to the list
            vehicles.add(new VehicleDetails(model, make, year, type));

            // Clear input fields after save
            handleClearVehicle();
        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter a valid year");
        }
    }

    @FXML
    private void handleClearVehicle() {
        // Clear all form fields for vehicle
        modelField.clear();
        makeField.clear();
        yearField.clear();
        typeComboBox.setValue(null);
    }

    @FXML
    private void handleSaveMaintenance() {
        try {
            // Retrieve values from form fields
            LocalDate date = maintenanceDatePicker.getValue();
            String description = descriptionField.getText();
            double cost = Double.parseDouble(costField.getText());

            // Check if a vehicle is selected
            if (!vehicles.isEmpty()) {
                // Create and add a new maintenance record
                MaintenanceRecord record = new MaintenanceRecord(
                        date,
                        description,
                        cost,
                        vehicles.get(vehicles.size() - 1).getModel() // Access last added vehicle
                );
                maintenanceRecords.add(record);
                handleClearMaintenance();
            } else {
                showAlert("Missing Vehicle", "Please add a vehicle first");
            }
        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter a valid cost");
        }
    }

    @FXML
    private void handleClearMaintenance() {
        // Clear all form fields for maintenance record
        maintenanceDatePicker.setValue(LocalDate.now());
        descriptionField.clear();
        costField.clear();
    }

    @FXML
    private void handleSaveUsage() {
        try {
            // Retrieve values from form fields
            LocalDate startDate = startDatePicker.getValue();
            LocalDate endDate = endDatePicker.getValue();
            double kilometers = Double.parseDouble(kilometersDrivenField.getText());

            // Check if a vehicle is selected
            if (!vehicles.isEmpty()) {
                // Create and add a new usage log
                UsageLog log = new UsageLog(
                        startDate,
                        endDate,
                        kilometers,
                        vehicles.get(vehicles.size() - 1).getModel() // Access last added vehicle
                );
                usageLogs.add(log);
                handleClearUsage();
            } else {
                showAlert("Not Found", "Please add a vehicle");
            }
        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Please enter valid value");
        }
    }

    @FXML
    private void handleClearUsage() {
        // Clear all form fields for usage log
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
        kilometersDrivenField.clear();
    }

    @FXML
    private void showSummary() {
        // Create a new stage for the summary window
        Stage summaryStage = new Stage();
        VBox summaryBox = new VBox(10);
        summaryBox.setPadding(new Insets(10));

        // Create a combo box to select summary type
        ComboBox<String> summaryType = new ComboBox<>();
        summaryType.getItems().addAll("Vehicles", "Maintenance Records", "Usage Logs");

        // Create a text area to display the summary
        TextArea summaryArea = new TextArea();
        summaryArea.setEditable(false);
        summaryArea.setPrefRowCount(10);

        // Handle selection change to display corresponding summary
        summaryType.setOnAction(event -> {
            String selected = summaryType.getValue();
            StringBuilder summary = new StringBuilder();

            switch (selected) {
                case "Vehicles":
                    vehicles.forEach(v -> summary.append(String.format(
                            "Model: %s, Make: %s, Year: %d, Type: %s\n",
                            v.getModel(), v.getMake(), v.getYear(), v.getType())));
                    break;
                case "Maintenance Records":
                    maintenanceRecords.forEach(r -> summary.append(String.format(
                            "Date: %s, Description: %s, Cost: $%.2f, Vehicle: %s\n",
                            r.getDate(), r.getDescription(), r.getCost(), r.getVehicleId())));
                    break;
                case "Usage Logs":
                    usageLogs.forEach(l -> summary.append(String.format(
                            "Start: %s, End: %s, KM: %.1f, Vehicle: %s\n",
                            l.getStartDate(), l.getEndDate(), l.getKilometersDriven(), l.getVehicleId())));
                    break;
            }
            summaryArea.setText(summary.toString());
        });

        // Add components to the VBox layout
        summaryBox.getChildren().addAll(summaryType, summaryArea);

        // Create the scene and set it on the stage
        Scene summaryScene = new Scene(summaryBox, 400, 300);
        summaryStage.setTitle("Summary");
        summaryStage.setScene(summaryScene);
        summaryStage.show();
    }

    private void showAlert(String title, String content) {
        // Display an alert dialog with the given title and content
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @SuppressWarnings("unchecked") // Added to suppress varargs warning
    private void initializeTables() {
        // Initialize vehicle table
        TableColumn<VehicleDetails, String> modelCol = new TableColumn<>("Model");
        modelCol.setCellValueFactory(new PropertyValueFactory<>("model"));

        TableColumn<VehicleDetails, String> makeCol = new TableColumn<>("Make");
        makeCol.setCellValueFactory(new PropertyValueFactory<>("make"));

        TableColumn<VehicleDetails, Integer> yearCol = new TableColumn<>("Year");
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));

        TableColumn<VehicleDetails, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

        vehicleTable.getColumns().addAll(modelCol, makeCol, yearCol, typeCol);
        vehicleTable.setItems(vehicles);

        // Initialize maintenance table
        TableColumn<MaintenanceRecord, LocalDate> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<MaintenanceRecord, String> descCol = new TableColumn<>("Description");
        descCol.setCellValueFactory(new PropertyValueFactory<>("description"));

        TableColumn<MaintenanceRecord, Double> costCol = new TableColumn<>("Cost");
        costCol.setCellValueFactory(new PropertyValueFactory<>("cost"));

        maintenanceTable.getColumns().addAll(dateCol, descCol, costCol);
        maintenanceTable.setItems(maintenanceRecords);

        // Initialize usage table
        TableColumn<UsageLog, LocalDate> startDateCol = new TableColumn<>("Start Date");
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        TableColumn<UsageLog, LocalDate> endDateCol = new TableColumn<>("End Date");
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));

        TableColumn<UsageLog, Double> kmCol = new TableColumn<>("Kilometers");
        kmCol.setCellValueFactory(new PropertyValueFactory<>("kilometersDriven"));

        usageTable.getColumns().addAll(startDateCol, endDateCol, kmCol);
        usageTable.setItems(usageLogs);
    }
}
