/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/

package com.example.Workshop2;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ViewController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("JVM!");
    }
}