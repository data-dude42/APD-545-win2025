/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/

package com.example.Workshop2.models; // Specifies the package where this class is located
import java.time.LocalDate; // Importing LocalDate to work with date values
import javafx.beans.property.*; // Importing JavaFX property classes to enable binding

/**
 * This class represents a usage log for a vehicle.
 * It stores information about the start and end dates of the usage,
 * the kilometers driven during the usage, and the vehicle ID associated with the usage.
 */
public class UsageLog {

    // ObjectProperty for storing the start date of the usage period
    private final ObjectProperty<LocalDate> startDate;

    // ObjectProperty for storing the end date of the usage period
    private final ObjectProperty<LocalDate> endDate;

    // DoubleProperty for storing the number of kilometers driven during the usage
    private final DoubleProperty kilometersDriven;

    // StringProperty for storing the unique ID of the vehicle associated with this usage log
    private final StringProperty vehicleId;

    /**
     * Constructor to initialize a new UsageLog object.
     *
     * @param startDate      The start date of the vehicle usage
     * @param endDate        The end date of the vehicle usage
     * @param kilometersDriven The number of kilometers driven during the usage
     * @param vehicleId      The unique identifier for the vehicle
     */
    public UsageLog(LocalDate startDate, LocalDate endDate, double kilometersDriven, String vehicleId) {
        // Initialize each property with the provided values
        this.startDate = new SimpleObjectProperty<>(startDate); // Using SimpleObjectProperty for startDate
        this.endDate = new SimpleObjectProperty<>(endDate); // Using SimpleObjectProperty for endDate
        this.kilometersDriven = new SimpleDoubleProperty(kilometersDriven); // Using SimpleDoubleProperty for kilometersDriven
        this.vehicleId = new SimpleStringProperty(vehicleId); // Using SimpleStringProperty for vehicleId
    }

    /**
     * Gets the start date of the vehicle usage.
     *
     * @return The start date of the vehicle usage
     */
    public LocalDate getStartDate() {
        return startDate.get(); // Returns the value of the startDate property
    }

    /**
     * Sets the start date of the vehicle usage.
     *
     * @param value The new start date for the usage log
     */
    public void setStartDate(LocalDate value) {
        startDate.set(value); // Sets the new start date for the property
    }

    /**
     * Provides the startDate property for binding.
     *
     * @return The ObjectProperty representing the start date of the usage
     */
    public ObjectProperty<LocalDate> startDateProperty() {
        return startDate; // Returns the ObjectProperty for startDate
    }

    /**
     * Gets the end date of the vehicle usage.
     *
     * @return The end date of the vehicle usage
     */
    public LocalDate getEndDate() {
        return endDate.get(); // Returns the value of the endDate property
    }

    /**
     * Sets the end date of the vehicle usage.
     *
     * @param value The new end date for the usage log
     */
    public void setEndDate(LocalDate value) {
        endDate.set(value); // Sets the new end date for the property
    }

    /**
     * Provides the endDate property for binding.
     *
     * @return The ObjectProperty representing the end date of the usage
     */
    public ObjectProperty<LocalDate> endDateProperty() {
        return endDate; // Returns the ObjectProperty for endDate
    }

    /**
     * Gets the number of kilometers driven during the vehicle usage.
     *
     * @return The kilometers driven during the usage
     */
    public double getKilometersDriven() {
        return kilometersDriven.get(); // Returns the value of the kilometersDriven property
    }

    /**
     * Sets the number of kilometers driven during the vehicle usage.
     *
     * @param value The new number of kilometers driven
     */
    public void setKilometersDriven(double value) {
        kilometersDriven.set(value); // Sets the new kilometers driven for the property
    }

    /**
     * Provides the kilometersDriven property for binding.
     *
     * @return The DoubleProperty representing the kilometers driven during the usage
     */
    public DoubleProperty kilometersDrivenProperty() {
        return kilometersDriven; // Returns the DoubleProperty for kilometersDriven
    }

    /**
     * Gets the vehicle ID associated with this usage log.
     *
     * @return The ID of the vehicle
     */
    public String getVehicleId() {
        return vehicleId.get(); // Returns the value of the vehicleId property
    }

    /**
     * Sets the vehicle ID for this usage log.
     *
     * @param value The new vehicle ID associated with the usage
     */
    public void setVehicleId(String value) {
        vehicleId.set(value); // Sets the new vehicle ID for the property
    }

    /**
     * Provides the vehicleId property for binding.
     *
     * @return The StringProperty representing the vehicle ID
     */
    public StringProperty vehicleIdProperty() {
        return vehicleId; // Returns the StringProperty for vehicleId
    }
}







