/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/
package com.example.Workshop2; // Defines the package for the application

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ApplicationView extends Application { // Extends Application to create a JavaFX application
    @Override
    public void start(Stage stage) throws IOException { // Entry point for JavaFX application
        FXMLLoader fxmlLoader = new FXMLLoader(ApplicationView.class.getResource("/fxml/main.fxml")); // Loads the FXML
                                                                                                      // file for the UI
        Scene scene = new Scene(fxmlLoader.load(), 1000, 1000); // Creates a scene with specified dimensions
        stage.setTitle("VEHICLE MANAGEMENT SYSTEM"); // Sets the window title
        stage.setScene(scene); // Sets the scene for the stage
        stage.show(); // Displays the stage
    }

    public static void main(String[] args) { // Main method to launch the application
        launch(); // Calls JavaFX launch method
    }
}
