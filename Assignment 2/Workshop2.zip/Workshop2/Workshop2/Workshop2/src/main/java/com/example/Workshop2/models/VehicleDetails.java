/**********************************************
Workshop #
Course:APD545 - Semester
Last Name:Singh
First Name:Paras
ID:165-114-232
Section:NCC
This assignment represents my own work in accordance with Seneca Academic Policy.
Signature
Date:9 FEB, 2025
**********************************************/

package com.example.Workshop2.models; // Specifies the package where this class is located
import javafx.beans.property.*; // Importing JavaFX property classes to enable property bindings

/**
 * This class represents the details of a vehicle.
 * It stores information about the model, make, year, and type of the vehicle.
 */
public class VehicleDetails {

    // StringProperty for storing the vehicle's model (e.g., "Corolla", "Civic")
    private final StringProperty model;

    // StringProperty for storing the vehicle's make (e.g., "Toyota", "Honda")
    private final StringProperty make;

    // IntegerProperty for storing the vehicle's manufacturing year (e.g., 2020, 2021)
    private final IntegerProperty year;

    // StringProperty for storing the vehicle's type (e.g., "Sedan", "SUV")
    private final StringProperty type;

    /**
     * Constructor to initialize a new VehicleDetails object.
     *
     * @param model The model name of the vehicle (e.g., "Camry", "Accord")
     * @param make The make or brand of the vehicle (e.g., "Toyota", "Honda")
     * @param year The year the vehicle was manufactured
     * @param type The type of the vehicle (e.g., "Sedan", "SUV")
     */
    public VehicleDetails(String model, String make, int year, String type) {
        // Initialize each property with the provided values
        this.model = new SimpleStringProperty(model); // Using SimpleStringProperty for model
        this.make = new SimpleStringProperty(make); // Using SimpleStringProperty for make
        this.year = new SimpleIntegerProperty(year); // Using SimpleIntegerProperty for year
        this.type = new SimpleStringProperty(type); // Using SimpleStringProperty for type
    }

    /**
     * Gets the model of the vehicle.
     *
     * @return The model of the vehicle
     */
    public String getModel() {
        return model.get(); // Returns the value of the model property
    }

    /**
     * Sets the model of the vehicle.
     *
     * @param value The new model for the vehicle
     */
    public void setModel(String value) {
        model.set(value); // Sets the new model for the property
    }

    /**
     * Provides the model property for binding.
     *
     * @return The StringProperty representing the model of the vehicle
     */
    public StringProperty modelProperty() {
        return model; // Returns the StringProperty for model
    }

    /**
     * Gets the make of the vehicle.
     *
     * @return The make or brand of the vehicle
     */
    public String getMake() {
        return make.get(); // Returns the value of the make property
    }

    /**
     * Sets the make of the vehicle.
     *
     * @param value The new make for the vehicle
     */
    public void setMake(String value) {
        make.set(value); // Sets the new make for the property
    }

    /**
     * Provides the make property for binding.
     *
     * @return The StringProperty representing the make of the vehicle
     */
    public StringProperty makeProperty() {
        return make; // Returns the StringProperty for make
    }

    /**
     * Gets the year the vehicle was manufactured.
     *
     * @return The manufacturing year of the vehicle
     */
    public int getYear() {
        return year.get(); // Returns the value of the year property
    }

    /**
     * Sets the year the vehicle was manufactured.
     *
     * @param value The new manufacturing year for the vehicle
     */
    public void setYear(int value) {
        year.set(value); // Sets the new year for the property
    }

    /**
     * Provides the year property for binding.
     *
     * @return The IntegerProperty representing the year the vehicle was manufactured
     */
    public IntegerProperty yearProperty() {
        return year; // Returns the IntegerProperty for year
    }

    /**
     * Gets the type of the vehicle.
     *
     * @return The type of the vehicle (e.g., "Sedan", "SUV")
     */
    public String getType() {
        return type.get(); // Returns the value of the type property
    }

    /**
     * Sets the type of the vehicle.
     *
     * @param value The new type for the vehicle
     */
    public void setType(String value) {
        type.set(value); // Sets the new type for the property
    }

    /**
     * Provides the type property for binding.
     *
     * @return The StringProperty representing the type of the vehicle
     */
    public StringProperty typeProperty() {
        return type; // Returns the StringProperty for type
    }
}
